import os
import argparse


def main():
    parser = argparse.ArgumentParser(prog="CI-Run-Test")

    # Program arguments
    parser.add_argument("--zone", type=str, required=True, help="Cerebro zone")
    parser.add_argument("--env", type=str, required=True, help="Project environment")
    parser.add_argument("--suite", type=str, required=True, help="Test Suite")
    parser.add_argument("--groups", type=str, help="TestNG groups to run")

    args = parser.parse_args()

    run_tests(args.zone, args.env, args.suite, args.groups)


def run_tests(zone: str, env: str, suite: str, groups: str) -> None:
    """
    Runs test suites using a service account.

    :param zone: Zone to run test.
    :param env: Environment to run test.
    :param suite: TestNG suite XML to run.
    :param groups: TestNG groups to run.
    """

    # Set google cloud service account
    service_acc = 'sa_cerebro_{}_{}_qadfcontrol'.format(env, zone)

    # Start test
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.environ[service_acc]
    os.environ["testENV"] = env
    os.environ["testZONE"] = zone
    os.system('gcloud auth activate-service-account --key-file=$GOOGLE_APPLICATION_CREDENTIALS')
    os.system('java -cp "./target/dependency/*:./target/cerebro-qa-automation.jar" ca.loblaw.cerebro.AutomationExecutor -suite "{}.xml" -groups "{}"'
              .format(suite, groups))


if __name__ == "__main__":
    main()
