package ca.loblaw.cerebro.automation.utils.cloud.datastore;

import com.google.cloud.datastore.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DatastoreService {

    private static Datastore DATASTORE = DatastoreOptions.getDefaultInstance().getService();
    private EntityQuery.Builder queryBuilder;

    private DatastoreService() {}

    public static class QueryBuilder {

        private EntityQuery.Builder queryBuilder;

        public QueryBuilder() {}

        public QueryBuilder newBuilder() {
            queryBuilder = Query.newEntityQueryBuilder();
            return this;
        }

        public QueryBuilder setNamespace(String namespace) {
            queryBuilder.setNamespace(namespace);
            return this;
        }

        public QueryBuilder setKind(String kind) {
            queryBuilder.setKind(kind);
            return this;
        }

        public QueryBuilder addEqualFilter(String key, String value) {
            queryBuilder.setFilter(StructuredQuery.PropertyFilter.eq(key, value));
            return this;
        }

        public QueryBuilder orderByDesc(String key) {
            queryBuilder.addOrderBy(StructuredQuery.OrderBy.desc(key));
            return this;
        }

        public QueryBuilder orderByAsc(String key) {
            queryBuilder.addOrderBy(StructuredQuery.OrderBy.asc(key));
            return this;
        }

        public QueryResults<Entity> query() {
            QueryResults<Entity> queryResults = DATASTORE.run(queryBuilder.build());
            queryBuilder = null;

            return queryResults;
        }

        public List<Entity> queryToList() {
            List<Entity> entityList = new ArrayList<>();
            QueryResults<Entity> queryResults = query();

            queryResults.forEachRemaining(entity -> entityList.add(entity));

            return entityList;
        }
    }
}
