package ca.loblaw.cerebro.automation.utils.contexts;

/**
 * Available Operating Systems.
 */
public enum OperatingSystem {
    LINUX,
    WINDOWS,
    MAC
}
