package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseLog;

public class MetadataLogHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseLog responseLog = (AirflowResponseLog) airflowResponseItem;

        // Update
        dagRun.setMetadataLog(responseLog.getLogs());
    }
}
