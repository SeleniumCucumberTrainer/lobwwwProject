package ca.loblaw.cerebro.automation.testcases.cloudcomposer.integration;

import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeFactory;
import ca.loblaw.cerebro.automation.utils.contexts.Project;

public class ComposerIntegrationSmokeFactory extends ComposerSmokeFactory {

    public ComposerIntegrationSmokeFactory() {
        super(
                Project.INTEGRATION_ZONE,
                "src/main/resources/setup/cloudcomposer/integration/IntegrationDAGs.xlsx",
                "IntegrationDAGs",
                "Integration"
        );
    }
}
