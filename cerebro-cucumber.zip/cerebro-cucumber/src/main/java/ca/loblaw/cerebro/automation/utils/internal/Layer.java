package ca.loblaw.cerebro.automation.utils.internal;

/**
 * Utility class to hold used Log4j2 ThreadContext keys.
 */
public class Layer {
    public static final String CLASS_NAME = "CLASSNAME";
    public static final String SUITE_NAME = "SUITENAME";
    public static final String BUNDLE_NAME = "BUNDLENAME";
    public static final String DATA_NAME = "DATANAME";
    public static final String INSTANCE_ID = "INSTANCEID";
    public static final String EXTENT_KEY = "EXTENTKEY";

    private Layer() {}
}
