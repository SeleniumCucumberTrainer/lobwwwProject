package ca.loblaw.cerebro.automation.utils.cloud.dataflow;

import com.google.dataflow.v1beta3.*;

import java.io.IOException;

public class DataflowService {

    private DataflowService() {}

    public static Job getDataflowJob(String projectId, String location, String jobId) throws IOException {
        try (JobsV1Beta3Client client = JobsV1Beta3Client.create()) {

            GetJobRequest jobRequest = GetJobRequest.newBuilder()
                    .setProjectId(projectId)
                    .setLocation(location)
                    .setJobId(jobId)
                    .build();

            return client.getJob(jobRequest);
        } catch (Exception e) {
            return null;
        }
    }

    public static JobMetrics getDataflowJobMetrics(String projectId, String location, String jobId) {
        try (MetricsV1Beta3Client client = MetricsV1Beta3Client.create()) {
            GetJobMetricsRequest metricsRequest = GetJobMetricsRequest.newBuilder()
                    .setProjectId(projectId)
                    .setLocation(location)
                    .setJobId(jobId)
                    .build();

            return client.getJobMetrics(metricsRequest);
        } catch (Exception e) {
            return null;
        }
    }
}
