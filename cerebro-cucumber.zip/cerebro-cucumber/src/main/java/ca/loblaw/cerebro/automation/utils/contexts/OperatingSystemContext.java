package ca.loblaw.cerebro.automation.utils.contexts;

import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Utility class to describe current OS context.
 */
public class OperatingSystemContext {
    public static final OperatingSystem OS = getOperatingSystem();
    public static final String USERNAME = getUsername();
    public static final String DOWNLOADS_DIR = getDownloadsDirectory();
    public static final String TEMP_DIR = getTempDirectory();
    public static ConcurrentHashMap<String, String> gsUtilCommandConfigMap;
    public static ConcurrentHashMap<String, String> filePathConfigMap;
    private static String gsutilCommandPath = "src/main/resources/configs/GSUtilCommands.properties";
    private static String filePathLinux = "src/main/resources/configs/LinuxFilePaths.properties";
    private static String filePathWin = "src/main/resources/configs/WinFilePaths.properties";
    private static String os = System.getProperty("os.name");
    private static String uname = System.getProperty("user.name");

    private OperatingSystemContext() {}

    private static String getTempDirectory() {
        return System.getProperty("java.io.tmpdir").replace("\\", "/");
    }

    private static String getDownloadsDirectory() {
        return System.getProperty("user.home").replace("\\", "/") + "/Downloads/";
    }

    private static String getUsername() {
        return System.getProperty("user.name");
    }

    private static OperatingSystem getOperatingSystem() {
        String operatingSystemName = System.getProperty("os.name").toLowerCase();

        if (operatingSystemName.contains("linux")) {
            return OperatingSystem.LINUX;
        } else if (operatingSystemName.contains("mac")) {
            return OperatingSystem.MAC;
        } else if (operatingSystemName.contains("windows")) {
            return OperatingSystem.WINDOWS;
        }

        throw new RuntimeException("OS not supported");
    }

    public static void setGSUtilCommands() throws IOException {
        //gsUtilCommandConfigMap = new ConcurrentHashMap<>(ReadPropFile.readPropFileToHashMap(gsutilCommandPath));
        gsUtilCommandConfigMap = new ConcurrentHashMap<>(PropertiesFileUtils.readPropertiesFileToMap(gsutilCommandPath));

        String os = System.getProperty("os.name");

        if(os.equalsIgnoreCase("linux") || os.equalsIgnoreCase("mac os x")){

        }
        else{
            for (Map.Entry e: gsUtilCommandConfigMap.entrySet()) {
                if (e.toString().contains("invokeDFJob")){
                    gsUtilCommandConfigMap.put(e.getKey().toString(),"cmd /c start "+e.getValue().toString());
                }else {
                    gsUtilCommandConfigMap.put(e.getKey().toString(),"cmd /c "+e.getValue().toString());
                }
            }
        }
    }

    public static void setFilePaths() throws IOException {
        if(os.equalsIgnoreCase("linux") || os.equalsIgnoreCase("mac os x")){
            filePathConfigMap = new ConcurrentHashMap<>(PropertiesFileUtils.readPropertiesFileToMap(filePathLinux));
            // filePathConfigMap = new ConcurrentHashMap<>(ReadPropFile.readPropFileToHashMap(filePathLinux));
            for (Map.Entry e: filePathConfigMap.entrySet()) {
                filePathConfigMap.put(e.getKey().toString(),e.getValue().toString());
            }
        }else{
            // filePathConfigMap = new ConcurrentHashMap<>(ReadPropFile.readPropFileToHashMap(filePathWin));
            filePathConfigMap = new ConcurrentHashMap<>(PropertiesFileUtils.readPropertiesFileToMap(filePathWin));
            for (Map.Entry e: filePathConfigMap.entrySet()) {
                if (e.getValue().toString().contains("${USERNAME}")){
                    filePathConfigMap.put(e.getKey().toString(),e.getValue().toString().replace("${USERNAME}",uname));
                }
            }
        }
    }

    public static void createDir(){
        if(os.equalsIgnoreCase("linux") || os.equalsIgnoreCase("mac os x")){
            File f = new File("./Downloads");
            if (f.mkdirs()){
                System.out.println("Directory is created");
            }else{
                System.out.println("Directory is NOT created");
            }
        }else {

        }
    }
}
