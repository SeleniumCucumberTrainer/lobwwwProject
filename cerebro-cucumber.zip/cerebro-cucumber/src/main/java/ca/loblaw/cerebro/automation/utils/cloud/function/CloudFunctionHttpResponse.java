package ca.loblaw.cerebro.automation.utils.cloud.function;

import com.google.api.client.http.HttpResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

/**
 * Wrapper class for Cloud Function response HttpResponse object to parse response.
 */
public class CloudFunctionHttpResponse {

    private final HttpResponse response;

    public CloudFunctionHttpResponse(HttpResponse response) {
        this.response = response;
    }

    public int getStatusCode() {
        return response.getStatusCode();
    }

    public String getStatusMessage() {
        return response.getStatusMessage();
    }

    public String getResponseString() throws IOException {
        // Parse response
        try (InputStream inputStream = response.getContent();
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

            return reader.lines().collect(Collectors.joining("\n"));
        } finally {
            response.disconnect();
        }
    }
}
