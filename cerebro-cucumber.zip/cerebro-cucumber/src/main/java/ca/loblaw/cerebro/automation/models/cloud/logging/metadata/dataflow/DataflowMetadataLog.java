package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.dataflow;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "zone", defaultImpl = DataflowMetadataLog.class)

public class DataflowMetadataLog {
    @JsonProperty("df_file_nbr_cols_imprt")
    private String fileColumnsCount;
    @JsonProperty("df_tgt_ds_nm")
    private String targetDataSourceName;
    @JsonProperty("df_tgt_proj_id")
    private String targetProjectId;
    @JsonProperty("df_file_compression")
    private String fileCompression;
    @JsonProperty("df_file_path")
    private String filePath;
    @JsonProperty("df_file_sz")
    private String fileSize;
    @JsonProperty("df_file_nbrs_err_rows")
    private String errorRows;
    @JsonProperty("df_file_nbrs_rows_parsed")
    private String rowsParsed;
    @JsonProperty("df_job_nm")
    private String jobName;
    @JsonProperty("df_file_hdr_row_ct")
    private String headerCount;
    @JsonProperty("df_file_ty")
    private String fileFormat;
    @JsonProperty("df_src_sys")
    private String sourceSystem;
    @JsonProperty("entity_trace_id")
    private String entityTraceId;
    @JsonProperty("df_istrgrby_composer")
    private String triggeredByComposer;
    @JsonProperty("df_file_nm")
    private String fileName;
    @JsonProperty("df_tgt_tbl_nm")
    private String targetTableName;
    @JsonProperty("job_run_trace_id")
    private List<String> jobRunTraceIds;
    @JsonProperty("df_proj_domain")
    private String domain;
    @JsonProperty("df_proj_sub_domain")
    private String subDomain;

    public String getFileColumnsCount() {
        return fileColumnsCount;
    }

    public DataflowMetadataLog setFileColumnsCount(String fileColumnsCount) {
        this.fileColumnsCount = fileColumnsCount;
        return this;
    }

    public String getTargetDataSourceName() {
        return targetDataSourceName;
    }

    public DataflowMetadataLog setTargetDataSourceName(String targetDataSourceName) {
        this.targetDataSourceName = targetDataSourceName;
        return this;
    }

    public String getTargetProjectId() {
        return targetProjectId;
    }

    public DataflowMetadataLog setTargetProjectId(String targetProjectId) {
        this.targetProjectId = targetProjectId;
        return this;
    }

    public String getFileCompression() {
        return fileCompression;
    }

    public DataflowMetadataLog setFileCompression(String fileCompression) {
        this.fileCompression = fileCompression;
        return this;
    }

    public String getFilePath() {
        return filePath;
    }

    public DataflowMetadataLog setFilePath(String filePath) {
        this.filePath = filePath;
        return this;
    }

    public String getFileSize() {
        return fileSize;
    }

    public DataflowMetadataLog setFileSize(String fileSize) {
        this.fileSize = fileSize;
        return this;
    }

    public String getErrorRows() {
        return errorRows;
    }

    public DataflowMetadataLog setErrorRows(String errorRows) {
        this.errorRows = errorRows;
        return this;
    }

    public String getRowsParsed() {
        return rowsParsed;
    }

    public DataflowMetadataLog setRowsParsed(String rowsParsed) {
        this.rowsParsed = rowsParsed;
        return this;
    }

    public String getJobName() {
        return jobName;
    }

    public DataflowMetadataLog setJobName(String jobName) {
        this.jobName = jobName;
        return this;
    }

    public String getHeaderCount() {
        return headerCount;
    }

    public DataflowMetadataLog setHeaderCount(String headerCount) {
        this.headerCount = headerCount;
        return this;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public DataflowMetadataLog setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
        return this;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public DataflowMetadataLog setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
        return this;
    }

    public String getEntityTraceId() {
        return entityTraceId;
    }

    public DataflowMetadataLog setEntityTraceId(String entityTraceId) {
        this.entityTraceId = entityTraceId;
        return this;
    }

    public String getTriggeredByComposer() {
        return triggeredByComposer;
    }

    public DataflowMetadataLog setTriggeredByComposer(String triggeredByComposer) {
        this.triggeredByComposer = triggeredByComposer;
        return this;
    }

    public String getFileName() {
        return fileName;
    }

    public DataflowMetadataLog setFileName(String fileName) {
        this.fileName = fileName;
        return this;
    }

    public String getTargetTableName() {
        return targetTableName;
    }

    public DataflowMetadataLog setTargetTableName(String targetTableName) {
        this.targetTableName = targetTableName;
        return this;
    }

    public List<String> getJobRunTraceIds() {
        return jobRunTraceIds;
    }

    public DataflowMetadataLog setJobRunTraceId(List<String> jobRunTraceIds) {
        this.jobRunTraceIds = jobRunTraceIds;
        return this;
    }

    public String getDomain() {
        return domain;
    }

    public DataflowMetadataLog setDomain(String domain) {
        this.domain = domain;
        return this;
    }

    public String getSubDomain() {
        return subDomain;
    }

    public DataflowMetadataLog setSubDomain(String subDomain) {
        this.subDomain = subDomain;
        return this;
    }
}
