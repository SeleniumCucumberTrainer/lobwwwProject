package ca.loblaw.cerebro.automation.component.cloud.composer;

/**
 * Apache Airflow states for DAGs and task instances.
 */
public enum AirflowState {
    SUCCESS("success"),
    FAILED("failed"),
    RUNNING("running"),
    QUEUED("queued"),
    SCHEDULED("scheduled"),
    SKIPPED("skipped"),
    UPSTREAM_FAILED("upstream_failed");

    private final String state;

    AirflowState(String state) {
        this.state = state;
    }

    public static AirflowState from(String stateValue) {
        if (stateValue == null) {
            return null;
        }

        for (AirflowState airflowState : AirflowState.values()) {
            if (airflowState.getState().equals(stateValue)) {
                return airflowState;
            }
        }

        throw new EnumConstantNotPresentException(AirflowState.class, stateValue);
    }

    public String getState() {
        return state;
    }

    @Override
    public String toString() {
        return this.state;
    }
}
