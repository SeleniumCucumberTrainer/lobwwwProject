package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowResponseError extends AirflowResponseItem {

    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("error")
    private AirflowResponseErrorItem error;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public AirflowResponseErrorItem getError() {
        return error;
    }

    public void setError(AirflowResponseErrorItem error) {
        this.error = error;
    }
}
