package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

public class IngestionTasks {

    public static final String GENERATE_JOB_RUN_TRACE_ID = "generate_job_run_trace_id";
    public static final String NOTHING_IN_LANDING_METADATA_LOG = "nothing_in_landing_metadata_log";
    public static final String MOVE_TO_WORKING = "move_to_working";
    public static final String GET_CURRENT_TIMESTAMP = "get_current_timestamp";
    public static final String GET_TABLES = "get_tables";
    public static final String TRIGGER_DATAFLOW_JOB = "trigger_dataflow_job";
    public static final String MOVE_TO_PROCESSED = "move_to_processed";
    public static final String MOVE_TO_REJECTED = "move_to_rejected";
    public static final String INSERT_FLOW_CONTROL = "insert_flow_control";
    public static final String METADATA_LOG = "metadata_log";
    public static final String TRIGGER_DAG = "trigger_";
}
