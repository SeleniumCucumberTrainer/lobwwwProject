package ca.loblaw.cerebro.automation.testcases.cloudcomposer;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute.ComposerTechComputeSmokeFactory;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.internal.ExcelReader;
import ca.loblaw.cerebro.automation.utils.reports.excel.ComposerDagRunExcelReportGenerator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Factory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;

public class ComposerSmokeFactory {

    private static final Logger LOG = LogManager.getLogger(ComposerTechComputeSmokeFactory.class);
    private static final ConcurrentHashMap<String, ConcurrentLinkedQueue<DagRun>> DAG_RUNS_FACTORY_MAP = new ConcurrentHashMap<>();

    // Factory details
    private final String inputExcelPath;
    private final String outputExcelName;
    private final String inputSheetName;
    private final Project project;

    public ComposerSmokeFactory(Project project, String inputExcelPath, String outputExcelName, String inputSheetName) {
        this.project = project;
        this.inputExcelPath = inputExcelPath;
        this.outputExcelName = outputExcelName;
        this.inputSheetName = inputSheetName;
    }

    public static ConcurrentLinkedQueue<DagRun> getDagRunsQueue(String sheetName) {
        return DAG_RUNS_FACTORY_MAP.get(sheetName);
    }

    @Factory
    public Object[] createComposerTechComputeSmokeTests() {
        List<Row> dagRows = ExcelReader.getRows(inputExcelPath, inputSheetName);

        DAG_RUNS_FACTORY_MAP.put(inputSheetName, new ConcurrentLinkedQueue<>());

        return dagRows.stream()
                .skip(1) // Skip column header
                .map(row -> row.getCell(0).getStringCellValue())
                .filter(dagId -> !dagId.isEmpty())
                .map(dagId -> ComposerSmokeTest.fromProject(project, dagId, inputSheetName))
                .toArray();
    }

    @AfterSuite(alwaysRun = true)
    public void composer_smoke_factory_after_suite() throws IOException {
        LOG.info("Generating {} result excel", outputExcelName);

        List<String> dagRunHeaders = Arrays.asList("DAG ID", "Is Paused", "DAG Run ID", "State",
                "Error", "Has Metadata", "Parent DAG", "Tasks Instances");

        ComposerDagRunExcelReportGenerator composerDagRunExcelReportGenerator = new ComposerDagRunExcelReportGenerator();
        composerDagRunExcelReportGenerator.setReportPath("composer-reports/", outputExcelName);

        // Create Excel sheet for each DAG runs queue
        for (String sheetName : DAG_RUNS_FACTORY_MAP.keySet()) {
            LOG.info("DAG runs for '{}' has size {}", sheetName, DAG_RUNS_FACTORY_MAP.get(sheetName).size());
            List<DagRun> totalDags = DAG_RUNS_FACTORY_MAP.get(sheetName).stream()
                    .sorted(Comparator.comparing(DagRun::getDagId))
                    .collect(Collectors.toList());
            Set<DagRun> checkedDags = new HashSet<>();
            List<DagRun> excelResultDags = new ArrayList<>();

            for (DagRun dagRun : totalDags) {
                if (!dagRun.hasUpstreamDag()) {
                    exportDownstreamDags(checkedDags, excelResultDags, dagRun);
                }
            }

            composerDagRunExcelReportGenerator.setSheetName(sheetName);
            composerDagRunExcelReportGenerator.reportResults(dagRunHeaders, excelResultDags);
        }

        composerDagRunExcelReportGenerator.writeToFileAndClose();
    }

    private void exportDownstreamDags(Set<DagRun> checkedDags, List<DagRun> excelResultDags, DagRun dagRun) {
        if (checkedDags.contains(dagRun)) {
            return;
        }

        // Add to result list and report downstream DAGs
        excelResultDags.add(dagRun);
        checkedDags.add(dagRun);
        for (DagRun downstreamDagRun: dagRun.getDownstreamDags()) {
            exportDownstreamDags(checkedDags, excelResultDags, downstreamDagRun);
        }
    }
}
