package ca.loblaw.cerebro.automation.utils.command;

import ca.loblaw.cerebro.automation.utils.contexts.OperatingSystem;
import ca.loblaw.cerebro.automation.utils.contexts.OperatingSystemContext;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * CommandLineExecutor is a utility class that runs preset command-line commands in a new process.
 */
public class CommandLineExecutor {

    private static final Logger LOG = LogManager.getLogger(CommandLineExecutor.class);
    private static final String COMMANDS_PATH = "src/main/resources/configs/CommandLineScripts.properties";

    // Map of all available commands
    private static ConcurrentHashMap<String, String> COMMANDS_MAP;

    private CommandLineExecutor() {}

    public static void setCommandLineScripts() throws IOException {
        COMMANDS_MAP = new ConcurrentHashMap<>(PropertiesFileUtils.readPropertiesFileToMap(COMMANDS_PATH));
    }

    /**
     * Activates a service account to be used for future google cloud related commands.
     * @param serviceAccountEmail Service account email.
     * @param serviceAccountJsonFile Path to service account JSON file.
     * @param projectId Google Cloud project ID associated with service account.
     * @return Command line output.
     * @throws IOException IO error starting process.
     * @throws InterruptedException Process thread interrupted while waiting.
     */
    public static CommandLineOutput activateServiceAccount(String serviceAccountEmail, String serviceAccountJsonFile, String projectId) throws IOException, InterruptedException {
        String command = String.format(COMMANDS_MAP.get("activateServiceAccount"), serviceAccountEmail, serviceAccountJsonFile, projectId);
        return executeCommand(command);
    }

    private static CommandLineOutput executeCommand (String command) throws IOException, InterruptedException {
        LOG.info("Executing: {}", command);

        // Execute process
        ProcessBuilder processBuilder = new ProcessBuilder();
        if (OperatingSystemContext.OS.equals(OperatingSystem.LINUX) || OperatingSystemContext.OS.equals(OperatingSystem.MAC)) {
            processBuilder.command("/bin/bash", "-c", command);
        } else {
            processBuilder.command("cmd", "/c", command);
        }
        Process process = processBuilder.start();

        // Get process results
        int exitStatus = process.waitFor();
        BufferedReader inputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
        List<String> inputList = inputReader.lines().collect(Collectors.toList());
        List<String> errorList = errorReader.lines().collect(Collectors.toList());

        if (exitStatus == 0) { // Success
            LOG.info("Execution success");
        } else {
            LOG.error("Execution failed");
        }

        return new CommandLineOutput(exitStatus, inputList, errorList);
    }
}
