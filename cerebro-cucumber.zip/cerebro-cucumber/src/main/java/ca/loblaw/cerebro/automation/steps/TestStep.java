package ca.loblaw.cerebro.automation.steps;

/**
 * Any class defining this interface represents a common test step used across multiple test suites.
 * Classes are expected to maintain state to be used across multiple test methods.
 */
public interface TestStep {
}
