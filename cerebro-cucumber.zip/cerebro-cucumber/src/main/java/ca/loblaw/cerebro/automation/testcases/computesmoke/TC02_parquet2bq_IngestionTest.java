package ca.loblaw.cerebro.automation.testcases.computesmoke;

import ca.loblaw.cerebro.automation.testcases.techcomputesmoke.parquet2bq_IngestionTestSteps;
import org.testng.annotations.Test;

import java.io.IOException;


@Test(groups = {"Smoke"})
public class TC02_parquet2bq_IngestionTest extends TechComputeCommonFun {
    public TC02_parquet2bq_IngestionTest() throws IOException {
        super("TC02_parquet2bq_ingestionTestData.properties");

    }
}


