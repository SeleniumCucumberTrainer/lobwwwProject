package ca.loblaw.cerebro.automation.steps.endtoend;

import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.cloud.dataflow.DataflowService;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.dataflow.v1beta3.Job;
import com.google.dataflow.v1beta3.JobMetrics;
import com.google.dataflow.v1beta3.JobState;
import com.google.dataflow.v1beta3.MetricUpdate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DataflowJobValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(DataflowJobValidator.class);

    public static class DataflowResults {
        private final int recordCount;
        private final int errorCount;

        public DataflowResults(int recordCount, int errorCount) {
            this.recordCount = recordCount;
            this.errorCount = errorCount;
        }

        public int getRecordCount() {
            return recordCount;
        }

        public int getErrorCount() {
            return errorCount;
        }
    }

    public static void validateDataflowJob(String dataflowJobId) throws IOException {
        Job dataflowJob = DataflowService.getDataflowJob(
                Project.TECHCOMPUTE_ZONE.getName(),
                "northamerica-northeast1",
                dataflowJobId
        );

        Assertions.assertThat(dataflowJob)
                .as("Dataflow job exists", dataflowJobId)
                .isNotNull();
        Reporter.pass(LOG, "Dataflow job exists");

        Assertions.assertThat(dataflowJob.getCurrentState())
                .as("Dataflow job state")
                .isEqualTo(JobState.JOB_STATE_DONE);
        Reporter.pass(LOG, "Dataflow job passed");
    }

    public static DataflowResults validateAndReturnDataflowMetrics(String dataflowJobId, String recordTask, List<String> errorTasks, int tableRecordCount) {
        JobMetrics dataflowJobMetrics = DataflowService.getDataflowJobMetrics(
                Project.TECHCOMPUTE_ZONE.getName(),
                "northamerica-northeast1",
                dataflowJobId
        );
        assert dataflowJobMetrics != null;

        // Dataflow results count
        int dataflowRecordCount = 0;
        int dataflowErrorCount = 0;

        Set<String> taskSet = new HashSet<>(); // Set to prevent adding count to duplicate tasks in metrics

        // Parse metrics
        for (MetricUpdate update : dataflowJobMetrics.getMetricsList()) {
            String updateName = update.getName().getName();
            String contextValue = update.getName().getContextMap().get("output_user_name");

            if (updateName.equals("ElementCount")) {
                if (contextValue.startsWith(recordTask) && !taskSet.contains(recordTask)) {
                   dataflowRecordCount = (int) update.getScalar().getNumberValue();
                   taskSet.add(recordTask);
                   continue;
                }

                for (String errorTask : errorTasks) {
                    if (contextValue.startsWith(errorTask) && !taskSet.contains(errorTask)) {
                        dataflowErrorCount += (int) update.getScalar().getNumberValue();
                        taskSet.add(errorTask);
                    }
                }
            }
        }

        Reporter.info(LOG, "Number of elements processed by Dataflow is {}", dataflowRecordCount);
        Reporter.info(LOG, "Number of error elements in Dataflow is {}", dataflowErrorCount);

        Assertions.assertThat(dataflowRecordCount)
                .as("Elements written to BQ compared to number of records inserted in BQ")
                .isEqualTo(tableRecordCount);
        Reporter.pass(LOG, "Element written to BQ is the same as number of records inserted in BQ");

        return new DataflowResults(dataflowRecordCount, dataflowErrorCount);
    }
}
