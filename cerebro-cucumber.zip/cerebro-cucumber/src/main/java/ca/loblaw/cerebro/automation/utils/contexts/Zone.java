package ca.loblaw.cerebro.automation.utils.contexts;

/**
 * Available Cerebro zones.
 */
public enum Zone {
    TEC("tec"),
    FUL("ful");

    public static Zone from(String str) {
        for (Zone zone : Zone.values()) {
            if (zone.value.equals(str)) {
                return zone;
            }
        }
        throw new EnumConstantNotPresentException(Zone.class, str);
    }

    private String value;

    Zone(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
