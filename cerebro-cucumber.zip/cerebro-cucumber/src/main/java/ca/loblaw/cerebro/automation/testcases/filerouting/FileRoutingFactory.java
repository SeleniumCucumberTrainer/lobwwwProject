package ca.loblaw.cerebro.automation.testcases.filerouting;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Factory;

import java.io.IOException;

public class FileRoutingFactory {

    private static final String LANDING_CONFIG_PATH = "src/main/resources/setup/filerouting/LandingConfig.json";

    @Factory
    public Object[] createFileRoutingTests() throws IOException {
        ArrayNode pipelinesNode = (ArrayNode) JsonUtils.readToJsonObject(LANDING_CONFIG_PATH);

        Object[] testInstances = new Object[pipelinesNode.size()];

        // Parse for data provider
        for (int pipelineIndex = 0; pipelineIndex < pipelinesNode.size(); pipelineIndex++) {
            JsonNode pipelineNode = pipelinesNode.get(pipelineIndex);

            JsonNode source = pipelineNode.get("source");
            String sourceBucket = source.get("bucket").asText();
            String sourceFolder = source.get("folder").asText();

            JsonNode target = pipelineNode.get("target");
            String targetBucket = TestContext.replaceTemplateEnv(target.get("bucket").asText());
            String targetFolder = target.get("folder").asText();

            JsonNode copy = pipelineNode.get("copy");
            String copyBucket = TestContext.replaceTemplateEnv(copy.get("bucket").asText());
            String copyFolder = copy.get("folder").asText();

            Assertions.assertThat(copyBucket).matches("cerebro-\\w{3}-tec-testing");
            Assertions.assertThat(sourceBucket).isEqualTo("cerebro-prd-landing-qa");
            Assertions.assertThat(sourceFolder).as(String.format("%s should equal %s", sourceFolder, copyFolder)).isEqualTo(copyFolder);
            Assertions.assertThat(targetBucket).startsWith("cerebro-" + TestContext.ENV + "-raw");

            // Data name
            String dataName = sourceFolder.replace("/", " - ");

            // Folders
            String landingFolderPath = String.format("gs://%s/%s/", sourceBucket, sourceFolder);
            String rawFolderPath = String.format("gs://%s/%s/", targetBucket, targetFolder);
            String testFolderPath = String.format("gs://%s/sample-landing-files/%s/", copyBucket, copyFolder);

            testInstances[pipelineIndex] = new FileRoutingTest(dataName, landingFolderPath, rawFolderPath, testFolderPath);
        }

        return testInstances;
    }
}
