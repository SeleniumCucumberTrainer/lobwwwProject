package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public class AirflowResponseTask extends AirflowResponseItem {

    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("dag_run_id")
    private String dagRunId;

    @JsonProperty("state")
    private String taskState;

    @JsonProperty("task_id")
    private String taskId;

    @JsonProperty("start_date")
    private String startDate;

    @JsonProperty("end_date")
    private String endDate;

    @JsonProperty("kwargs")
    private Map<String, Object> keywordArguments;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public String getTaskState() {
        return taskState;
    }

    public void setTaskState(String taskState) {
        this.taskState = taskState;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Map<String, Object> getKeywordArguments() {
        return keywordArguments;
    }

    public void setKeywordArguments(Map<String, Object> keywordArguments) {
        this.keywordArguments = keywordArguments;
    }
}
