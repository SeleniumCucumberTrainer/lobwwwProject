package ca.loblaw.cerebro.automation.testcases.techcomputesmoke;

import org.testng.annotations.Test;


@Test(groups = {"Smoke"})
public class TC02_parquet2bq_IngestionTest extends parquet2bq_IngestionTestSteps {

}


