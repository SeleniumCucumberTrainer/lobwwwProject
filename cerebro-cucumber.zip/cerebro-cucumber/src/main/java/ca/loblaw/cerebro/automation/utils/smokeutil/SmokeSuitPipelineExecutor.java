package ca.loblaw.cerebro.automation.utils.smokeutil;

import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunction;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunctionHttpResponse;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import ca.loblaw.cerebro.automation.utils.internal.bash.BashOutput;
import ca.loblaw.cerebro.automation.utils.internal.bash.BashUtils;
import com.google.dataflow.v1beta3.GetJobRequest;
import com.google.dataflow.v1beta3.Job;
import com.google.dataflow.v1beta3.JobsV1Beta3Client;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmokeSuitPipelineExecutor {
    private static final long DEFAULT_WAIT_TIME = 20 * 60 * 1000;
    private static final int FIRST_JOB_ROW = 1;
    private static final long MAX_WAIT_FOR_JOB_ID = 150000;
    private static final long REFRESH_TIME = 5000;
    private String jobName;
    private String runtimeArgs;
    private String jarName;
    private String mainClass;
    private CloudFunction smokeFunction;
    public static List<String> completedPipelines = new ArrayList<>();
    private static final String JOB_STATE_PENDING = "PENDING";
    private static final String JOB_STATE_RUNNING = "RUNNING";
    private String JOB_STATE_DONE = "DONE";
    private static final String JOB_STATE_FAILED = "FAILED";
    private Date executionDate;

    public SmokeSuitPipelineExecutor(String args, String mainClass, String jarName, String jobName) {
        this.runtimeArgs = args;
        this.mainClass = mainClass;
        this.jarName = jarName;
        this.jobName = jobName;
    }


    public SmokeSuitPipelineExecutor setupCloudFunction(String project, String region, String functionName) throws IOException {
        smokeFunction = new CloudFunction.Builder()
                .setProject(project)
                .setRegion(region)
                .setFunctionName(functionName)
                .build();
        return this;
    }

    public CloudFunctionHttpResponse trigger() throws IOException {
        setExecutionDate(new Date());
        return smokeFunction.trigger(getPayloadString());
    }
    /***
     * Builds a JSON payload with 'jarLocation' and 'pipelineCommand' java jar command variables
     * @return Payload map
     */
    private Map<String, String> buildPayload() {
        Map<String, String> payload = new HashMap<>();

        String command = getPipelineCommand();
        payload.put("pipelineCommand", command.trim());

        String latestJar = CloudStorageUtils.getLatestJar(jarName);
        payload.put("jarLocation", latestJar);

        payload.put("pipelineName", jobName);
        return payload;
    }
    private String getPayloadString() {
        StringBuilder jsonPayload = new StringBuilder();
        for (Map.Entry<String, String> entry : buildPayload().entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            jsonPayload.append(",\"").append(key).append("\"");
            if (value.startsWith("[") || value.startsWith("{")) {

                jsonPayload.append(":").append(value);
            } else {
                jsonPayload.append(":\"").append(value).append("\"");
            }
        }

        if (!jsonPayload.toString().isEmpty()) {
            jsonPayload.insert(0, "{").append("}");
        }

        return jsonPayload.toString().replaceFirst(",", "").trim();
    }

    private String getPipelineCommand() {
        Map<String, String> argMap;
        try {
            argMap = PropertiesFileUtils.readPropFileUpdateConfigParam(this.runtimeArgs);
        } catch (IOException e) {
            System.out.println("Failed when reading runtime args config file");
            throw new RuntimeException(e);
        }

        StringBuilder sb = new StringBuilder();
        for (String key : argMap.keySet()) {
            String arg = argMap.get(key);
            if (key.contains("jobName")) {
                this.jobName = arg + "-" + jobName.replace("_", "-");
                sb.append("--").append(key).append("=").append(jobName).append(" ");
            } else if (key.contains("recCreTms")) {
                Date date = new Date();
                final SimpleDateFormat sdf =
                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

                sb.append("--").append(key).append("=").append(arg.replace("2022-08-23 17:12:31.781", sdf.format(date)).replace("\"", "'")).append(" ");
            } else
                sb.append("--").append(key).append("=").append(arg).append(" ");
        }

        return "java -jar ${JAR_PATH} " + mainClass + " " + sb;
    }

    public boolean waitFor() {
        String jobId = getJobId(jobName);

        if (jobId.isEmpty()) {
            System.out.println("Cannot find job id");
            return false;
        }

        try (JobsV1Beta3Client client = JobsV1Beta3Client.create()) {
            GetJobRequest request = GetJobRequest.newBuilder()
                    .setProjectId(smokeFunction.getProject())
                    .setLocation(smokeFunction.getRegion())
                    .setJobId(jobId)
                    .build();

            long startTime = System.currentTimeMillis();
            String state = "";
            while (System.currentTimeMillis() - startTime <= DEFAULT_WAIT_TIME) {
                Job job = client.getJob(request);

                state = job.getCurrentState().toString();
                if (state.contains(JOB_STATE_PENDING) || state.contains(JOB_STATE_RUNNING)) {
                    System.out.println("Waiting " + jobName + " to complete. Current state: " + state);
                    Thread.sleep(60000);
                    continue;
                }
                break;
            }
            System.out.println("Job " + jobName + " completed with state: " + state);
            if (state.contains(JOB_STATE_DONE)) {
                return true;
            }
        } catch (Exception e) {
            return false;
        }

        return false;
    }

    private BashOutput getJobState(String jobId) {
        String command = String.format("gcloud dataflow jobs describe " + jobId + " --region=northamerica-northeast1");
        try {
            return BashUtils.checkStatus(command);
        } catch (Exception e) {
            System.out.println("Failed when getting job state");
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    private String getJobId(String jobName) {
        Date date = getExecutionDate();
        final SimpleDateFormat sdf =
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        String today = sdf.format(date);
//        String command = "gcloud dataflow jobs list --project=" + getProject() + " --region=northamerica-northeast1 --status=active --filter=\"name=" + jobName + "\" --filter=\"creationTime>=" + today + "\"";
//        String command = "gcloud dataflow jobs list --project=" + getProject() + " --region=northamerica-northeast1 --status=active --filter=\"name=" + jobName + "\"";
        String command = "gcloud dataflow jobs list --project=" + smokeFunction.getProject() + " --region=northamerica-northeast1 --status=active --filter=\"name=" + jobName + "\" --created-after=" + today;

        try {
            String jobId = "";
            long startTime = System.currentTimeMillis();
            do {
                BashOutput output = BashUtils.setVars(command);

                if (output.getOutput().size() == 2) {
                    jobId = output.getOutput().get(FIRST_JOB_ROW).split(" ")[0];
                    Pattern pattern = Pattern.compile("[0-9-_]+", Pattern.CASE_INSENSITIVE);
                    Matcher matcher = pattern.matcher(jobId);

                    if (!matcher.find()) continue;

                    System.out.println("Job " + this.jobName + " started successfully.");

                    break;
                }
                Thread.sleep(REFRESH_TIME);
            } while (System.currentTimeMillis() - startTime <= MAX_WAIT_FOR_JOB_ID);

            return jobId;
        } catch (Exception e) {
            System.out.println("Failed to get job id.");
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
    private Date getExecutionDate(){
        return this.executionDate;
    }

    private void setExecutionDate(Date date){
        this.executionDate = date;
    }
}
