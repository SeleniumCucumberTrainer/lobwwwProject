package ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable;

public class Column {
    private String name;
    private String dataType;
    private Partitioned isPartitioningColumn;

    public enum Partitioned {
        YES,
        NO;

        public String getPartitioned() {
            return this.name();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public Partitioned getIsPartitioningColumn() {
        return isPartitioningColumn;
    }

    public void setIsPartitioningColumn(Partitioned isPartitioningColumn) {
        this.isPartitioningColumn = isPartitioningColumn;
    }
}
