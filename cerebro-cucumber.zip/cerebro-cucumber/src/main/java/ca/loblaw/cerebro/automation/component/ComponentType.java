package ca.loblaw.cerebro.automation.component;

public enum ComponentType {
    CLOUD_FUNCTION,
    CLOUD_COMPOSER,
    DATAFLOW_JOB
}
