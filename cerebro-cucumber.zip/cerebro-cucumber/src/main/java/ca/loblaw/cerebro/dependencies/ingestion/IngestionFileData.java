package ca.loblaw.cerebro.dependencies.ingestion;

public class IngestionFileData {

    private static ThreadLocal<String> inboundFilePath = new ThreadLocal<>();

    private String ingestionFile;

    public String getInboundFilePath() {
        return inboundFilePath.get();
    }

    public void setInboundFilePath(String inboundFilePath) {
        IngestionFileData.inboundFilePath.set(inboundFilePath);
    }

    public String getIngestionFile() {
        return ingestionFile;
    }

    public void setIngestionFile(String ingestionFile) {
        this.ingestionFile = ingestionFile;
    }
}
