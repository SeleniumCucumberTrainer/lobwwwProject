package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;


import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;

/**
 * Handles an Airflow response to update a DagRun
 */
public interface AirflowUpdateHandler {
    void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun);
}
