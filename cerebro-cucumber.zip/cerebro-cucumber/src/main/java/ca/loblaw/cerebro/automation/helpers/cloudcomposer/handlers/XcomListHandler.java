package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseXcomList;

public class XcomListHandler implements AirflowUpdateHandler {
    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseXcomList responseXcomList = (AirflowResponseXcomList) airflowResponseItem;

        String taskId = responseXcomList.getTaskId();

        // Store available XCOM variables
        dagRun.getTaskInstance(taskId).createXcomVariables(responseXcomList.getXcomEntries());
    }
}
