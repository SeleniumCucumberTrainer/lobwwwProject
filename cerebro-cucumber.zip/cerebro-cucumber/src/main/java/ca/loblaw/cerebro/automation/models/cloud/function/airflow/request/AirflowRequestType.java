package ca.loblaw.cerebro.automation.models.cloud.function.airflow.request;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum AirflowRequestType {
    @JsonProperty("trigger")
    TRIGGER,
    @JsonProperty("unpause")
    UNPAUSE,
    @JsonProperty("info")
    INFO,
    @JsonProperty("list_tasks")
    LIST_TASKS,
    @JsonProperty("task_instances")
    TASK_INSTANCES,
    @JsonProperty("start_date")
    START_DATE,
    @JsonProperty("recent")
    RECENT,
    @JsonProperty("logs")
    LOGS,
    @JsonProperty("list_dags")
    LIST_DAGS,
    @JsonProperty("xcom_list")
    XCOM_LIST,
    @JsonProperty("xcom")
    XCOM
}
