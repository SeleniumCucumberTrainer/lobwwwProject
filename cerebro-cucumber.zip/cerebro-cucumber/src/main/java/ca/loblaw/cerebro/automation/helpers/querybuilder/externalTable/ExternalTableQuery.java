package ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable;

import ca.loblaw.cerebro.automation.helpers.querybuilder.Query;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class ExternalTableQuery implements Query {
    private String tableName;
    private List<Column> columns;
    private List<CloudStorageFile> fileURIs;
    private FileFormat fileFormat;
    private Character delimiter;
    private boolean hasHeader = false;
    private int maxBadRecords = 0;

    // Setters
    public ExternalTableQuery setTableName(String tableName) {
        this.tableName = tableName;
        return this;
    }

    public ExternalTableQuery setColumns(List<Column> columns) {
        this.columns = columns;
        return this;
    }

    public ExternalTableQuery setFileFormat(FileFormat fileFormat) {
        this.fileFormat = fileFormat;
        return this;
    }

    public ExternalTableQuery setDelimiter(Character delimiter) {
        this.delimiter = delimiter;
        return this;
    }

    public ExternalTableQuery setHasHeader(Boolean hasHeader) {
        this.hasHeader = hasHeader;
        return this;
    }

    public ExternalTableQuery setFileURIs(List<CloudStorageFile> fileURIs) {
        this.fileURIs = fileURIs;
        return this;
    }

    public ExternalTableQuery setMaxBadRecords(int maxBadRecords) {
        this.maxBadRecords = maxBadRecords;
        return this;
    }

    public String getTableName() {
        return tableName;
    }

    public List<Column> getColumns() {
        return columns;
    }

    public FileFormat getFileFormat() {
        return fileFormat;
    }

    public Character getDelimiter() {
        return delimiter;
    }

    public Boolean getHasHeader() {
        return hasHeader;
    }

    public List<CloudStorageFile> getFileURIs() {
        return fileURIs;
    }
    public int getMaxBadRecords() {
        return maxBadRecords;
    }

    // Parsers
    private String parseTableName() {
        assert tableName != null && !tableName.isEmpty();

        return tableName;
    }

    private String parseFileURIs() {
        assert fileURIs != null && !fileURIs.isEmpty();

        StringBuilder URIsString = new StringBuilder();

        URIsString.append("uris=[");
        for (CloudStorageFile file : fileURIs) {
            URIsString.append(",").append("\"").append(file.getName()).append("\"");
        }
        URIsString.append("]");

        return StringUtils.replaceOnce(URIsString.toString(), ",", "");
    }

    private String parseFileFormat() {
        assert fileFormat != null;

        return "format=\"" + fileFormat.getFormat() + "\"";
    }

    private String parseSkipLeadingRow() {

        return "skip_leading_rows=" + (hasHeader ? 1 : 0);
    }

    private String parseDelimiter() {
        assert delimiter != null;

        return "field_delimiter=\"" + delimiter + "\"";
    }

    private String parseColumns() {
        assert columns != null && !columns.isEmpty();

        StringBuilder columnsString = new StringBuilder();
        for (Column column : columns) {
            columnsString.append(", ").append(column.getName()).append(" ").append(column.getDataType());
        }

        return StringUtils.replaceOnce(columnsString.toString(), ", ", "");
    }

    private String parseMaxBadRecords() {
        return "max_bad_records=" + maxBadRecords;
    }

    @Override
    public String build() {
        StringBuilder externalTableQuery = new StringBuilder();

        // Table name
        externalTableQuery.append("CREATE OR REPLACE EXTERNAL TABLE `").append(parseTableName()).append("`\n");

        // Columns
        externalTableQuery.append("(").append(parseColumns()).append(")\n");

        // Options
        externalTableQuery.append("OPTIONS(");
        externalTableQuery.append("\n\t").append(parseFileFormat()).append(",");
        externalTableQuery.append("\n\t").append(parseFileURIs()).append(",");
        externalTableQuery.append("\n\t").append(parseMaxBadRecords());

        if(fileFormat.equals(FileFormat.CSV) && delimiter != null) {
            externalTableQuery.append(",\n\t").append(parseDelimiter()).append(",");
            externalTableQuery.append("\n\t").append(parseSkipLeadingRow());
        }

        externalTableQuery.append("\n)");

        return externalTableQuery.toString();
    }
}
