package ca.loblaw.cerebro.automation.testcases.endtoend;

import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "SAP", "EndToEnd" })
public class SAP_LFA1_Test extends EndToEndTest {
    public SAP_LFA1_Test() throws IOException {
        super(
                "src/main/resources/setup/endtoend/sap_lfa1.properties",
                "src/main/resources/setup/endtoend/cleanup/sap_lfa1.sql"
        );
    }
}
