package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CurationComposerMetadataLog extends ComposerMetadataLog {

    @JsonProperty("cc_src_nm")
    private String sourceName;

    @JsonProperty("cc_tgt_nm")
    private String targetName;

    @JsonProperty("cc_no_rows_loaded")
    private String numberRowLoaded;

    // Dataflow
    @JsonProperty("df_job_nm")
    private String dataflowJobName;

    @JsonProperty("df_job_run_id")
    private String dataflowJobRunId;

    @JsonProperty("df_job_execution_strt_tms")
    private String dataflowJobExecutionStartTime;

    @JsonProperty("df_job_execution_end_tms")
    private String dataflowJobExecutionEndTime;

    @JsonProperty("df_job_elpsd_tms")
    private String dataflowJobElapsedTime;

    @JsonProperty("df_execution_rslt")
    private String dataflowJobResult;

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
    }

    public String getNumberRowLoaded() {
        return numberRowLoaded;
    }

    public void setNumberRowLoaded(String numberRowLoaded) {
        this.numberRowLoaded = numberRowLoaded;
    }

    public String getDataflowJobName() {
        return dataflowJobName;
    }

    public void setDataflowJobName(String dataflowJobName) {
        this.dataflowJobName = dataflowJobName;
    }

    public String getDataflowJobRunId() {
        return dataflowJobRunId;
    }

    public void setDataflowJobRunId(String dataflowJobRunId) {
        this.dataflowJobRunId = dataflowJobRunId;
    }

    public String getDataflowJobExecutionStartTime() {
        return dataflowJobExecutionStartTime;
    }

    public void setDataflowJobExecutionStartTime(String dataflowJobExecutionStartTime) {
        this.dataflowJobExecutionStartTime = dataflowJobExecutionStartTime;
    }

    public String getDataflowJobExecutionEndTime() {
        return dataflowJobExecutionEndTime;
    }

    public void setDataflowJobExecutionEndTime(String dataflowJobExecutionEndTime) {
        this.dataflowJobExecutionEndTime = dataflowJobExecutionEndTime;
    }

    public String getDataflowJobElapsedTime() {
        return dataflowJobElapsedTime;
    }

    public void setDataflowJobElapsedTime(String dataflowJobElapsedTime) {
        this.dataflowJobElapsedTime = dataflowJobElapsedTime;
    }

    public String getDataflowJobResult() {
        return dataflowJobResult;
    }

    public void setDataflowJobResult(String dataflowJobResult) {
        this.dataflowJobResult = dataflowJobResult;
    }
}
