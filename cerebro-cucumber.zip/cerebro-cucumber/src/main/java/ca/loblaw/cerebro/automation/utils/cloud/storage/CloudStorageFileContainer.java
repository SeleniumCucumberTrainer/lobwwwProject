package ca.loblaw.cerebro.automation.utils.cloud.storage;

import org.apache.commons.io.FilenameUtils;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Wrapper class for a list of CloudStorageFile(s) used for sorting.
 */
public class CloudStorageFileContainer {

    private final List<CloudStorageFile> cloudStorageFileList;

    private CloudStorageFileContainer(List<CloudStorageFile> cloudStorageFileList) {
        this.cloudStorageFileList = cloudStorageFileList;
    }

    public static CloudStorageFileContainer wrap(List<CloudStorageFile> cloudStorageFileList) {
        return new CloudStorageFileContainer(cloudStorageFileList);
    }

    public List<CloudStorageFile> getCloudStorageFileList() {
        return cloudStorageFileList;
    }

    public List<String> toGcsNamesList() {
        return cloudStorageFileList
                .stream()
                .map(file -> file.getName())
                .collect(Collectors.toList());
    }

    public List<String> toFileNamesList() {
        return cloudStorageFileList
                .stream()
                .map(file -> FilenameUtils.getName(file.getName()))
                .collect(Collectors.toList());
    }

    public List<Long> toSizeList() {
        return cloudStorageFileList
                .stream()
                .map(file -> file.getSize())
                .collect(Collectors.toList());
    }

    public List<Long> toCreateTimeList() {
        return cloudStorageFileList
                .stream()
                .map(file -> file.getCreateTime())
                .collect(Collectors.toList());
    }

    /**
     * Sort list of CloudStorageFile(s) by name.
     *
     * @param isAscending If sort by ascending.
     * @return Current CloudStorageFileContainer object.
     */
    public CloudStorageFileContainer sortByName(boolean isAscending) {
        if(isAscending) {
            Collections.sort(cloudStorageFileList);
        } else {
            Collections.sort(cloudStorageFileList, Collections.reverseOrder());
        }

        return this;
    }

    /**
     * Sort list of CloudStorageFile(s) by create time.
     *
     * @param isAscending If sort by ascending.
     * @return Current CloudStorageFileContainer object.
     */
    public CloudStorageFileContainer sortByCreateTime(boolean isAscending) {
        Collections.sort(cloudStorageFileList, createCloudStorageFileComparator("createTime", isAscending));
        return this;
    }

    /**
     * Sort list of CloudStorageFile(s) by size.
     *
     * @param isAscending If sort by ascending.
     * @return Current CloudStorageFileContainer object.
     */
    public CloudStorageFileContainer sortBySize(boolean isAscending) {
        Collections.sort(cloudStorageFileList, createCloudStorageFileComparator("size", isAscending));
        return this;
    }

    private Comparator createCloudStorageFileComparator(String type, boolean isAscending) {
        Comparator cloudStorageFileComparator;

        if(type.equals("createTime")) {
            cloudStorageFileComparator = new CloudStorageFile.CreateTimeComparator();
        } else if (type.equals("size")) {
            cloudStorageFileComparator = new CloudStorageFile.SizeComparator();
        } else {
            throw new RuntimeException();
        }

        if(!isAscending) {
            cloudStorageFileComparator = cloudStorageFileComparator.reversed();
        }

        return cloudStorageFileComparator;
    }

    public List<String> toNamesList() {
        return cloudStorageFileList
                .stream()
                .map(file -> file.getName())
                .collect(Collectors.toList());
    }

}
