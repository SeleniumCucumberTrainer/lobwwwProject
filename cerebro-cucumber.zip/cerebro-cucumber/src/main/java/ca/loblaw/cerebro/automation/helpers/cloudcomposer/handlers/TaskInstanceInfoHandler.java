package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseTask;

public class TaskInstanceInfoHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseTask responseTask = (AirflowResponseTask) airflowResponseItem;

        // Update
        if (dagRun.hasTaskInstance(responseTask.getTaskId())) {
            TaskInstance taskInstance = dagRun.getTaskInstance(responseTask.getTaskId());
            taskInstance.setState(AirflowState.from(responseTask.getTaskState()));
            taskInstance.setStartDate(responseTask.getStartDate());
            taskInstance.setEndDate(responseTask.getEndDate());
            taskInstance.setKeywordArguments(responseTask.getKeywordArguments());
        } else {
            TaskInstance taskInstance = new TaskInstance(
                    responseTask.getTaskId(),
                    AirflowState.from(responseTask.getTaskState()),
                    responseTask.getStartDate(),
                    responseTask.getEndDate(),
                    responseTask.getKeywordArguments()
            );
            dagRun.addTaskInstance(taskInstance);
        }
    }
}
