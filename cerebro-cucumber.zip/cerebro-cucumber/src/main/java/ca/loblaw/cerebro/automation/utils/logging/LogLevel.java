package ca.loblaw.cerebro.automation.utils.logging;

/**
 * Reporter log levels. Used to link Reporter class methods to underlying implementation logging.
 */
public enum LogLevel {
    INFO,
    WARN,
    ERROR,
    PASS,
    SKIP
}