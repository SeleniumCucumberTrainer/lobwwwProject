package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

public class SnapshotSmokeFactory extends ComposerTechComputeSmokeFactory {

    public SnapshotSmokeFactory() {
        super("Snapshot");
    }
}
