package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeTest;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "CloudComposer", "TechCompute", "Smoke" })
public class TechComputeSmokeTest extends ComposerSmokeTest {

    private static final String AIRFLOW_PROPERTIES = "src/main/resources/setup/cloudcomposer/techcompute/airflowFunction.properties";
    private static final AirflowFunction AIRFLOW_FUNCTION;

    static {
        try {
            AIRFLOW_FUNCTION = AirflowFunction.fromPropertiesFile(AIRFLOW_PROPERTIES);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public TechComputeSmokeTest(String dataName, String startingDagId, String sheetName) {
        super(dataName, startingDagId, sheetName, Project.TECHCOMPUTE_ZONE, AIRFLOW_FUNCTION);
    }
}
