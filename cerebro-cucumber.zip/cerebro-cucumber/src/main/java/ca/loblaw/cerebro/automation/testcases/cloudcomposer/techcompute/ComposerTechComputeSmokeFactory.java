package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeFactory;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.internal.ExcelReader;
import ca.loblaw.cerebro.automation.utils.reports.excel.ComposerDagRunExcelReportGenerator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Factory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;

public abstract class ComposerTechComputeSmokeFactory extends ComposerSmokeFactory {

    public ComposerTechComputeSmokeFactory(String sheetName) {
        super(
                Project.TECHCOMPUTE_ZONE,
                "src/main/resources/setup/cloudcomposer/techcompute/TechComputeDAGs.xlsx",
                "TechComputeDAGs",
                sheetName
        );
    }
}
