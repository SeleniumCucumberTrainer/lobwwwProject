package ca.loblaw.cerebro.automation.utils.cloud.storage;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import com.google.api.gax.paging.Page;
import com.google.cloud.storage.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Utility class for interacting with the Google Cloud Storage service.
 */
public class CloudStorageUtils {

    private static final Storage STORAGE = StorageOptions.getDefaultInstance().getService();

    private List<CloudStorageFile> cloudStorageFileList;

    private CloudStorageUtils() {}

    // Helper class that builds Storage.BlobListOptions[]
    private static class CloudStorageFileListOptions {
        private boolean recursive = false;
        private String prefix;
        private CloudStorageFileFieldOptions fileFieldOptions;

        public CloudStorageFileListOptions setRecursive(boolean recursive) {
            this.recursive = recursive;
            return this;
        }

        public CloudStorageFileListOptions setPrefix(String prefix) {
            this.prefix = prefix;
            return this;
        }

        public CloudStorageFileListOptions setFileFieldOptions(CloudStorageFileFieldOptions fileFieldOptions) {
            this.fileFieldOptions = fileFieldOptions;
            return this;
        }

        public Storage.BlobListOption[] build() {
            List<Storage.BlobListOption> blobListOptions = new ArrayList<>();


            if(prefix != null) {
                blobListOptions.add(Storage.BlobListOption.prefix(prefix));
            }

            if(!recursive) {
                blobListOptions.add(Storage.BlobListOption.currentDirectory());
            }

            if(fileFieldOptions != null) {
                blobListOptions.add(Storage.BlobListOption.fields(fileFieldOptions.build()));
            }

            return blobListOptions.toArray(new Storage.BlobListOption[blobListOptions.size()]);
        }
    }

    // Helper class that builds Storage.BlobGetOptions[]
    private static class CloudStorageFileGetOptions {
        private CloudStorageFileFieldOptions fileFieldOptions;

        public CloudStorageFileGetOptions setFileFieldOptions(CloudStorageFileFieldOptions fileFieldOptions) {
            this.fileFieldOptions = fileFieldOptions;
            return this;
        }

        public Storage.BlobGetOption[] build() {
            List<Storage.BlobGetOption> blobGetOptions = new ArrayList<>();

            if(fileFieldOptions != null) {
                blobGetOptions.add(Storage.BlobGetOption.fields(fileFieldOptions.build()));
            }

            return blobGetOptions.toArray(new Storage.BlobGetOption[blobGetOptions.size()]);
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    // Create
    //------------------------------------------------------------------------------------------------------------------
    /**
     * Uploads a local file to a Cloud Storage path.
     * @param cloudFolderPath Cloud Storage folder destination to create.
     */
    public static void createFolder(String cloudFolderPath) {
        if(!isFolder(cloudFolderPath)) {
            throw new InvalidParameterException("Cloud Storage folder path is not a folder");
        }

        BlobId blobId = BlobId.fromGsUtilUri(cloudFolderPath);
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();

        STORAGE.create(blobInfo);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Upload
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Uploads a local file to a Cloud Storage path.
     * @param localPath Local path to file for upload.
     * @param cloudFilePath Cloud Storage path destination for upload.
     * @throws IOException Error reading local file from local file path.
     */
    public static void uploadFile(String localPath, String cloudFilePath) throws IOException {
        BlobId blobId = BlobId.fromGsUtilUri(cloudFilePath);
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();

        STORAGE.create(blobInfo, Files.readAllBytes(Paths.get(localPath)));
    }

    /**
     * Uploads a local file with metadata to a Cloud Storage path.
     * @param localPath Local path to file for upload.
     * @param cloudFilePath Cloud Storage path destination for upload.
     * @param metadata Map containing file metadata.
     * @throws IOException Error reading local file from local file path.
     */
    public static void uploadFileWithMetadata(String localPath, String cloudFilePath, Map<String, String> metadata) throws IOException {
        BlobId blobId = BlobId.fromGsUtilUri(cloudFilePath);
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setMetadata(metadata).build();

        STORAGE.create(blobInfo, Files.readAllBytes(Paths.get(localPath)));
    }

    /**
     * Uploads a local folder to a Cloud Storage folder path.
     * @param localFolderPath Local folder path containing files to upload.
     * @param cloudFolderPath Cloud Storage folder path destination to upload.
     * @param isRecursive Whether to recursively upload files in subdirectories.
     * @throws IOException Error reading local file from local file path.
     */
    public static void uploadFolder(String localFolderPath, String cloudFolderPath, boolean isRecursive) throws IOException {
        File localDirectory = new File(localFolderPath);

        if (!localDirectory.isDirectory() || !isFolder(localFolderPath) || !isFolder(cloudFolderPath)) {
            throw new InvalidParameterException("Cloud path or local path is not a folder");
        }

        // Retrieve all files in local directory
        Collection<File> localFiles = FileUtils.listFiles(localDirectory, null, isRecursive);
        List<String> localFilePaths = localFiles
                .stream()
                .map(file -> file.getAbsolutePath().replaceAll("\\\\", "/"))
                .collect(Collectors.toList());

        // Upload each individual local file in directory to Cloud Folder path
        for (String localFilePath : localFilePaths) {
            String relativeLocalName = localFilePath.replace(localFolderPath, "");
            String cloudFilePath = cloudFolderPath + relativeLocalName;

            uploadFile(localFilePath, cloudFilePath);
        }
    }


    //------------------------------------------------------------------------------------------------------------------
    // Copy
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Downloads a file from a Cloud Storage path to local path.
     * @param cloudFilePath Cloud Storage path to download file.
     * @param localPath Local path to download file into.
     */
    public static void downloadFile(String cloudFilePath, String localPath) {
        Blob blob = STORAGE.get(BlobId.fromGsUtilUri(cloudFilePath));

        blob.downloadTo(Paths.get(localPath));
    }

    /**
     * Copy a Cloud Storage file to a target Cloud Storage file path. This operation will overwrite.
     * @param sourceCloudFilePath Cloud Storage path to file to copy.
     * @param targetCloudFilePath Cloud Storage path to copy file to.
     */
    public static void copyFile(String sourceCloudFilePath, String targetCloudFilePath) {
        BlobId source = BlobId.fromGsUtilUri(sourceCloudFilePath);
        BlobId target = BlobId.fromGsUtilUri(targetCloudFilePath);

        STORAGE.copy(Storage.CopyRequest.newBuilder()
                .setSource(source)
                .setTarget(target)
                .build());
    }

    /**
     * Copy a Cloud Storage folder to a target Cloud Storage folder path. This operation will overwrite.
     * @param sourceCloudFolderPath Cloud Storage path of folder to copy.
     * @param targetCloudFolderPath Cloud Storage path to copy folder to.
     */
    public static void copyFolder(String sourceCloudFolderPath, String targetCloudFolderPath, boolean recursive) {
        if(!isFolder(sourceCloudFolderPath) || !isFolder(targetCloudFolderPath)) {
            throw new InvalidParameterException("Neither source nor target Cloud Storage path is a folder");
        }

        CloudStoragePathSplitter sourcePathInfo = CloudStoragePathSplitter.splitPath(sourceCloudFolderPath);
        String sourceBucket = sourcePathInfo.getBucketName();
        String sourceFolder = sourcePathInfo.getFileName();

        CloudStoragePathSplitter targetPathInfo = CloudStoragePathSplitter.splitPath(targetCloudFolderPath);
        String targetBucket = targetPathInfo.getBucketName();
        String targetFolder = targetPathInfo.getFileName();


        Page<Blob> blobs = STORAGE.list(sourceBucket,
                new CloudStorageFileListOptions().setPrefix(sourceFolder).setRecursive(recursive).build());

        for(Blob blob: blobs.iterateAll()) {
            if(!recursive && isFolder(blob.getName())) {
                continue;
            }

            String targetPath = blob.getName().replaceFirst(sourceFolder, targetFolder);
            blob.copyTo(targetBucket, targetPath);
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    // Move
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Move a Cloud Storage file to a target Cloud Storage file path. This operation will overwrite.
     * @param sourceCloudFilePath Cloud Storage path of file to move.
     * @param targetCloudFilePath Cloud Storage path to move file to.
     */
    public static void moveFile(String sourceCloudFilePath, String targetCloudFilePath) {
        BlobId source = BlobId.fromGsUtilUri(sourceCloudFilePath);
        BlobId target = BlobId.fromGsUtilUri(targetCloudFilePath);

        STORAGE.copy(Storage.CopyRequest.newBuilder()
                .setSource(source)
                .setTarget(target)
                .build());

        STORAGE.delete(source);
    }

    /**
     * Moves a Cloud Storage folder to a target Cloud Storage folder path. This operation will overwrite.
     * @param sourceCloudFolderPath Cloud Storage path of folder to move.
     * @param targetCloudFolderPath Cloud Storage path to move folder to.
     */
    public static void moveFolder(String sourceCloudFolderPath, String targetCloudFolderPath, boolean recursive) {
        if(!isFolder(sourceCloudFolderPath) || !isFolder(targetCloudFolderPath)) {
            throw new InvalidParameterException("Neither source nor target Cloud Storage path is a folder");
        }

        CloudStoragePathSplitter sourcePathInfo = CloudStoragePathSplitter.splitPath(sourceCloudFolderPath);
        String sourceBucket = sourcePathInfo.getBucketName();
        String sourceFolder = sourcePathInfo.getFileName();

        CloudStoragePathSplitter targetPathInfo = CloudStoragePathSplitter.splitPath(targetCloudFolderPath);
        String targetBucket = targetPathInfo.getBucketName();
        String targetFolder = targetPathInfo.getFileName();

        Page<Blob> blobs = STORAGE.list(sourceBucket,
                new CloudStorageFileListOptions().setPrefix(sourceFolder).setRecursive(recursive).build());

        StorageBatch storageBatch = STORAGE.batch();

        for(Blob blob: blobs.iterateAll()) {
            if(!recursive && isFolder(blob.getName())) {
                continue;
            }

            String targetPath = blob.getName().replaceFirst(sourceFolder, targetFolder);
            blob.copyTo(targetBucket, targetPath);
            storageBatch.delete(blob.getBlobId());
        }

        storageBatch.submit();
    }

    //------------------------------------------------------------------------------------------------------------------
    // Delete
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Deletes all files in batch in a Cloud Storage folder
     * @param cloudFolderPath Cloud Storage prefix matcher.
     */
    public static void deleteFolder(String cloudFolderPath) {
        if(!isFolder(cloudFolderPath)) {
            throw new InvalidParameterException("Cloud Storage path is not a folder");
        }

        CloudStoragePathSplitter cloudStoragePathSplitter = CloudStoragePathSplitter.splitPath(cloudFolderPath);
        String bucketName = cloudStoragePathSplitter.getBucketName();
        String folder = cloudStoragePathSplitter.getFileName();


        Page<Blob> blobs = STORAGE.list(bucketName,
                Storage.BlobListOption.prefix(folder));
        StorageBatch storageBatch = STORAGE.batch();

        int deletecounter = 0;
        for(Blob blob: blobs.iterateAll()) {
            storageBatch.delete(blob.getBlobId());
            deletecounter++;
        }

        // Submit batch if there are blobs to delete
        if (deletecounter != 0) {
            storageBatch.submit();
        }
    }

    /**
     * Deletes a file at a specified Cloud Storage path.
     * @param cloudFilePath Cloud Storage path to file.
     * @return Whether delete was successful.
     */
    public static boolean deleteFile(String cloudFilePath) {
        BlobId blobId = BlobId.fromGsUtilUri(cloudFilePath);

        return STORAGE.delete(blobId);
    }

    //------------------------------------------------------------------------------------------------------------------
    // List
    //------------------------------------------------------------------------------------------------------------------

    public static CloudStorageFile getFile(String cloudFilePath, CloudStorageFileFieldOptions cloudStorageFileFieldOptions) {
        BlobId blobId = BlobId.fromGsUtilUri(cloudFilePath);

        Blob blob = STORAGE.get(blobId,
                new CloudStorageFileGetOptions()
                        .setFileFieldOptions(cloudStorageFileFieldOptions)
                        .build()
        );

        return CloudStorageFile.from(blob);
    }

    /**
     * Retrieves list of files from a Cloud Storage path. This does not list subdirectories.
     * @param cloudFilesPrefix Cloud Storage prefix path to find files.
     * @param cloudStorageFileFieldOptions {@code CloudStorageFileFieldOptions} containing which {@code Blob}
     *                                            fields to return.
     * @return List of {@code CloudStorageFile} containing file information.
     */
    public static List<CloudStorageFile> listFiles(String cloudFilesPrefix, CloudStorageFileFieldOptions cloudStorageFileFieldOptions) {
        return listFilesPattern(cloudFilesPrefix, "", cloudStorageFileFieldOptions);
    }

    /**
     * Retrieves list of files from a Cloud Storage path. This does not list subdirectories.
     * @param cloudFilesPrefix Cloud Storage prefix path to find files.
     * @param filePattern RegEx pattern to match file names.
     * @param cloudStorageFileFieldOptions {@code CloudStorageFileFieldOptions} containing which {@code Blob}
     *                                     fields to return.
     * @return List of {@code CloudStorageFile} containing file information.
     */
    public static List<CloudStorageFile> listFilesPattern(String cloudFilesPrefix, String filePattern,
                                                          CloudStorageFileFieldOptions cloudStorageFileFieldOptions) {

        CloudStoragePathSplitter cloudStoragePathSplitter = CloudStoragePathSplitter.splitPath(cloudFilesPrefix);
        String bucketName = cloudStoragePathSplitter.getBucketName();
        String prefix = cloudStoragePathSplitter.getFileName();

        Pattern pattern = filePattern.isEmpty() ? null : Pattern.compile(Pattern.quote(prefix) + filePattern);

        Page<Blob> blobs = retrieveBlobsPage(bucketName, prefix, cloudStorageFileFieldOptions);
        List<CloudStorageFile> files = new ArrayList<>();

        for (Blob blob: blobs.iterateAll()) {
            if (blob.getName().endsWith("/")) {
                continue;
            }

            if (pattern != null) {
                if (!pattern.matcher(blob.getName()).matches()) {
                    files.add(CloudStorageFile.from(blob));
                }
            }

            files.add(CloudStorageFile.from(blob));
        }

        return files;
    }

    private static Page<Blob> retrieveBlobsPage(String bucketName, String folder, CloudStorageFileFieldOptions cloudStorageFileFieldOptions) {
        Page<Blob> blobs = STORAGE.list(bucketName,
                new CloudStorageFileListOptions()
                        .setPrefix(folder)
                        .setRecursive(false)
                        .setFileFieldOptions(cloudStorageFileFieldOptions)
                        .build()
        );

        return blobs;
    }

    //------------------------------------------------------------------------------------------------------------------
    // Exist
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Checks if a file exists at a Cloud Storage path.
     * @param cloudFilePath Cloud Storage path to file.
     * @return Whether a Cloud Storage file exists.
     */
    public static boolean doesFileExist(String cloudFilePath) {
        BlobId blobId = BlobId.fromGsUtilUri(cloudFilePath);
        Blob blob = STORAGE.get(blobId);

        return blob != null;
    }

    /**
     * Checks if a bucket exists in the current project
     * @param bucketName Name of bucket to check.
     * @return Whether the bucket exists.
     */
    public static boolean doesBucketExist(String bucketName) {
        Bucket bucket = STORAGE.get(bucketName);
        return bucket.exists();
    }

    //------------------------------------------------------------------------------------------------------------------
    // Helper
    //------------------------------------------------------------------------------------------------------------------

    private static boolean isFolder(String path) {
        return path.endsWith("/");
    }

    /***
     * Get latest jar file from the jar bucket.
     *
     * @param jarPath Subfolder for Ingestion or Curation
     * @return The path of the latest Current jar file.
     * If the Current and Archived jar versions are the same, then it returns the penultimate Archive version
     */
    public static String getLatestJar(String jarPath) {
        String folder = jarPath.split("/")[0];
        String subFolder = jarPath.split("/")[1];
        String bucket;
        String abijarBucket = TestContext.TEST_CONFIG_MAP.get("abijarBucket");
        String jarBucket = TestContext.TEST_CONFIG_MAP.get("jarBucket");
        if (folder.toLowerCase().contains("migrator")) {
            bucket = abijarBucket + "/" + folder;
        } else {
            bucket = jarBucket + "/" + folder;
        }

        List<String> sortedCurrentFiles = getSortedJarFilesByDate(bucket + "/Current/");
        String latestCurrentJarPath = sortedCurrentFiles.get(0);
        if (subFolder.toLowerCase().contains("current")) {
            System.out.println("Latest jar file : \n" + latestCurrentJarPath);
            return latestCurrentJarPath;
        }

        List<String> sortedArchiveFiles = getSortedJarFilesByDate(bucket + "/Archive/");
        String latestArchiveJarPath = sortedArchiveFiles.get(0);
        String penultimateArchiveJarPath = sortedArchiveFiles.get(1);
        String archiveJarName = FilenameUtils.getName(latestArchiveJarPath);
        String currentJarName = FilenameUtils.getName(latestCurrentJarPath);
        if (archiveJarName.equalsIgnoreCase(currentJarName)) {
            System.out.println("Latest jar file : \n" + penultimateArchiveJarPath);
            return penultimateArchiveJarPath;
        }

        System.out.println("Latest jar file : \n" + latestArchiveJarPath);
        return latestArchiveJarPath;
    }

    public static List<String> getSortedJarFilesByDate(String bucket) {
        Pattern JAR_FILE_PATTERN = Pattern.compile(".*\\.jar.*");
        List<CloudStorageFile> cloudStorageJarFiles = CloudStorageUtils.listFilesPattern(bucket, JAR_FILE_PATTERN.pattern(),
                new CloudStorageFileFieldOptions().includeName().includeCreateDate());

        List<String> jarFiles = CloudStorageFileContainer.wrap(cloudStorageJarFiles)
                .sortByCreateTime(false)
                .toNamesList();

        return jarFiles;
    }

}
