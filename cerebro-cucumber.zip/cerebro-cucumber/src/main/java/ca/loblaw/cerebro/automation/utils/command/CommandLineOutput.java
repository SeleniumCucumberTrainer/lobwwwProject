package ca.loblaw.cerebro.automation.utils.command;

import java.util.List;

/**
 * Wrapper class for the results of a Process execution.
 */
public class CommandLineOutput {

    private final int exitStatus; // Command line process exit status
    private final List<String> output; // Command line process output
    private final List<String> error; // Command line process errors

    public CommandLineOutput(int exitStatus, List<String> output, List<String> error) {
        this.exitStatus = exitStatus;
        this.output = output;
        this.error = error;
    }

    public boolean hasError() {
        return error.size() > 0;
    }

    public int getExitStatus() {
        return exitStatus;
    }

    public List<String> getOutput() {
        return output;
    }

    public List<String> getError() {
        return error;
    }
}
