package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.cloudfunction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FileRoutingMetadataLog {

    @JsonProperty("cf_execution_rslt")
    private String executionResult;

    @JsonProperty("cf_execution_tms")
    private String executionTimestamp;

    @JsonProperty("cf_file_nm")
    private String fileName;

    @JsonProperty("cf_instance_id")
    private String instanceId;

    @JsonProperty("cf_job_nm")
    private String jobName;

    @JsonProperty("cf_serv_acct_id")
    private String serviceAccount;

    @JsonProperty("cf_src_path")
    private String sourcePath;

    @JsonProperty("cf_src_tms")
    private String sourceTimestamp;

    @JsonProperty("cf_tgt_path")
    private String targetPath;

    @JsonProperty("cf_tgt_tms")
    private String targetTimestamp;

    @JsonProperty("entity_trace_id")
    private String entityTraceId;

    @JsonProperty("zone")
    private String zone;

    public String getExecutionResult() {
        return executionResult;
    }

    public void setExecutionResult(String executionResult) {
        this.executionResult = executionResult;
    }

    public String getExecutionTimestamp() {
        return executionTimestamp;
    }

    public void setExecutionTimestamp(String executionTimestamp) {
        this.executionTimestamp = executionTimestamp;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getServiceAccount() {
        return serviceAccount;
    }

    public void setServiceAccount(String serviceAccount) {
        this.serviceAccount = serviceAccount;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    public String getSourceTimestamp() {
        return sourceTimestamp;
    }

    public void setSourceTimestamp(String sourceTimestamp) {
        this.sourceTimestamp = sourceTimestamp;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    public String getTargetTimestamp() {
        return targetTimestamp;
    }

    public void setTargetTimestamp(String targetTimestamp) {
        this.targetTimestamp = targetTimestamp;
    }

    public String getEntityTraceId() {
        return entityTraceId;
    }

    public void setEntityTraceId(String entityTraceId) {
        this.entityTraceId = entityTraceId;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    @Override
    public String toString() {
        return "FileRoutingMetadataLog{" +
                "executionResult='" + executionResult + '\'' +
                ", executionTimestamp='" + executionTimestamp + '\'' +
                ", fileName='" + fileName + '\'' +
                ", instanceId='" + instanceId + '\'' +
                ", jobName='" + jobName + '\'' +
                ", serviceAccount='" + serviceAccount + '\'' +
                ", sourcePath='" + sourcePath + '\'' +
                ", sourceTimestamp='" + sourceTimestamp + '\'' +
                ", targetPath='" + targetPath + '\'' +
                ", targetTimestamp='" + targetTimestamp + '\'' +
                ", entityTraceId='" + entityTraceId + '\'' +
                ", zone='" + zone + '\'' +
                '}';
    }
}
