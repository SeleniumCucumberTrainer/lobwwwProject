package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

public class PublicationSmokeFactory extends ComposerTechComputeSmokeFactory {
    public PublicationSmokeFactory() {
        super("Publication");
    }
}
