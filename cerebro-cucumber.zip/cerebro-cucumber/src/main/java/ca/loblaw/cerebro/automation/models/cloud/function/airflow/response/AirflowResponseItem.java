package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "response_type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = AirflowResponseDagRun.class, name="dag_run_info"),
        @JsonSubTypes.Type(value = AirflowResponseDag.class, name="dag_info"),
        @JsonSubTypes.Type(value = AirflowResponseTask.class, name="task_info"),
        @JsonSubTypes.Type(value = AirflowResponseTaskList.class, name="task_list"),
        @JsonSubTypes.Type(value = AirflowResponseTaskInstances.class, name="task_instances"),
        @JsonSubTypes.Type(value = AirflowResponseError.class, name="error"),
        @JsonSubTypes.Type(value = AirflowResponseLog.class, name="metadata_log"),
        @JsonSubTypes.Type(value = AirflowResponseXcomList.class, name="xcom_list"),
        @JsonSubTypes.Type(value = AirflowResponseXcomValue.class, name="xcom_value")
})
public abstract class AirflowResponseItem {
}
