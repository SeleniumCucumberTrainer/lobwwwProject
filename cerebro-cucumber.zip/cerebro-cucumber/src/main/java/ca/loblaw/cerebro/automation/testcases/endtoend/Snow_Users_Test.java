package ca.loblaw.cerebro.automation.testcases.endtoend;

import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "Snow", "EndToEnd" })
public class Snow_Users_Test extends EndToEndTest {
    public Snow_Users_Test() throws IOException {
        super(
                "src/main/resources/setup/endtoend/snow_users.properties",
                "src/main/resources/setup/endtoend/cleanup/snow_users.sql"
        );
    }
}
