package ca.loblaw.cerebro.automation.testcases.endtoend;

import ca.loblaw.cerebro.automation.annotations.ConfigCondition;
import ca.loblaw.cerebro.automation.annotations.Depends;
import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.CurationTasks;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.IngestionTasks;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.SnapshotTasks;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.exceptions.DagException;
import ca.loblaw.cerebro.automation.models.validations.*;
import ca.loblaw.cerebro.automation.steps.endtoend.ControlFlowValidator;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.ExternalTableQuery;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.FileFormat;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;
import ca.loblaw.cerebro.automation.steps.cloudcomposer.AirflowDagUpdater;
import ca.loblaw.cerebro.automation.steps.cloudcomposer.AirflowDagValidator;
import ca.loblaw.cerebro.automation.steps.endtoend.*;
import ca.loblaw.cerebro.automation.steps.filerouting.*;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.cloud.bigquery.BigQueryUtils;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.CerebroPatterns;
import ca.loblaw.cerebro.automation.utils.internal.LocalFileUtils;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.TableResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

public abstract class EndToEndTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(EndToEndTest.class);
    private static final String AIRFLOW_PROPERTIES = "src/main/resources/setup/cloudcomposer/techcompute/airflowFunction.properties";
    private static AirflowFunction AIRFLOW_FUNCTION;
    private static final long WAIT_INTERVAL = 10000;
    private static final long WAIT_MAX = 1800000;

    // Parameters
    private final Map<String, String> propertiesMap;
    private String cleanupSqlFilePath;
    private final String testFolderPath;
    private final String landingFolderPath;
    private final String rawFolderPath;
    private final String ingestionTable;
    private final String snapshotTable;
    private final String curationTable;
    private final String[] publicationTables;

    /* -------- Run Variables -------- */

    // Others
    private String landingStartTime;
    private String jobRunTraceId;
    private String externalTable;

    // Landing
    private List<CloudStorageFile> landingTestCloudFiles;
    private List<CloudStorageFile> rawTestCloudFiles;
    private List<CloudStorageFile> batchDataRawFiles;

    // Ingestion
    private DagRun ingestionDag;
    private String ingestionRecCreTms;
    private String ingestionDataflowJobId;
    private String ingestionDataflowJobName;
    private int ingestionTableRecordCount;
    private int ingestionDataflowRecordCount;
    private int ingestionDataflowErrorCount;
    private List<Column> ingestionColumns;

    // Snapshot
    private DagRun snapshotDag;
    private String snapshotTime;
    private int snapshotTableRecordCount;

    // Curation
    private DagRun curationDag;
    private String curationRecCreTms;
    private String curationDataflowJobId;
    private String curationDataflowJobName;
    private int curationTableRecordCount;
    private int curationDataflowRecordCount;
    private int curationDataflowErrorCount;

    // Publication
    private DagRun publicationDag;
    private String publicationRecCreTms;
    private int[] publicationTableRecordCounts;

    // Test steps and validators
    private FileRoutingStorageManager fileRoutingStorageManager;
    private AirflowDagUpdater airflowDagUpdater;

    public EndToEndTest(String propertiesFilePath) throws IOException {
        this.propertiesMap = PropertiesFileUtils.readPropertiesFileToMap(propertiesFilePath);

        this.testFolderPath = propertiesMap.get("testFolderPath");
        this.landingFolderPath = propertiesMap.get("landingFolderPath");
        this.rawFolderPath = propertiesMap.get("rawFolderPath");
        this.ingestionTable = propertiesMap.get("ingestionTable");
        this.snapshotTable = propertiesMap.get("snapshotTable");
        this.curationTable = propertiesMap.get("curationTable");
        this.publicationTables = propertiesMap.get("publicationTables").replace(" ", "").split(",");


        // DAG run instances
        this.ingestionDag = new DagRun(propertiesMap.get("ingestionDagId"), Project.TECHCOMPUTE_ZONE);
        this.snapshotDag = new DagRun(propertiesMap.get("snapshotDagId"), Project.TECHCOMPUTE_ZONE);
        this.curationDag = new DagRun(propertiesMap.get("curationDagId"), Project.TECHCOMPUTE_ZONE);
        this.publicationDag = new DagRun(propertiesMap.get("publicationDagId"), Project.TECHCOMPUTE_ZONE);
    }

    public EndToEndTest(String propertiesFilePath, String cleanupSqlFilePath) throws IOException {
        this(propertiesFilePath);
        this.cleanupSqlFilePath = cleanupSqlFilePath;
    }

    @BeforeSuite
    public void end_to_end_test_before_suite() throws IOException {
        AIRFLOW_FUNCTION = AirflowFunction.fromPropertiesFile(AIRFLOW_PROPERTIES);
    }

    @BeforeClass
    public void end_to_end_test_before_class() {
        fileRoutingStorageManager = new FileRoutingStorageManager(testFolderPath, landingFolderPath, rawFolderPath);
        airflowDagUpdater = new AirflowDagUpdater(AIRFLOW_FUNCTION);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Input Check
    //------------------------------------------------------------------------------------------------------------------

    @Test(description = "Check Input")
    public void check_input() throws IOException {
        // Check properties
        validateProperties(propertiesMap);

        // Check DAGs
        validateDagInput(ingestionDag);
        validateDagInput(snapshotDag);
        validateDagInput(curationDag);
        validateDagInput(publicationDag);

        // Check tables
        validateTableInput(ingestionTable);
        validateTableInput(snapshotTable);
        validateTableInput(curationTable);
        for (String publicationTable : publicationTables) {
            validateTableInput(publicationTable);
        }

        // Connect DAGs
        AirflowDagUpdater.connectUpstreamAndDownstreamDag(ingestionDag, snapshotDag);
        AirflowDagUpdater.connectUpstreamAndDownstreamDag(snapshotDag, curationDag);
        AirflowDagUpdater.connectUpstreamAndDownstreamDag(curationDag, publicationDag);

        landingStartTime = LocalDateTime.now(ZoneId.of("UTC")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        LOG.info("Landing start time is around {}", landingStartTime);
    }

    private void validateProperties(Map<String, String> propertiesMap) {
        // File information
        Assertions.assertThat(propertiesMap)
                .containsKey("fileFormat");
        Assertions.assertThat(propertiesMap)
                .containsKey("fileExternalTableFormat");
        Assertions.assertThat(propertiesMap)
                .containsKey("fileDelimiter");
        Assertions.assertThat(propertiesMap)
                .containsKey("fileHasHeader");

        // Landing
        Assertions.assertThat(propertiesMap)
                .containsKey("testFolderPath");
        Assertions.assertThat(propertiesMap)
                .containsKey("landingFolderPath");
        Assertions.assertThat(propertiesMap)
                .containsKey("rawFolderPath");
    }

    private void validateDagInput(DagRun dag) throws IOException {
        String dagId = dag.getDagId();

        airflowDagUpdater.setDagRun(dag);
        airflowDagUpdater.checkDagInfo();
        airflowDagUpdater.listTasks();
        Assertions.assertThat(dag.hasNoError())
                .as("Check %s exists", dagId)
                .isTrue();
        Assertions.assertThat(dag.isPaused())
                .as("Check %s is paused", dagId)
                .isFalse();
        Reporter.pass(LOG, "DAG {} is valid", dagId);
    }

    private void validateTableInput(String tableName) {
        Assertions.assertThat(BigQueryUtils.checkTableExists(tableName))
                .as("Check table %s exists", tableName)
                .isTrue();
        Reporter.pass(LOG, "Table {} is valid", tableName);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Landing
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(groups = "landing")
    @Depends(methods = "check_input")
    @ConfigCondition(runBeforeOrAfterGroups = "landing", runOnce = true)
    public void landing_zone_setup(ITestResult testResult) throws InterruptedException {
        // Copying test files
        fileRoutingStorageManager.cleanLandingFolder();
        List<String> testFilesToCopyPaths = fileRoutingStorageManager.retrieveTestFilesPaths();

        Assertions.assertThat(testFilesToCopyPaths.size())
                .as("Number of test files to copy")
                .isGreaterThan(0);

        fileRoutingStorageManager.copyTestFilesToLandingFolder(testFilesToCopyPaths);
    }

    @Test(priority = 1, description = "Validate Landing zone", groups = "landing")
    @Depends(methods = "check_input")
    public void validate_landing_file_routing() {
        // Landing files
        landingTestCloudFiles = fileRoutingStorageManager.retrieveLandingFiles()
                .stream()
                .sorted()
                .collect(Collectors.toList());

        Assertions.assertThat(landingTestCloudFiles.size())
                .as("Number of landing files")
                .isGreaterThan(0);
        Reporter.pass(LOG, "Number of landing files is greater than 0");

        // Retrieve raw test files routed from landing
        rawTestCloudFiles = fileRoutingStorageManager.findRawCloudFilesFromLandingFiles(landingTestCloudFiles, "landing");
        FileRoutingValidator.validateLandingAndRawCloudFiles(landingTestCloudFiles, rawTestCloudFiles, "landing");

        addPassFlag("files_landed");
    }

    @Test(priority = 2, description = "Validate File Routing Metadata Log", groups = "landing")
    @Depends(methods = "validate_landing_file_routing")
    public void validate_landing_file_routing_metadata_log() throws InterruptedException {
        Thread.sleep(10000);

        DataObservabilityValidator.validateFileRoutingMetadataLogs(
                landingStartTime,
                retrieveNonDfmFiles(landingTestCloudFiles),
                retrieveNonDfmFiles(rawTestCloudFiles)
        );
    }

    private List<CloudStorageFile> retrieveNonDfmFiles(List<CloudStorageFile> cloudFiles) {
        return cloudFiles.stream()
                .filter(cloudStorageFile -> !cloudStorageFile.getName().endsWith(".dfm"))
                .collect(Collectors.toList());
    }


    //------------------------------------------------------------------------------------------------------------------
    // Ingestion
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(groups = "ingestion")
    @Depends(flags = "files_landed")
    @ConfigCondition(runBeforeOrAfterGroups = "ingestion", runOnce = true)
    public void trigger_ingestion_dag(ITestResult testResult) throws IOException, InterruptedException {
        airflowDagUpdater.setDagRun(ingestionDag);

        // Trigger
        airflowDagUpdater.triggerDag();
        Reporter.info(LOG, "DAG run ID is {}", ingestionDag.getDagRunId());

        // Set ingestion flag is DAG is running
        waitForDagToRun(ingestionDag);

        if (ingestionDag.getState() != AirflowState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("ingestion_triggered");
        } else {
            throw new DagException("Ingestion DAG is still queued");
        }
    }

    @Test(priority = 10, description = "Validate Ingestion Job Run Trace ID", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_job_run_trace_id() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.GENERATE_JOB_RUN_TRACE_ID);
        airflowDagUpdater.retrieveXcomVariables(IngestionTasks.GENERATE_JOB_RUN_TRACE_ID);
        airflowDagUpdater.retrieveXcomValue(IngestionTasks.GENERATE_JOB_RUN_TRACE_ID, "return_value");

        // Retrieve job run trace ID
        TaskInstance generateJobRunTraceId = ingestionDag.getTaskInstance(IngestionTasks.GENERATE_JOB_RUN_TRACE_ID);
        jobRunTraceId = String.valueOf(generateJobRunTraceId.getXcomEntry("return_value"));
        jobRunTraceId = jobRunTraceId.substring(2, jobRunTraceId.length() - 2);
        Reporter.info(LOG, "Job run trace ID is {}", jobRunTraceId);

        // Validations
        Assertions.assertThat(jobRunTraceId)
                .as("Job run trace ID")
                .matches(CerebroPatterns.UUID);
        Reporter.pass(LOG, "Job run trace ID matches UUID pattern");
    }

    @Test(priority = 11, description = "Validate Ingestion Move to Working", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_move_to_working() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.MOVE_TO_WORKING);

        // Raw files
        List<CloudStorageFile> workingRawCloudFiles = fileRoutingStorageManager.findRawCloudFilesFromLandingFiles(landingTestCloudFiles, "working");
        FileRoutingValidator.validateLandingAndRawCloudFiles(landingTestCloudFiles, workingRawCloudFiles, "working");

        // Retrieve all non-DFM raw files for validation in "working" folder
        String fileFormat = propertiesMap.get("fileFormat");
        batchDataRawFiles = fileRoutingStorageManager.retrieveRawFiles("working");
        batchDataRawFiles = batchDataRawFiles.stream()
                .filter(file -> file.getName().endsWith(fileFormat))
                .collect(Collectors.toList());
        Reporter.info(LOG, "{} of the raw files in 'working' folder are data files", batchDataRawFiles.size());
    }

    @Test(priority = 12, description = "Validate Ingestion Dataflow", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_dataflow() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomVariables(IngestionTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomValue(IngestionTasks.TRIGGER_DATAFLOW_JOB, "jobName");
        airflowDagUpdater.retrieveXcomValue(IngestionTasks.TRIGGER_DATAFLOW_JOB, "jobId");

        // Retrieve recCreTms and target table
        Reporter.info(LOG, "Checking BigQuery information from task '{}'", IngestionTasks.TRIGGER_DATAFLOW_JOB);

        TaskInstance triggerDataflowJob = ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB);
        ingestionRecCreTms = String.valueOf(triggerDataflowJob.getArgument("recCreTms"));
        String targetTable = String.valueOf(triggerDataflowJob.getArgument("trgt_ds_tbl_nm"));

        Reporter.info(LOG,"Ingestion recCreTms is {}", ingestionRecCreTms);
        Reporter.info(LOG,"Task '{}' target table is {}", IngestionTasks.TRIGGER_DATAFLOW_JOB, targetTable);

        Assertions.assertThat(targetTable)
                .as("Check task '%s' target table", IngestionTasks.TRIGGER_DATAFLOW_JOB)
                .isEqualTo(extractDatasetTable(ingestionTable));
        Reporter.pass(LOG, "Task '{}' has same target table as the given target table", IngestionTasks.TRIGGER_DATAFLOW_JOB);

        // Ingestion table record count
        ingestionTableRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) as record_count FROM `%s` WHERE rec_cre_tms = '%s'",
                        ingestionTable,
                        ingestionRecCreTms
                )
        );
        Reporter.info(LOG, "Ingestion table record count for {} is {}", ingestionRecCreTms, ingestionTableRecordCount);
        if (ingestionTableRecordCount == 0) {
            Reporter.warn(LOG, "Ingestion table record count is 0");
        }

        // Retrieve dataflow values
        Reporter.info(LOG, "Checking dataflow information from task '{}'", IngestionTasks.TRIGGER_DATAFLOW_JOB);
        ingestionDataflowJobId = ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobId");
        ingestionDataflowJobName = ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobName");

        Reporter.info(LOG, "Dataflow job name is {} and ID is {}", ingestionDataflowJobName, ingestionDataflowJobId);

        // Validations
        DataflowJobValidator.validateDataflowJob(ingestionDataflowJobId);
        DataflowJobValidator.DataflowResults dataflowResults = DataflowJobValidator.validateAndReturnDataflowMetrics(
                ingestionDataflowJobId,
                "Valid Records to BQ/Write to BQ/PrepareWrite",
                Arrays.asList("Error Logging/Write unaggregated errors to BigQuery/Bounded Write to BQ/PrepareWrite"),
                ingestionTableRecordCount
        );
        ingestionDataflowRecordCount = dataflowResults.getRecordCount();
        ingestionDataflowErrorCount = dataflowResults.getErrorCount();
    }

    @Test(priority = 13, description = "Validate Ingestion Move to Processed", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_move_to_processed() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.MOVE_TO_PROCESSED);

        // Raw files
        List<CloudStorageFile> processedRawCloudFiles = fileRoutingStorageManager.findRawCloudFilesFromLandingFiles(landingTestCloudFiles, "processed");
        FileRoutingValidator.validateLandingAndRawCloudFiles(landingTestCloudFiles, processedRawCloudFiles, "processed");
    }

    @BeforeMethod(groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    @ConfigCondition(runBeforeOrAfterMethods = "validate_ingestion_bigquery", runOnce = true)
    public void create_external_table(ITestResult testResult) throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.MOVE_TO_PROCESSED);

        externalTable = propertiesMap.get("externalTable");
        ingestionColumns = BigQueryUtils.getColumnsSchemaFromTable(ingestionTable, true);

        // Find "working" data raw files moved to "processed"
        batchDataRawFiles = fileRoutingStorageManager.findRawCloudFilesInStageFromStage(
                batchDataRawFiles, "working", "processed");

        ExternalTableQuery externalTableQuery = new ExternalTableQuery()
                .setTableName(externalTable)
                .setColumns(ingestionColumns)
                .setFileURIs(batchDataRawFiles);

        if (propertiesMap.containsKey("fileExternalTableFormat")){
            externalTableQuery.setFileFormat(FileFormat.fromString(propertiesMap.get("fileExternalTableFormat")));
        }
        if (propertiesMap.containsKey("fileHasHeader")) {
            externalTableQuery.setHasHeader(Boolean.parseBoolean(propertiesMap.get("fileHasHeader")));
        }
        if (propertiesMap.containsKey("fileDelimiter")) {
            externalTableQuery.setDelimiter(propertiesMap.get("fileDelimiter").charAt(0));
        }
        externalTableQuery.setMaxBadRecords(Integer.MAX_VALUE);

        try {
            BigQueryUtils.executeQuery(externalTableQuery.build());
            LOG.info("Created external table '{}' ", externalTable);
        } catch (InterruptedException e) {
            LOG.error("Failed to create external table '{}'", externalTable);
            throw new RuntimeException(e);
        }
    }

    @Test(priority = 14, description = "Validate Ingestion BigQuery Record Count", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_bigquery() throws InterruptedException {
        // External table record count
        int externalTableRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM `%s`",
                        propertiesMap.get("externalTable")
                )
        );
        Reporter.info(LOG, "External table record count is {}", externalTableRecordCount);

        EndToEndTablesValidator.validateExternalAndIngestionTableFilesRecordCount(
                externalTable,
                ingestionTable,
                ingestionRecCreTms,
                batchDataRawFiles
        );

        EndToEndTablesValidator.validateExternalAndIngestionTableTotalRecordCount(
                externalTableRecordCount,
                ingestionTableRecordCount
        );
    }


    @Test(priority = 15, description = "Validate Ingestion Datastore", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_datastore() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.INSERT_FLOW_CONTROL);

        ControlFlowValidator.validateDataflowControlFlowInsert(
                ingestionRecCreTms,
                extractDatasetTable(ingestionTable),
                "ingestion",
                extractDatasetTable(snapshotTable),
                "snapshot"
        );
    }

    @Test(priority = 16, description = "Validate Ingestion Metadata Logs", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_metadata_logs() throws InterruptedException, IOException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.METADATA_LOG);
        Thread.sleep(10000);
        DataObservabilityValidator.validateIngestionComposerMetadataLogs(
                new IngestionComposerValidationDto()
                        .setDagRun(ingestionDag)
                        .setRawFolderPath(rawFolderPath)
                        .setJobRunTraceId(jobRunTraceId)
                        .setDatasetTable(extractDatasetTable(ingestionTable))
                        .setRecCreTms(ingestionRecCreTms)
                        .setDataflowJobId(ingestionDataflowJobId)
                        .setDataflowJobName(ingestionDataflowJobName)
                        .setTableRecordCount(ingestionTableRecordCount)
                        .setDataflowRecordCount(ingestionDataflowRecordCount)
                        .setDataflowErrorCount(ingestionDataflowErrorCount)
                        .setBatchRawFileSize(batchDataRawFiles.size())
        );

        DataObservabilityValidator.validateIngestionDataflowMetadataLogs(
                ingestionDataflowJobName
        );
    }

    @Test(priority = 17, description = "Validate Ingestion DAG", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_dag() throws IOException, InterruptedException {
        waitForDagToFinish(ingestionDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(ingestionDag);
        AirflowDagValidator.validateDagTaskInstances(ingestionDag);
    }


    @Test(priority = 18, description = "Validate Data Integrity", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_data_integrity() {
        EndToEndTablesValidator.validateExternalAndIngestionTableDataIntegrity(
                externalTable,
                ingestionTable,
                ingestionRecCreTms,
                ingestionColumns,
                batchDataRawFiles,
                propertiesMap.get("pipelineName")
        );
    }

    //------------------------------------------------------------------------------------------------------------------
    // Snapshot
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(groups = "snapshot")
    @ConfigCondition(runBeforeOrAfterGroups = "snapshot", runOnce = true)
    @Depends(flags = "ingestion_triggered")
    public void retrieve_snapshot_dag(ITestResult testResult) throws IOException, InterruptedException {
        waitForTaskToComplete(ingestionDag, "trigger_" + snapshotDag.getDagId());
        airflowDagUpdater.setDagRun(snapshotDag);

        // Retrieve closest to execution date
        airflowDagUpdater.findRunAssociatedWithUpstreamDag();
        if (snapshotDag.getDagRunId() == null) {
            throw new DagException("Snapshot DAG was not triggered");
        }
        LOG.info("DAG run ID is {}", snapshotDag.getDagRunId());

        // Set snapshot flag if triggered and running
        waitForDagToRun(snapshotDag);

        if (snapshotDag.getState() != AirflowState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("snapshot_running");
        } else {
            throw new DagException("Snapshot DAG is still queued");
        }
    }

    @Test(priority = 20, description = "Validate Snapshot BigQuery", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    public void validate_snapshot_bigquery() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.GET_TARGET_TABLE);
        airflowDagUpdater.retrieveXcomVariables(SnapshotTasks.GET_TARGET_TABLE);
        airflowDagUpdater.retrieveXcomValue(SnapshotTasks.GET_TARGET_TABLE, "return_value");

        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.LOAD_CURRENT);

        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.GET_SNAPSHOT_TIME);
        airflowDagUpdater.retrieveXcomVariables(SnapshotTasks.GET_SNAPSHOT_TIME);
        airflowDagUpdater.retrieveXcomValue(SnapshotTasks.GET_SNAPSHOT_TIME, "system_tms");

        // Retrieve recCreTms and target table
        snapshotTime = snapshotDag.getTaskInstance(SnapshotTasks.GET_SNAPSHOT_TIME).getXcomEntry("system_tms");
        String targetTable = snapshotDag.getTaskInstance(SnapshotTasks.GET_TARGET_TABLE).getXcomEntry("return_value");

        Reporter.info(LOG, "Snapshot time from task '{}' is {}", SnapshotTasks.LOAD_CURRENT, snapshotTime);
        Reporter.info(LOG, "Task '{}' target table is {}", SnapshotTasks.LOAD_CURRENT, targetTable);

        Assertions.assertThat(targetTable)
                .as("Check task '%s' target table", SnapshotTasks.LOAD_CURRENT)
                .isEqualTo(extractDatasetTable(snapshotTable));

        // Record count validation
        snapshotTableRecordCount = EndToEndTablesValidator.validateAndReturnSnapshotRecordCount(snapshotTable);

        // Snapshot time validation
        String tableSnapshotTime = EndToEndTablesValidator.validateAndReturnSnapshotTime(
                snapshotTable,
                snapshotDag.getTaskInstance(SnapshotTasks.LOAD_CURRENT).getStartDate(),
                snapshotDag.getTaskInstance(SnapshotTasks.LOAD_CURRENT).getEndDate()
        );

        Assertions.assertThat(tableSnapshotTime)
                .as("Check table snapshot time against DAG task snapshot time")
                .isEqualTo(snapshotTime);
    }

    @Test(priority = 21, description = "Validate Snapshot Datastore", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    public void validate_snapshot_datastore() throws IOException, InterruptedException {
        // Control flow update
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.UPDATE_FLOW_CONTROL);
        ControlFlowValidator.validateDatastoreControlFlowUpdate(
                ingestionRecCreTms,
                extractDatasetTable(ingestionTable),
                "ingestion",
                snapshotTime,
                extractDatasetTable(snapshotTable),
                "snapshot"
        );

        // Control flow insert
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.INSERT_TO_CONTROL);
        ControlFlowValidator.validateDataflowControlFlowInsert(
                snapshotTime,
                extractDatasetTable(snapshotTable),
                "snapshot",
                extractDatasetTable(curationTable),
                "curation"
        );
    }

    @Test(priority = 22, description = "Validate Snapshot Metadata Logs", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    public void validate_snapshot_metadata_logs() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.METADATA_LOG);
        DataObservabilityValidator.validateSnapshotComposerMetadataLog(
                new SnapshotComposerValidationDto()
                        .setDagRun(snapshotDag)
                        .setJobRunTraceId(jobRunTraceId)
                        .setRecCreTms(snapshotTime)
                        .setSourceName(extractDatasetTable(ingestionTable))
                        .setTargetName(extractDatasetTable(snapshotTable))
                        .setTableRecordCount(snapshotTableRecordCount)
        );
    }

    @Test(priority = 23, description = "Validate Snapshot DAG", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    public void validate_snapshot_dag() throws IOException, InterruptedException {
        waitForDagToFinish(snapshotDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(snapshotDag);
        AirflowDagValidator.validateDagTaskInstances(snapshotDag);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Curation
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(groups = "curation")
    @ConfigCondition(runBeforeOrAfterGroups = "curation", runOnce = true)
    @Depends(flags = "snapshot_running")
    public void retrieve_curation_dag(ITestResult testResult) throws IOException, InterruptedException {
        waitForTaskToComplete(snapshotDag, "trigger_" + curationDag.getDagId());

        // Retrieve closest to execution date
        airflowDagUpdater.setDagRun(curationDag);
        airflowDagUpdater.findRunAssociatedWithUpstreamDag();
        if (curationDag.getDagRunId() == null) {
            throw new DagException("Curation DAG was not triggered");
        }
        LOG.info("DAG run ID is {}", curationDag.getDagRunId());

        // Set curation flag if triggered and running
        waitForDagToRun(curationDag);

        if (curationDag.getState() != AirflowState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("curation_running");
        } else {
            throw new DagException("Curation DAG is still queued");
        }
    }

    @Test(priority = 30, description = "Validate Curation Dataflow", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_dataflow() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.READ_PROPERTY);
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomVariables(CurationTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomValue(CurationTasks.TRIGGER_DATAFLOW_JOB, "jobName");
        airflowDagUpdater.retrieveXcomValue(CurationTasks.TRIGGER_DATAFLOW_JOB, "jobId");

        // Retrieve recCreTms and target table
        TaskInstance trigger_dataflow_job = curationDag.getTaskInstance(CurationTasks.TRIGGER_DATAFLOW_JOB);
        curationRecCreTms = String.valueOf(trigger_dataflow_job.getArgument("recCreTms"));
        String targetTable = String.valueOf(trigger_dataflow_job.getArgument("trgt_ds_tbl_nm"));

        Reporter.info(LOG, "Curation recCreTms is {}", curationRecCreTms);
        Reporter.info(LOG, "Curation '{}' target table is {}", CurationTasks.TRIGGER_DATAFLOW_JOB, targetTable);

        Assertions.assertThat(targetTable)
                .as("Check '%s' task target table", CurationTasks.TRIGGER_DATAFLOW_JOB)
                .isEqualTo(extractDatasetTable(curationTable));
        Reporter.pass(LOG, "Task '{}' has same target table as the given target table", CurationTasks.TRIGGER_DATAFLOW_JOB);

        // Curation table record count
        curationTableRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM `%s` WHERE rec_cre_tms = '%s'",
                        curationTable,
                        curationRecCreTms
                )
        );
        Reporter.info(LOG, "Curation table record count for {} is {}", curationRecCreTms, curationTableRecordCount);
        if (curationTableRecordCount == 0) {
            Reporter.warn(LOG, "Curation table record count is 0");
        }

        // Retrieve dataflow values
        Reporter.info(LOG, "Checking dataflow information from task '{}'", CurationTasks.TRIGGER_DATAFLOW_JOB);
        curationDataflowJobId = curationDag.getTaskInstance(CurationTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobId");
        curationDataflowJobName = curationDag.getTaskInstance(CurationTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobName");

        Reporter.info(LOG, "Dataflow job name is {} and ID is {}", curationDataflowJobName, curationDataflowJobId);

        // Validations
        DataflowJobValidator.validateDataflowJob(curationDataflowJobId);
        DataflowJobValidator.DataflowResults dataflowResults = DataflowJobValidator.validateAndReturnDataflowMetrics(
                curationDataflowJobId,
                "PB:Valid Records to BQ/Write to BQ/PrepareWrite",
                Arrays.asList("Log Record Errors/Write unaggregated errors to BigQuery/Bounded Write to BQ/PrepareWrite"),
                curationTableRecordCount
        );
        curationDataflowRecordCount = dataflowResults.getRecordCount();
        curationDataflowErrorCount = dataflowResults.getErrorCount();
    }

    @Test(priority = 31, description = "Validate Curation BigQuery", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_bigquery() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.ADD_TMS_PROPERTY);

        // Retrieve curation query
        String contents = (String) curationDag.getTaskInstance("add_tms_property").getKeywordArguments().get("contents");
        String curationQuery = extractCurationQuery(contents);
        Reporter.info(LOG, "Retrieved curation query is:\n\n{}", curationQuery);

        // Files record count
        EndToEndTablesValidator.validateCurationQueryAndTableFilesRecordCount(
                curationQuery,
                propertiesMap.get("curationQueryFileColumnName"),
                curationTable,
                curationRecCreTms,
                batchDataRawFiles,
                curationDataflowErrorCount
        );

        // Total record count
        EndToEndTablesValidator.validateCurationQueryAndTableTotalRecordCount(
                curationQuery,
                curationTableRecordCount,
                curationDataflowErrorCount
        );
    }

    private String extractCurationQuery(String contents) {
        Matcher queryMatcher = CerebroPatterns.CURATION_QUERY.matcher(contents);

        if (queryMatcher.find()) {
            String curationQuery = queryMatcher.group();
            return curationQuery.replaceFirst("query=", "")
                    .replace("\\", "")
                    .replace(";", "")
                    .replace("<env>",TestContext.ENV.toString());
        } else {
            throw new DagException("Could not retrieve curation query from DAG task");
        }
    }

    @Test(priority = 32, description = "Validate Curation Datastore", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_datastore() throws IOException, InterruptedException {
        // Control flow update
        waitForTaskToCompleteSuccessfully(curationDag, "update_flow_control");
        ControlFlowValidator.validateDatastoreControlFlowUpdate(
                snapshotTime,
                extractDatasetTable(snapshotTable),
                "snapshot",
                curationRecCreTms,
                extractDatasetTable(curationTable),
                "curation"
        );

        // Control flow insert
        waitForTaskToCompleteSuccessfully(curationDag, "insert_to_control");
        ControlFlowValidator.validateDataflowControlFlowInsertOneToMany(
                curationRecCreTms,
                extractDatasetTable(curationTable),
                "curation",
                extractDatasetTableArray(publicationTables),
                "publication"
        );
    }

    @Test(priority = 33, description = "Validate Curation Metadata Logs", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_metadata_logs() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.METADATA_LOG);
        DataObservabilityValidator.validateCurationComposerMetadataLog(
                new CurationComposerValidationDto()
                        .setDagRun(curationDag)
                        .setJobRunTraceId(jobRunTraceId)
                        .setRecCreTms(curationRecCreTms)
                        .setSourceName(extractDatasetTable(snapshotTable))
                        .setTargetName(extractDatasetTable(curationTable))
                        .setTableRecordCount(curationTableRecordCount)
                        .setDataflowJobId(curationDataflowJobId)
                        .setDataflowJobName(curationDataflowJobName)
        );
    }

    @Test(priority = 34, description = "Validate Curation DAG", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_dag() throws IOException, InterruptedException {
        waitForDagToFinish(curationDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(curationDag);
        AirflowDagValidator.validateDagTaskInstances(curationDag);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Publication
    //------------------------------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------------------------------
    // Helpers
    //------------------------------------------------------------------------------------------------------------------

    private String extractDatasetTable(String table) {
        return table.split("\\.", 2)[1];
    }

    private String[] extractDatasetTableArray(String[] tables) {
        return Arrays.stream(tables).map(this::extractDatasetTable).toArray(String[]::new);
    }

    private void waitForDagToRun(DagRun dagRun) throws IOException, InterruptedException {
        LOG.info("Waiting for DAG {} to run...", dagRun.getDagId());

        long timeElapsed = 0;
        while (dagRun.getState() == AirflowState.QUEUED && timeElapsed <= WAIT_MAX) {
            Thread.sleep(WAIT_INTERVAL);
            timeElapsed += WAIT_INTERVAL;
            airflowDagUpdater.checkRunInfo();
        }
    }

    private int retrieveBigQueryTableRecordCount(String recordCountQuery) throws InterruptedException {
        TableResult result = BigQueryUtils.executeQuery(recordCountQuery);

        Assertions.assertThat(result.getTotalRows())
                .as("Record count rows")
                .isEqualTo(1);

        int recordCount = 0;
        for (FieldValueList row : result.iterateAll()) {
            recordCount = row.get(0).getNumericValue().intValue();
            break;
        }

        return recordCount;
    }

    private void waitForDagToFinish(DagRun dagRun) throws InterruptedException, IOException {
        LOG.info("Waiting for DAG to finish running...");

        long timeElapsed = 0;
        while (dagRun.getState() == AirflowState.RUNNING && timeElapsed <= WAIT_MAX) {
            Thread.sleep(WAIT_INTERVAL);
            timeElapsed += WAIT_INTERVAL;
            airflowDagUpdater.checkRunInfo();
        }

        LOG.info("DAG is finished");
    }

    private void waitForTaskToCompleteSuccessfully(DagRun dagRun, String taskId) throws IOException, InterruptedException {
        waitForTaskToComplete(dagRun, taskId);
        Assertions.assertThat(dagRun.getTaskInstance(taskId).getState())
                .isEqualTo(AirflowState.SUCCESS);
        Thread.sleep(2000);
    }

    private void waitForTaskToComplete(DagRun dagRun, String taskId) throws InterruptedException, IOException {
        // Check if task is already done running
        if (dagRun.getTaskInstance(taskId).isDoneRunning()) {
            return;
        }

        // Waiting for task
        LOG.info("Waiting for task {} to complete ...", taskId);

        long timeElapsed = 0;
        do {
            Thread.sleep(WAIT_INTERVAL);
            timeElapsed += WAIT_INTERVAL;
            airflowDagUpdater.checkTaskInstanceInfo(taskId);
        } while (!dagRun.getTaskInstance(taskId).isDoneRunning() && timeElapsed <= WAIT_MAX);

        LOG.info("Task {} is completed with state {}", taskId, dagRun.getTaskInstance(taskId).getState());
    }

    @AfterClass(alwaysRun = true)
    public void cleanup_test_files_and_records() throws IOException, InterruptedException {
        // Cleanup landing
        if (fileRoutingStorageManager != null && landingTestCloudFiles != null) {
            fileRoutingStorageManager.cleanUpRawFolderFiles(landingTestCloudFiles);
            LOG.info("Cleaned up all raw files");
        }

        // Cleanup BQ tables
        if (cleanupSqlFilePath != null && !cleanupSqlFilePath.isEmpty()) {
            String deleteQueries = LocalFileUtils.readFileToString(cleanupSqlFilePath);
            deleteQueries = TestContext.replaceTemplateEnv(deleteQueries.replace("${rec_cre_tms}", landingStartTime));

            BigQueryUtils.executeQuery(deleteQueries);
            LOG.info("Finish executing cleanup SQL statements");
        }
    }

    @AfterClass(alwaysRun = true)
    public void report_record_counts() {
        String[][] recordCountData = {
                {"", extractDatasetTable(ingestionTable), extractDatasetTable(snapshotTable), extractDatasetTable(curationTable)},
                {"Record Count", String.valueOf(ingestionTableRecordCount), String.valueOf(snapshotTableRecordCount), String.valueOf(curationTableRecordCount)},
                {"Timestamp name", "rec_cre_tms", "snapshot_time", "rec_cre_tms"},
                {"Timestamp value", emptyIfNull(ingestionRecCreTms), emptyIfNull(snapshotTime), emptyIfNull(curationRecCreTms)}
        };
        Reporter.info(recordCountData, "record-count-table");
    }

    private String emptyIfNull(String value) {
        return value != null ? value : "";
    }
}