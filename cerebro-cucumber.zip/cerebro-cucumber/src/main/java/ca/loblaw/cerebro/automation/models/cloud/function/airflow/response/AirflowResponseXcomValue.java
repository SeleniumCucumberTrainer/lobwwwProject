package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowResponseXcomValue extends AirflowResponseItem{

    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("dag_run_id")
    private String dagRunId;

    @JsonProperty("task_id")
    private String taskId;

    @JsonProperty("xcom_key")
    private String xcomKey;

    @JsonProperty("xcom_value")
    private String xcomValue;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getXcomKey() {
        return xcomKey;
    }

    public void setXcomKey(String xcomKey) {
        this.xcomKey = xcomKey;
    }

    public String getXcomValue() {
        return xcomValue;
    }

    public void setXcomValue(String xcomValue) {
        this.xcomValue = xcomValue;
    }
}
