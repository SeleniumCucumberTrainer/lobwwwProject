package ca.loblaw.cerebro;

import org.apache.commons.cli.*;
import org.testng.TestNG;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Main execution class for test framework. Delegates test executions and options to TestNG runner.
 */
public class AutomationExecutor {

    public static void main(String[] args) throws IOException, InterruptedException, ParseException {

        // Options
        Options options = new Options();
        Option suiteOption = Option.builder("suite")
                .hasArg()
                .desc("TestNG Test Suite")
                .build();
        Option groupOption = Option.builder("groups")
                .hasArg()
                .optionalArg(true)
                .desc("TestNG Test Groups")
                .build();
        options.addOption(suiteOption);
        options.addOption(groupOption);

        CommandLineParser commandLineParser = new DefaultParser();
        CommandLine commandLine = commandLineParser.parse(options, args);

        String suitePath = commandLine.hasOption("suite") ? "src/main/resources/suites/" + commandLine.getOptionValue("suite") : "";
        String groups = commandLine.getOptionValue("groups");

        System.out.println("Suite is " + suitePath);
        System.out.println("Groups are " + groups);

        // -------- TestNG --------
        TestNG testNG = new TestNG();

        // Suite
        List<String> suites = new ArrayList<>();
        if (!suitePath.isEmpty()) {
            suites.add(suitePath);
        }
        testNG.setTestSuites(suites);

        // Groups
        if (groups != null && !groups.isEmpty()){
            testNG.setGroups(groups);
        }

        // Execute
        testNG.run();
    }
}