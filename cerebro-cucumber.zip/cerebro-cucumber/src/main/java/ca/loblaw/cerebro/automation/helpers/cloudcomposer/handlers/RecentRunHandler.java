package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseDagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import org.assertj.core.api.Assertions;

public class RecentRunHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseDagRun responseDagRun = (AirflowResponseDagRun) airflowResponseItem;

        // Recent run found
        if (responseDagRun.getDagRunId() != null) {

            // Update
            dagRun.setDagRunId(responseDagRun.getDagRunId());
            dagRun.setState(AirflowState.from(responseDagRun.getState()));
        }
    }
}
