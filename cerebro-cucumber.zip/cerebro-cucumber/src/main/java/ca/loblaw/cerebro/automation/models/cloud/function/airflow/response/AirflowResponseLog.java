package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.ComposerMetadataLog;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowResponseLog extends AirflowResponseItem {

    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("dag_run_id")
    private String dagRunId;

    @JsonProperty("logs")
    private ComposerMetadataLog logs;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public ComposerMetadataLog getLogs() {
        return logs;
    }

    public void setLogs(ComposerMetadataLog logs) {
        this.logs = logs;
    }
}
