package ca.loblaw.cerebro.automation.steps.filerouting;

import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.testcases.filerouting.FileRoutingTest;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.CerebroPatterns;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.SoftAssertions;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Validator class to validate file routing results.
 */
public class FileRoutingValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(FileRoutingValidator.class);

    public FileRoutingValidator() {
        super();
    }

    /**
     * Compares each landing file and raw file from {@code landingCloudFiles} and {@code rawCloudFiles}.
     * It is expected that both lists are of the same size, and that an index used to find a landing file
     * in {@code landingCloudFiles} can be used to find its counterpart raw file in {@code rawCloudFiles}.
     *
     * Validations include
     *      - Raw file is present
     *      - UUID value has correct format
     *      - Same UUID value in blob metadata
     *
     * @param landingCloudFiles List of landing files
     * @param rawCloudFiles List of raw files. May contain null to represent no raw file counterpart.
     */
    public static void validateLandingAndRawCloudFiles(List<CloudStorageFile> landingCloudFiles, List<CloudStorageFile> rawCloudFiles, String... stages) {
        SoftAssertions fileRoutedAssertions = new SoftAssertions();
        SoftAssertions fileDetailsAssertions = new SoftAssertions();

        String uuidKey = "uuid-" + TestContext.ENV;

        for (int cloudIndex = 0; cloudIndex < landingCloudFiles.size(); cloudIndex++) {
            CloudStorageFile landingFile = landingCloudFiles.get(cloudIndex);
            CloudStorageFile rawFile = rawCloudFiles.get(cloudIndex);

            String landingFileName = landingFile.getName();

            // Fail and continue to next landing file if raw file not found
            if (rawFile == null) {
                fileRoutedAssertions.fail("No raw file found for landing file %s", landingFileName);
                continue;
            }

            String rawFileName = rawFile.getName();

            // Validate UUID for non-dfm files
            if (!landingFile.getName().endsWith(".dfm")) {
                fileDetailsAssertions.assertThat(landingFile.getMetadata().containsKey(uuidKey))
                        .as("Check landing file %s has UUID present", landingFileName)
                        .isTrue();
                fileDetailsAssertions.assertThat(rawFile.getMetadata().containsKey(uuidKey))
                        .as("Check raw file %s has UUID present", rawFileName)
                        .isTrue();

                if (landingFile.getMetadata().containsKey(uuidKey) && rawFile.getMetadata().containsKey(uuidKey)) {
                    String landingFileUuid = landingFile.getMetadata().get(uuidKey);
                    String rawFileUuid = rawFile.getMetadata().get(uuidKey);

                    fileDetailsAssertions.assertThat(landingFileUuid)
                            .as("Check landing file %s UUID pattern", landingFileName)
                            .matches(CerebroPatterns.UUID);
                    fileDetailsAssertions.assertThat(rawFileUuid)
                            .as("Check raw file %s UUID pattern", rawFileName)
                            .matches(CerebroPatterns.UUID);
                    fileDetailsAssertions.assertThat(landingFileUuid)
                            .as("Compare landing file %s and raw file %s UUID", landingFileName, rawFileName)
                            .isEqualTo(rawFileUuid);
                }
            }
        }

        fileRoutedAssertions.assertAll();
        String printStages = String.join(",", stages);
        Reporter.pass(LOG, "All landing files were found in raw bucket ({})", printStages);

        fileDetailsAssertions.assertAll();
        Reporter.pass(LOG, "All landing and raw files have correct UUIDs");
    }
}
