package ca.loblaw.cerebro.automation.utils.reports.excel;

import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.*;

import java.util.List;

public class ComposerDagRunExcelReportGenerator extends ExcelReportGenerator<List<DagRun>> {

    public ComposerDagRunExcelReportGenerator() {
        // Colours
        XSSFColor lightPink = new XSSFColor(getColorBytes(255, 173, 173));
        XSSFColor lightYellow = new XSSFColor(getColorBytes(255, 255, 180));
        XSSFColor lightGreen = new XSSFColor(getColorBytes(180, 238, 180));
        XSSFColor lightOrange = new XSSFColor(getColorBytes(255, 216, 150));
        XSSFColor lightBlue = new XSSFColor(getColorBytes(173, 216, 230));

        // CellStyles
        putCellStyle("error", createCellStyle(lightPink));
        putCellStyle("success", createCellStyle(lightGreen));
        putCellStyle("undetermined", createCellStyle(lightYellow));
        putCellStyle("warning", createCellStyle(lightOrange));
        putCellStyle("inconclusive", createCellStyle(lightBlue));
    }

    private byte[] getColorBytes(int r, int g, int b) {
        return new byte[] {(byte) r, (byte) g, (byte) b};
    }

    @Override
    public void reportResults(List<String> headers, List<DagRun> dagRuns) {
        XSSFSheet sheet = reportWorkbook.createSheet(sheetName);

        // Fonts
        XSSFFont headerFont = reportWorkbook.createFont();
        headerFont.setBold(true);

        // Headers
        XSSFRow headerRow = sheet.createRow(0);
        for (int col = 0; col < headers.size(); col++) {
            XSSFRichTextString text = new XSSFRichTextString(headers.get(col));
            text.applyFont(headerFont);

            XSSFCell cell = headerRow.createCell(col);
            cell.setCellType(CellType.STRING);
            cell.setCellValue(text);
        }

        // Results
        for (int row = 0; row < dagRuns.size(); row++) {
            int excelRow = row + 1;

            DagRun dagRun = dagRuns.get(row);

            XSSFRow resultRow = sheet.createRow(excelRow);
            XSSFCellStyle cellStyle = determineCellStyle(dagRun);

            int colCounter = 0;

            // Create result cells
            String[] results = new String[] {
                    dagRun.getDagId(),
                    dagRun.isPaused() ? "paused" : "",
                    dagRun.getDagRunId(),
                    dagRun.getState() != null ? dagRun.getState().getState() : "",
                    dagRun.getError(),
                    String.valueOf(dagRun.hasMetadataLog()),
                    dagRun.getUpstreamDag() == null ? "" : dagRun.getUpstreamDag().getDagId(),
                    generateTaskInstancesString(dagRun)
            };

            for (String result : results) {
                createDagInfoCell(resultRow, colCounter++, result, cellStyle);
            }
        }
    }

    private String generateTaskInstancesString(DagRun dagRun) {
        StringBuilder taskInstanceString = new StringBuilder();
        taskInstanceString.append("{ ");
        for (TaskInstance taskInstance : dagRun.getTaskInstances()) {
            taskInstanceString.append(", ").append(taskInstance.getTaskId()).append(" = ").append(taskInstance.getState());
        }
        taskInstanceString.append(" }");
        return StringUtils.replaceOnce(taskInstanceString.toString(), ", ", "");
    }

    /*
     * Determines cell style to apply based on properties of DagRun object.
     *
     * error: DagRun failed or has errors or is successful but no metadata logs generated.
     * undetermined: DagRun does not have success or failed state.
     * warning: DagRun task instances are not the same as task lists, or another_dag_is_running is success.
     * success: None of the above applies.
     */
    private XSSFCellStyle determineCellStyle(DagRun dagRun) {
        if (dagRun.getState() == AirflowState.FAILED || !dagRun.hasNoError() ||
                dagRun.taskInstanceIsState("another_dag_is_running", AirflowState.SUCCESS)) {
            return getCellStyle("error");
        } else if (!dagRun.hasRunId()) {
            return getCellStyle("undetermined");
        } else if (dagRun.isOutdated() || dagRun.getState() != AirflowState.SUCCESS) {
            return getCellStyle("warning");
        } else {
            return getCellStyle("success");
        }
    }

    private void createDagInfoCell(XSSFRow resultRow, int col, String dagFieldValue, CellStyle cellStyle) {
        XSSFCell cell = resultRow.createCell(col);
        cell.setCellType(CellType.STRING);
        cell.setCellValue(dagFieldValue);

        if (cellStyle != null) {
            cell.setCellStyle(cellStyle);
        }
    }
}
