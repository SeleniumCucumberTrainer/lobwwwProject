package ca.loblaw.cerebro.automation.steps.endtoend;

import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;
import ca.loblaw.cerebro.automation.helpers.querybuilder.template.complex.SourceTargetValidationQuery;
import ca.loblaw.cerebro.automation.helpers.querybuilder.template.single.SingleSourceQuery;
import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.cloud.bigquery.BigQueryUtils;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import ca.loblaw.cerebro.automation.utils.reports.excel.DataIntegrityExcelReportGenerator;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FieldValue;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.TableResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class EndToEndTablesValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(EndToEndTablesValidator.class);
    private static final String SQL_TEMPLATES_PATH = "src/main/resources/configs/sqltemplates/EndToEndSQL.properties";
    private static final Map<String, String> SQL_TEMPLATES;

    static {
        try {
            SQL_TEMPLATES = PropertiesFileUtils.readPropertiesFileToMap(SQL_TEMPLATES_PATH);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    // Ingestion
    //------------------------------------------------------------------------------------------------------------------

    public static void validateExternalAndIngestionTableFilesRecordCount(String externalTable, String ingestionTable,
                                                                         String ingestionRecCreTms, List<CloudStorageFile> batchFiles) throws InterruptedException {
        SingleSourceQuery externalTableFilesRecordCountQuery = new SingleSourceQuery()
                .setTemplate(SQL_TEMPLATES.get("externalTableFilesRecordCount"))
                .setTableName(externalTable);

        SingleSourceQuery ingestionTableFilesRecordCountQuery = new SingleSourceQuery()
                .setTemplate(SQL_TEMPLATES.get("ingestionTableFilesRecordCount"))
                .setTableName(ingestionTable)
                .setTimestamp(ingestionRecCreTms)
                .setFiles(batchFiles);

        String recordCountFilesQuery = new SourceTargetValidationQuery()
                .setTemplate(SQL_TEMPLATES.get("filesRecordCountQuery"))
                .setSourceQuery(externalTableFilesRecordCountQuery.build())
                .setTargetQuery(ingestionTableFilesRecordCountQuery.build())
                .build();

        TableResult tableResult = BigQueryUtils.executeQuery(recordCountFilesQuery);

        boolean hasError = false;
        for (FieldValueList row : tableResult.iterateAll()) {
            if (row.get("test_result").getStringValue().equals("Failed")) {
                hasError = true;
                Reporter.error(LOG, "File {} has {} rows in External table, but has {} rows in Ingestion table",
                        row.get("file_name").getStringValue(),
                        (int) row.get("source_record_count").getLongValue(),
                        (int) row.get("target_record_count").getLongValue());
            }
        }

        // Report result
        if (hasError) {
            Assertions.fail("Not all batch files had matching number of records in External table and Ingestion table");
        } else {
            Reporter.pass(LOG, "All batch files have matching number of records in External table and Ingestion table");
        }
    }

    public static void validateExternalAndIngestionTableTotalRecordCount(int externalTableRecordCount, int ingestionTableRecordCount) {
        Assertions.assertThat(externalTableRecordCount)
                .as("Record count comparison between External table and Ingestion table")
                .isEqualTo(ingestionTableRecordCount);
        Reporter.pass(LOG, "Record count comparison between External table and Ingestion table matched!");
    }

    public static void validateExternalAndIngestionTableDataIntegrity(String externalTable, String ingestionTable,
                                                                      String ingestionRecCreTms, List<Column> ingestionColumns,
                                                                      List<CloudStorageFile> batchDataRawFiles, String reportName) {
        String sourceQuery = new SingleSourceQuery()
                .setTemplate(SQL_TEMPLATES.get("externalTableData"))
                .setTableName(externalTable)
                .setColumns(ingestionColumns)
                .build();

        String targetQuery = new SingleSourceQuery()
                .setTemplate(SQL_TEMPLATES.get("ingestionTableData"))
                .setTableName(ingestionTable)
                .setColumns(ingestionColumns)
                .setFiles(batchDataRawFiles)
                .setTimestamp(ingestionRecCreTms)
                .build();

        validateBigQueryTableHasRecords(externalTable, sourceQuery);
        validateBigQueryTableHasRecords(ingestionTable, targetQuery);

        // Create and execute data integrity query
        String dataIntegrityQuery = new SourceTargetValidationQuery()
                .setSourceQuery(sourceQuery)
                .setTargetQuery(targetQuery)
                .setTemplate(SQL_TEMPLATES.get("dataIntegrityQuery"))
                .build();

        try {
            TableResult tableResult = BigQueryUtils.executeQuery(dataIntegrityQuery);
            reportDataIntegrityResults(tableResult, reportName);

            Assertions.assertThat(tableResult.getTotalRows())
                    .as(String.format("Data integrity validation found %s invalid rows",tableResult.getTotalRows()))
                    .isEqualTo(0);
            Reporter.info(LOG, "Data Integrity for Ingestion passed");
        } catch (InterruptedException e) {
            Reporter.error(LOG, "Failed to execute data integrity query for Ingestion");
            throw new RuntimeException(e);
        }
    }

    private static void reportDataIntegrityResults(TableResult tableResult, String reportName) {
        if (tableResult.getTotalRows() > 0) {
            List<String> headers = new ArrayList<>();
            List<String> rows = new ArrayList<>();

            for (Field field : tableResult.getSchema().getFields()) {
                headers.add(field.getName());
            }

            for (FieldValueList value : tableResult.getValues()) {
                StringBuilder sb = new StringBuilder();
                for (FieldValue fieldValue : value) {
                    sb.append(",");
                    if (fieldValue.isNull()) {
                        continue;
                    }
                    sb.append(fieldValue.getStringValue());
                }
                rows.add(sb.toString().replaceFirst(",", ""));
            }

            try {
                // Generate Data integrity report
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_hhmmss");
                reportName = reportName +"_"+ sdf.format(new Date());

                DataIntegrityExcelReportGenerator report = new DataIntegrityExcelReportGenerator();
                report.setReportPath("end-to-end/data-integrity/", reportName);
                report.reportResults(headers, rows);
                report.writeToFileAndClose();
            } catch (IOException e) {
                LOG.error("Failed to report data integrity results");
            }
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    // Snapshot
    //------------------------------------------------------------------------------------------------------------------

    public static int validateAndReturnSnapshotRecordCount(String snapshotTable) throws InterruptedException {
        // Record count validation
        int snapshotTableRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM `%s`",
                        snapshotTable
                )
        );

        Reporter.info("Snapshot table record count is {}", snapshotTableRecordCount);
        Assertions.assertThat(snapshotTableRecordCount)
                .as("Snapshot table record count")
                .isGreaterThan(0);
        Reporter.pass("Snapshot table has greater than 0 records");

        return snapshotTableRecordCount;
    }

    public static String validateAndReturnSnapshotTime(String snapshotTable, String startDate, String endDate) throws InterruptedException {
        TableResult tableResult = BigQueryUtils.executeQuery(
                String.format(
                        "SELECT DISTINCT(STRING(snapshot_time)) AS snapshot_time FROM `%s` WHERE snapshot_time > '%s' AND snapshot_time < '%s'",
                        snapshotTable,
                        startDate,
                        endDate
                )
        );

        Assertions.assertThat(tableResult.getTotalRows())
                .as("Number of snapshot timestamps")
                .isEqualTo(1);

        String snapshotTime = "";
        for (FieldValueList row : tableResult.iterateAll()) {
            snapshotTime = row.get(0).getStringValue().replaceFirst("\\+.*$", "");
            break;
        }

        Reporter.pass("Snapshot time {} from snapshot table is correct", snapshotTime);

        return snapshotTime;
    }

    //------------------------------------------------------------------------------------------------------------------
    // Curation
    //------------------------------------------------------------------------------------------------------------------

    public static void validateCurationQueryAndTableFilesRecordCount(String curationSubQuery, String curationQueryFileColumnName, String curationTableName,
                                                                     String curationRecCreTms, List<CloudStorageFile> batchFiles, int maxMissingRows) throws InterruptedException {
        SingleSourceQuery curationQueryFilesRecordCountQuery = new SingleSourceQuery()
                .setTemplate(SQL_TEMPLATES.get("curationQueryFilesRecordCount"))
                .setSubQuery(curationSubQuery)
                .setFileColumnName(curationQueryFileColumnName)
                .setFiles(batchFiles);

        SingleSourceQuery curationTableFilesRecordCountQuery = new SingleSourceQuery()
                .setTemplate(SQL_TEMPLATES.get("curationTableFilesRecordCount"))
                .setTableName(curationTableName)
                .setTimestamp(curationRecCreTms)
                .setFiles(batchFiles);

        String recordCountFilesQuery = new SourceTargetValidationQuery()
                .setTemplate(SQL_TEMPLATES.get("filesRecordCountQuery"))
                .setSourceQuery(curationQueryFilesRecordCountQuery.build())
                .setTargetQuery(curationTableFilesRecordCountQuery.build())
                .build();

        TableResult tableResult = BigQueryUtils.executeQuery(recordCountFilesQuery);

        int totalMissingRows = 0;
        for (FieldValueList row : tableResult.iterateAll()) {
            if (row.get("test_result").getStringValue().equals("Failed")) {
                totalMissingRows++;
                Reporter.info(LOG, "File {} has {} rows in Curation query, but has {} rows in Curation table",
                        row.get("file_name").getStringValue(),
                        (int) row.get("source_record_count").getLongValue(),
                        (int) row.get("target_record_count").getLongValue());
            }
        }

        // Report result
        if (totalMissingRows > maxMissingRows) {
            Assertions.fail("Total number of missing records (%d) from all files were greater than allowed (%d)", totalMissingRows, maxMissingRows);
        } else {
            Reporter.pass(LOG, "All batch files have expected number of records from Curation query in Curation table");
        }
    }

    public static void validateCurationQueryAndTableTotalRecordCount(String curationQuery, int curationTableRecordCount, int maxErrors) throws InterruptedException {
        int curationQueryRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM (%s)",
                        curationQuery
                )
        );

        Assertions.assertThat(curationQueryRecordCount)
                .as("Curation query record count")
                .isEqualTo(curationTableRecordCount + maxErrors);
        Reporter.pass(LOG, "Curation query record count = curation table record count + error records in Dataflow");
    }

    //------------------------------------------------------------------------------------------------------------------
    // Publication
    //------------------------------------------------------------------------------------------------------------------


    //------------------------------------------------------------------------------------------------------------------
    // Helpers
    //------------------------------------------------------------------------------------------------------------------
    public static int retrieveBigQueryTableRecordCount(String recordCountQuery) throws InterruptedException {
        TableResult result = BigQueryUtils.executeQuery(recordCountQuery);

        Assertions.assertThat(result.getTotalRows())
                .as("Record count rows")
                .isEqualTo(1);

        int recordCount = 0;
        for (FieldValueList row : result.iterateAll()) {
            recordCount = row.get("record_count").getNumericValue().intValue();
            break;
        }

        return recordCount;
    }

    private static void validateBigQueryTableHasRecords(String tableName, String query) {
        try {
            TableResult result = BigQueryUtils.executeQuery(query);
            Assertions.assertThat(result.getTotalRows())
                    .as("No records found in table - " + tableName)
                    .isGreaterThan(0);
        } catch (InterruptedException e) {
            LOG.error("Failed to check if table has records - " + tableName);
            throw new RuntimeException(e);
        }
    }
}
