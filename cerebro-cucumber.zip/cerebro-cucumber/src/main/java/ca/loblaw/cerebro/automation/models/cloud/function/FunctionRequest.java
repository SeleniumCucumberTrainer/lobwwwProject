package ca.loblaw.cerebro.automation.models.cloud.function;

public interface FunctionRequest {
}
