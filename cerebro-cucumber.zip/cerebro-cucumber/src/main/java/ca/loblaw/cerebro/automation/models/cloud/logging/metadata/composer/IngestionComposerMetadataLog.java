package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IngestionComposerMetadataLog extends ComposerMetadataLog {

    @JsonProperty("cc_src_nm")
    private String sourceName;
    @JsonProperty("cc_tgt_nm")
    private String targetName;

    @JsonProperty("cc_no_rows_loaded")
    private String numberRowLoaded;

    @JsonProperty("cc_no_src_entity_present")
    private String numberSourceEntityPresent;

    @JsonProperty("cc_file_processed_tms")
    private String fileProcessedTimestamp;

    @JsonProperty("cc_file_reject_tms")
    private String fileRejectTimestamp;

    @JsonProperty("cc_file_working_tms")
    private String fileWorkingTimestamp;

    @JsonProperty("cc_df_rec_ct_match")
    private String composerAndDataflowRecordCountMatch;

    // Dataflow
    @JsonProperty("df_job_nm")
    private String dataflowJobName;

    @JsonProperty("df_job_run_id")
    private String dataflowJobRunId;

    @JsonProperty("df_job_execution_strt_tms")
    private String dataflowJobExecutionStartTime;

    @JsonProperty("df_job_execution_end_tms")
    private String dataflowJobExecutionEndTime;

    @JsonProperty("df_job_elpsd_tms")
    private String dataflowJobElapsedTime;

    @JsonProperty("df_execution_rslt")
    private String dataflowJobResult;

    @JsonProperty("df_all_file_nbrs_rows_parsed")
    private String dataflowAllRowsParsedCount;

    @JsonProperty("df_all_file_nbrs_err_rows")
    private String dataflowAllErrorRowsCount;

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
    }

    public String getNumberRowLoaded() {
        return numberRowLoaded;
    }

    public void setNumberRowLoaded(String numberRowLoaded) {
        this.numberRowLoaded = numberRowLoaded;
    }

    public String getNumberSourceEntityPresent() {
        return numberSourceEntityPresent;
    }

    public void setNumberSourceEntityPresent(String numberSourceEntityPresent) {
        this.numberSourceEntityPresent = numberSourceEntityPresent;
    }

    public String getFileProcessedTimestamp() {
        return fileProcessedTimestamp;
    }

    public void setFileProcessedTimestamp(String fileProcessedTimestamp) {
        this.fileProcessedTimestamp = fileProcessedTimestamp;
    }

    public String getFileRejectTimestamp() {
        return fileRejectTimestamp;
    }

    public void setFileRejectTimestamp(String fileRejectTimestamp) {
        this.fileRejectTimestamp = fileRejectTimestamp;
    }

    public String getFileWorkingTimestamp() {
        return fileWorkingTimestamp;
    }

    public void setFileWorkingTimestamp(String fileWorkingTimestamp) {
        this.fileWorkingTimestamp = fileWorkingTimestamp;
    }

    public String getDataflowJobName() {
        return dataflowJobName;
    }

    public void setDataflowJobName(String dataflowJobName) {
        this.dataflowJobName = dataflowJobName;
    }

    public String getDataflowJobRunId() {
        return dataflowJobRunId;
    }

    public void setDataflowJobRunId(String dataflowJobRunId) {
        this.dataflowJobRunId = dataflowJobRunId;
    }

    public String getDataflowJobExecutionStartTime() {
        return dataflowJobExecutionStartTime;
    }

    public void setDataflowJobExecutionStartTime(String dataflowJobExecutionStartTime) {
        this.dataflowJobExecutionStartTime = dataflowJobExecutionStartTime;
    }

    public String getDataflowJobExecutionEndTime() {
        return dataflowJobExecutionEndTime;
    }

    public void setDataflowJobExecutionEndTime(String dataflowJobExecutionEndTime) {
        this.dataflowJobExecutionEndTime = dataflowJobExecutionEndTime;
    }

    public String getDataflowJobElapsedTime() {
        return dataflowJobElapsedTime;
    }

    public void setDataflowJobElapsedTime(String dataflowJobElapsedTime) {
        this.dataflowJobElapsedTime = dataflowJobElapsedTime;
    }

    public String getDataflowJobResult() {
        return dataflowJobResult;
    }

    public void setDataflowJobResult(String dataflowJobResult) {
        this.dataflowJobResult = dataflowJobResult;
    }

    public String getComposerAndDataflowRecordCountMatch() {
        return composerAndDataflowRecordCountMatch;
    }

    public void setComposerAndDataflowRecordCountMatch(String composerAndDataflowRecordCountMatch) {
        this.composerAndDataflowRecordCountMatch = composerAndDataflowRecordCountMatch;
    }

    public String getDataflowAllRowsParsedCount() {
        return dataflowAllRowsParsedCount;
    }

    public void setDataflowAllRowsParsedCount(String dataflowAllRowsParsedCount) {
        this.dataflowAllRowsParsedCount = dataflowAllRowsParsedCount;
    }

    public String getDataflowAllErrorRowsCount() {
        return dataflowAllErrorRowsCount;
    }

    public void setDataflowAllErrorRowsCount(String dataflowAllErrorRowsCount) {
        this.dataflowAllErrorRowsCount = dataflowAllErrorRowsCount;
    }
}
