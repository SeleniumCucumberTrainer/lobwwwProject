package ca.loblaw.cerebro.automation.utils.contexts;

/**
 * Available Cerebro projects.
 */
public enum Project {
    LANDING_ZONE("lt-dia-lake-prd-landing", "${LANDING_ZONE}"),
    RAW_ZONE("lt-dia-lake-${ENV}-raw", "${RAW_ZONE}"),
    TECHDATA_ZONE("lt-dia-lake-${ENV}-techdata", "${TECHDATA_ZONE}"),
    TECHCOMPUTE_ZONE("lt-dia-lake-${ENV}-techcompute", "${TECHCOMPUTE_ZONE}"),
    CONSUME_ZONE("lt-dia-lake-${ENV}-consume", "${CONSUME_ZONE}"),
    FULFILLMENT_ZONE(" lt-dia-lake-${ENV}-fulfillment", "${FULFILLMENT_ZONE}"),
    OBSERVABILITY_ZONE("lt-dia-lake-${ENV}-observability", "${OBSERVABILITY_ZONE}"),
    INTEGRATION_ZONE("lt-dia-lake-${ENV}-integration", "${INTEGRATION_ZONE}"),
    REPORTING_ZONE("lt-dia-lake-${ENV}-reporting", "${REPORTING_ZONE}");

    private String name;
    private String template;

    public static Project from(String projectName) {
        for(Project project : Project.values()) {
            if (project.getName().equals(projectName)) {
                return project;
            }
        }

        throw new EnumConstantNotPresentException(Project.class, projectName);
    }

    Project(String name, String template) {
        this.name = TestContext.replaceTemplateEnv(name);
        this.template = template;
    }

    public String getName() {
        return name;
    }

    public String getTemplate() {
        return template;
    }
}
