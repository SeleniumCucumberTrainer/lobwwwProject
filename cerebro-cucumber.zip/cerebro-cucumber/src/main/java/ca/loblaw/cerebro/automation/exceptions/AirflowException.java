package ca.loblaw.cerebro.automation.exceptions;

public class AirflowException extends RuntimeException {

    public AirflowException(String message) {
        super(message);
    }

    public AirflowException(String message, Object... args) {
        super(String.format(message, args));
    }
}
