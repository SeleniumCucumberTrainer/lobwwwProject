package ca.loblaw.cerebro.automation.utils.internal.bash;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class BashExecutor {
    private static final Logger log = Logger.getLogger(BashExecutor.class.getName());

    public static BashOutput executeCommand (String cmd) throws Exception {

        String[] arrCommand = cmd.split(" ");

        log.info(String.format("Please wait... Executing %s", cmd));

        BashOutput bashOutput = new BashOutput();


        String os = System.getProperty("os.name");
        Process p;
        if(os.equalsIgnoreCase("linux") || os.equalsIgnoreCase("mac os x")){
            ProcessBuilder pb = new ProcessBuilder();
            String project = TestContext.getTestRegion("${ZONE}");
            System.out.println(project);
            if(project.toLowerCase().contains("ful"))
            pb.command("/bin/bash","-c",cmd);

           else if (project.toLowerCase().contains("tec")){
                pb.command().add("script");
                pb.command().add("-c");
                pb.command().add(cmd);
                pb.command().add("-f");
                pb.command().add("-q");
            }

            p = pb.start();
        } else if(cmd.contains("gcloud functions call")){
            p = Runtime.getRuntime().exec(cmd);
        } else {
            p = Runtime.getRuntime().exec(arrCommand);

        }


        BufferedReader stdOut=new BufferedReader(new InputStreamReader(p.getInputStream()));
        String s;
        List<String> successOutput = new ArrayList<>();

        while((s=stdOut.readLine())!=null){
//            System.out.println("added "+s);
            successOutput.add(s);
        }
        bashOutput.setOutput(successOutput);
//        System.out.println(bashOutput.getOutput());

        try{
            p.waitFor();
            int status =p.exitValue();
            BufferedReader processErrorReader =
                    new BufferedReader(new InputStreamReader(p.getErrorStream()));

            bashOutput.setStatus(status);
            String str = null;
            if (status == 0) {
                int count = 0;
                log.info(String.format("Execution (%s) success", cmd));
            } else {
                log.info(String.format("Execution (%s) failed", cmd));
                List<String> errorOutput = new ArrayList<>();
                while ((str = processErrorReader.readLine()) != null) {
                    errorOutput.add(str);
                }
                bashOutput.setError(errorOutput);
                System.out.println(bashOutput.getError());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            //System.out.println("Error in gs command.");
        }


        return bashOutput;
    }
}
