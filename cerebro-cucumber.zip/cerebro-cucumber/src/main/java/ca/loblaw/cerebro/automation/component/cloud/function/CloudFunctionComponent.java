package ca.loblaw.cerebro.automation.component.cloud.function;

import ca.loblaw.cerebro.automation.component.CloudComponent;
import ca.loblaw.cerebro.automation.component.ComponentType;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagType;
import ca.loblaw.cerebro.automation.models.cloud.function.FunctionRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.FunctionResponse;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunction;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;

/**
 * Abstract representational class for a specific Cloud Function.
 *
 * @param <T> Valid request object for the Cloud Function.
 * @param <V> Valid response object for the Cloud Function.
 */
public abstract class CloudFunctionComponent<T extends FunctionRequest, V extends FunctionResponse> implements CloudComponent {

    private final CloudFunction cloudFunction; // Underlying Cloud Function

    public CloudFunctionComponent(CloudFunction cloudFunction) {
        this.cloudFunction = cloudFunction;
    }

    public abstract V execute(T functionRequest) throws IOException;
    public abstract void validateRequestJson(JsonNode requestJsonNode);
    public abstract void validateResponseJson(JsonNode responseJsonNode);


    @Override
    public ComponentType getComponentType() {
        return ComponentType.CLOUD_FUNCTION;
    }

    @Override
    public Project getProject() {
        return Project.from(cloudFunction.getProject());
    }

    public CloudFunction getCloudFunction() {
        return cloudFunction;
    }
}
