package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"Smoke","TechCompute"})
public class TC01_csv2bq_ingestionTest extends TechComputeCommonFun{
;    public TC01_csv2bq_ingestionTest() throws IOException {
        super("TC01_csv2bq_ingestionTestData.properties");

    }

}
