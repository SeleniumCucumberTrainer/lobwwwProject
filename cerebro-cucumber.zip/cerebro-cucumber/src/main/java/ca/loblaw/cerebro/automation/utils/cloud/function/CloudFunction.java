package ca.loblaw.cerebro.automation.utils.cloud.function;

import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import com.google.api.client.http.*;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.IdTokenCredentials;
import com.google.auth.oauth2.IdTokenProvider;

import java.io.IOException;
import java.util.Map;

/**
 * class representation of a Google Cloud Function that receives an HTTP request
 * and returns an HTTP response.
 */
public class CloudFunction {
    private final String project; // Google Cloud project
    private final String region; // Cloud Function region
    private final String functionName; // Cloud Function name

    // HTTP information
    private final String url; // Cloud Function HTTP request URL
    private final HttpRequestFactory requestFactory;

    /**
     * Cloud Function Builder
     */
    public static class Builder {
        private String project;
        private String region;
        private String functionName;

        public Builder fromPropertiesFile(String propertiesFilePath) throws IOException {
            Map<String, String> cloudFunctionProperties = PropertiesFileUtils.readPropertiesFileToMap(propertiesFilePath);
            setProject(cloudFunctionProperties.get("project"));
            setRegion(cloudFunctionProperties.get("region"));
            setFunctionName(cloudFunctionProperties.get("functionName"));
            return this;
        }

        public Builder setProject(String project) {
            this.project = project;
            return this;
        }

        public Builder setRegion(String region) {
            this.region = region;
            return this;
        }

        public Builder setFunctionName(String functionName) {
            this.functionName = functionName;
            return this;
        }

        public CloudFunction build() throws IOException {
            return new CloudFunction(project, region, functionName);
        }
    }

    private CloudFunction(String project, String region, String functionName) throws IOException {
        this.project = project;
        this.region = region;
        this.functionName = functionName;

        url = String.format("https://%s-%s.cloudfunctions.net/%s", region, project, functionName);

        // Generate token credentials
        GoogleCredentials googleCredentials = GoogleCredentials.getApplicationDefault();
        IdTokenCredentials tokenCredentials = IdTokenCredentials.newBuilder()
                .setIdTokenProvider((IdTokenProvider) googleCredentials)
                .setTargetAudience(url)
                .build();

        // Create HTTP request factory using credentials
        HttpCredentialsAdapter credentialsAdapter = new HttpCredentialsAdapter(tokenCredentials);
        requestFactory = new NetHttpTransport().createRequestFactory(credentialsAdapter);
    }

    /**
     * Invokes the underlying Cloud Function this class represents and returns the response.
     *
     * @param payload JSON payload.
     * @return HTTP response wrapped in a CloudFunctionHttpResponse object.
     * @throws IOException Error executing request.
     */
    public CloudFunctionHttpResponse trigger(String payload) throws IOException {
        HttpContent content =  ByteArrayContent.fromString("application/json", payload);
        GenericUrl genericUrl = new GenericUrl(url);

        HttpRequest request = requestFactory.buildPostRequest(genericUrl, content);
        request.setConnectTimeout(300000); // 5 minutes timeout
        request.setReadTimeout(300000); // 5 minutes timeout
        request.getHeaders().setAccept("application/json");

        // Response
        HttpResponse response = request.execute();
        return new CloudFunctionHttpResponse(response);
    }

    public String getProject() {
        return project;
    }

    public String getRegion() {
        return region;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getUrl() {
        return url;
    }
}
