package ca.loblaw.cerebro.automation.testcases.techcomputesmoke;

import org.testng.annotations.Test;



@Test(groups = {"Smoke"})
public class TC01_csv2bq_ingestionTest extends csv2bq_ingestionTestSteps {

}


