package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseXcomValue;

public class XcomValueHandler implements AirflowUpdateHandler {
    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseXcomValue responseXcomValue = (AirflowResponseXcomValue) airflowResponseItem;

        String taskId = responseXcomValue.getTaskId();
        String xcomKey = responseXcomValue.getXcomKey();
        String xcomValue = responseXcomValue.getXcomValue();

        // Store XCOM entry
        dagRun.getTaskInstance(taskId).addXcomEntry(xcomKey, xcomValue);
    }
}
