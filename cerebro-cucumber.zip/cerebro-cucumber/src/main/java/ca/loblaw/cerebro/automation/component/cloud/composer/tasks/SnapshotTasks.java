package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

public class SnapshotTasks {
    public static final String GET_TARGET_TABLE = "get_trgt_tbl";
    public static final String GET_REC_CRE_TMS = "get_rec_cre_tms";
    public static final String GET_TABLES_SQL = "get_tables_sql";
    public static final String PREPARE_SNAPSHOT_SQL = "prepare_snapshot_sql";
    public static final String LOAD_CURRENT = "load_current";
    public static final String GET_SNAPSHOT_TIME = "get_snapshot_time";
    public static final String UPDATE_FLOW_CONTROL = "update_flow_control";
    public static final String INSERT_TO_CONTROL = "insert_to_control";
    public static final String METADATA_LOG = "metadata_log";
    public static final String TRIGGER_DAG = "trigger_dag";
}
