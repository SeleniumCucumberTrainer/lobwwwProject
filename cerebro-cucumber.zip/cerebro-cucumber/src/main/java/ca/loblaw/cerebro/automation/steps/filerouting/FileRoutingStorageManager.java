package ca.loblaw.cerebro.automation.steps.filerouting;

import ca.loblaw.cerebro.automation.steps.TestStep;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileContainer;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileFieldOptions;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Test step class to interact with Landing bucket and Raw bucket for the file routing process.
 */
public class FileRoutingStorageManager implements TestStep {

    private static final Logger LOG = LogManager.getLogger(FileRoutingStorageManager.class);
    public static final String[] STAGE_FOLDERS = {"landing", "processed", "rejected", "working"};
    private static final int FILE_COPY_TIMEOUT = 220000;
    private static final int LANDING_WAIT_TIME_PER_FILE = 7000;

    private final String testFolderPath; // GCS path for folder that stores test files to be copied to landing
    private final String landingFolderPath; // GCS path for PRD-landing folder
    private final String rawFolderPath; // GCS path for raw storage folder after routing

    public FileRoutingStorageManager(String testFolderPath, String landingFolderPath, String rawFolderPath) {
        this.testFolderPath = testFolderPath;
        this.landingFolderPath = landingFolderPath;
        this.rawFolderPath = rawFolderPath;
    }

    //------------------------------------------------------------------------------------------------------------------
    // Test Folder
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Retrieve GCS paths of all test files in test folder
     * @return List of GCS paths strings
     */
    public List<String> retrieveTestFilesPaths() {
        List<CloudStorageFile> filesToCopy = CloudStorageUtils.listFiles(
                testFolderPath,
                new CloudStorageFileFieldOptions().includeName());
        List<String> testFilesToCopyPaths = CloudStorageFileContainer.wrap(filesToCopy).toGcsNamesList();

        Reporter.info(LOG, "Test files to copy: {}", testFilesToCopyPaths);
        return testFilesToCopyPaths;
    }

    /**
     * Copies all test files to landing folder.
     *
     * @param testFilesToCopyPaths List of GCS test file paths to copy.
     * @throws InterruptedException Current thread is interrupted while sleeping.
     */
    public void copyTestFilesToLandingFolder(List<String> testFilesToCopyPaths) throws InterruptedException {
        for (String testFilePath : testFilesToCopyPaths) {
            CloudStorageUtils.copyFile(testFilePath, landingFolderPath + FilenameUtils.getName(testFilePath));
        }

        Thread.sleep((long) testFilesToCopyPaths.size() * LANDING_WAIT_TIME_PER_FILE);
        Reporter.info(LOG, "Copied {} test files to landing bucket", testFilesToCopyPaths.size());
    }

    /**
     * Copies all test files, in parallel, to landing folder 'numCopies' of times.
     * The new landing files will have a count appended to the file name.
     * @param testFilesToCopyPaths List of GCS test file paths to copy.
     * @param numCopies Number of copies.
     * @throws InterruptedException Executor for copying files is interrupted while waiting.
     */
    public void copyTestFilesToLandingFolderMultiple(List<String> testFilesToCopyPaths, int numCopies) throws InterruptedException {
        // Find
        Pair<List<String>, List<String>> orderedPathsPair = getCopyAndDestinationPathsPair(testFilesToCopyPaths, numCopies);

        // Copy files from testing bucket to prd-landing-qa bucket in parallel
        ExecutorService executorService = Executors.newFixedThreadPool(orderedPathsPair.getLeft().size());
        for (int copyIndex = 0; copyIndex < orderedPathsPair.getLeft().size(); copyIndex++) {
            int finalCopyIndex = copyIndex;

            executorService.execute(() -> CloudStorageUtils.copyFile(
                    orderedPathsPair.getLeft().get(finalCopyIndex),
                    orderedPathsPair.getRight().get(finalCopyIndex)
            ));
        }
        executorService.shutdown();
        executorService.awaitTermination(FILE_COPY_TIMEOUT, TimeUnit.MILLISECONDS);

        Thread.sleep((long) numCopies * testFilesToCopyPaths.size() * LANDING_WAIT_TIME_PER_FILE);
        Reporter.info(LOG, "Copied {} test files to landing bucket", numCopies * testFilesToCopyPaths.size());
    }

    private Pair<List<String>, List<String>> getCopyAndDestinationPathsPair(List<String> testFilesToCopyPaths, int numCopies) {
        List<String> orderedFilesToCopyPaths = new ArrayList<>();
        List<String> orderedDestinationFilesPaths = new ArrayList<>();

        for (int fileIndex = 1; fileIndex <= numCopies; fileIndex++) {
            for (String fileToCopyPath : testFilesToCopyPaths) {
                orderedFilesToCopyPaths.add(fileToCopyPath);
                orderedDestinationFilesPaths.add(convertToSourceFilePath(fileToCopyPath, landingFolderPath, fileIndex));
            }
        }

        Assertions.assertThat(orderedFilesToCopyPaths.size()).isEqualTo(orderedDestinationFilesPaths.size());
        return Pair.of(orderedFilesToCopyPaths, orderedDestinationFilesPaths);
    }

    private String convertToSourceFilePath(String fileToCopyPath, String landingFolderPath, int fileIndex) {
        String localFileName = FilenameUtils.getName(fileToCopyPath);
        String[] localFileNameArr = localFileName.split("\\.", 2);
        String localFileBaseName = localFileNameArr[0];
        String localFileExtension = localFileNameArr[1];

        return landingFolderPath + localFileBaseName + fileIndex + "." + localFileExtension;
    }

    //------------------------------------------------------------------------------------------------------------------
    // Landing Folder
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Lists all Cloud Storage files in landing folder
     * @return List of CloudStorageFile representing files in landing folder
     */
    public List<CloudStorageFile> retrieveLandingFiles() {
        List<CloudStorageFile> landingCloudFiles =  CloudStorageUtils.listFiles(
                landingFolderPath,
                new CloudStorageFileFieldOptions().includeName().includeSize().includeCreateDate().includeMetadata()
        );
        Reporter.info(LOG, "Retrieved {} files from landing bucket", landingCloudFiles.size());
        return landingCloudFiles;
    }

    /**
     * Deletes Cloud Storage landing folder and everything in the folder
     */
    public void cleanLandingFolder() {
        CloudStorageUtils.deleteFolder(landingFolderPath);
        LOG.info("Cleaned landing bucket {}", landingFolderPath);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Raw Folder
    //------------------------------------------------------------------------------------------------------------------

    public List<CloudStorageFile> retrieveRawFiles(String stage) {
        List<CloudStorageFile> rawCloudFiles = CloudStorageUtils.listFiles(
                rawFolderPath.replace("...", stage),
                new CloudStorageFileFieldOptions().includeName().includeSize().includeCreateDate().includeMetadata()
        );

        Reporter.info(LOG, "Retrieved all {} files from raw bucket {} stage folder", rawCloudFiles.size(), stage);
        return rawCloudFiles;
    }

    /**
     * Finds and retrieves list of all Cloud Storage raw files from their respective landing files.
     * If a raw file is not found, null is added to the list.
     *
     * @param landingFiles List of Cloud Storage landing files.
     * @param stages List of stage folders to check in raw zone for routed files.
     * @return List of Cloud Storage raw files.
     */
    public List<CloudStorageFile> findRawCloudFilesFromLandingFiles(List<CloudStorageFile> landingFiles, String... stages) {
        List<String> rawCloudFilesPaths = getRawBucketFileNamesFromLandingFiles(landingFiles);
        return findRawCloudFilesInStages(rawCloudFilesPaths, "routed landing files", stages);
    }

    /**
     * Finds and retrieves list of all Cloud Storage raw files in target stage associated raw files
     * originally found in a starting stage.
     * If a raw file is not found, null is added to the list.
     *
     * @param rawFiles List of Cloud Storage raw files in starting stage.
     * @param startingStage Starting stage folder.
     * @param targetStage Stage folder to check for moved raw files.
     * @return List of Cloud Storage raw files.
     */
    public List<CloudStorageFile> findRawCloudFilesInStageFromStage(List<CloudStorageFile> rawFiles, String startingStage, String targetStage) {
        List<String> rawCloudFilesPaths = rawFiles.stream()
                .map(file -> file.getName().replaceFirst(startingStage, "..."))
                .collect(Collectors.toList());
        return findRawCloudFilesInStages(rawCloudFilesPaths, "raw files moved from " + startingStage, targetStage);
    }

    private List<CloudStorageFile> findRawCloudFilesInStages(List<String> rawCloudFilesPaths, String fileMessage, String... stages) {
        List<CloudStorageFile> rawCloudFiles = new ArrayList<>();

        // Cloud Storage file object equivalents from the given raw cloud files paths
        int findCounter = 0;

        outerTargetFilesLoop: for (String rawCloudFilePath : rawCloudFilesPaths) {
            for (String ingestionFolder : stages) {
                if (CloudStorageUtils.doesFileExist(rawCloudFilePath.replace("...", ingestionFolder))) {
                    // File found in a raw folder
                    CloudStorageFile targetFile = CloudStorageUtils.getFile(
                            rawCloudFilePath.replace("...", ingestionFolder),
                            new CloudStorageFileFieldOptions().includeName().includeSize().includeCreateDate().includeMetadata()
                    );
                    rawCloudFiles.add(targetFile);
                    findCounter++;

                    // No need to search other stage folders since raw file can only be in 1 stage folder at a time
                    continue outerTargetFilesLoop;
                }
            }

            // File not found in any raw folder
            rawCloudFiles.add(null);
        }

        Assertions.assertThat(rawCloudFiles.size()).isEqualTo(rawCloudFilesPaths.size());
        String printStages = String.join(",", stages);
        Reporter.info(LOG, "Found {} {} in raw bucket ({})", findCounter, fileMessage, printStages);
        return rawCloudFiles;
    }

    /**
     * Finds and deletes list of all Cloud Storage raw files from their respective landing files.
     * @param landingFiles List of Cloud Storage landing files.
     */
    public void cleanUpRawFolderFiles(List<CloudStorageFile> landingFiles) {
        List<String> rawCloudFilesPaths = getRawBucketFileNamesFromLandingFiles(landingFiles);

        outerTargetFilesLoop:
        for (String rawCloudFilePath : rawCloudFilesPaths) {
            for (String ingestionFolder : STAGE_FOLDERS) {
                if (CloudStorageUtils.doesFileExist(rawCloudFilePath.replace("...", ingestionFolder))) {
                    // Delete raw folder cloud file
                    boolean isDeleted = CloudStorageUtils.deleteFile(rawCloudFilePath.replace("...", ingestionFolder));
                    if (isDeleted) {
                        continue outerTargetFilesLoop;
                    } else {
                        LOG.warn("{} failed to be deleted", FilenameUtils.getName(rawCloudFilePath));
                    }
                }
            }
            LOG.warn( "{} was not found for deletion", FilenameUtils.getName(rawCloudFilePath));
        }
    }

    private List<String> getRawBucketFileNamesFromLandingFiles(List<CloudStorageFile> landingFiles) {
        List<String> rawCloudFilesPaths = new ArrayList<>();
        for (CloudStorageFile landingCloudFile : landingFiles) {
            String landingCloudFileName = FilenameUtils.getName(landingCloudFile.getName());
            String rawCloudFilePath = rawFolderPath + landingCloudFileName;

            rawCloudFilesPaths.add(rawCloudFilePath);
        }
        return rawCloudFilesPaths;
    }
}
