package ca.loblaw.cerebro.automation.models.validations;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;

public class IngestionComposerValidationDto {

    DagRun dagRun;
    String rawFolderPath;
    String jobRunTraceId;
    String datasetTable;
    String recCreTms;
    String dataflowJobId;
    String dataflowJobName;
    int tableRecordCount;
    int dataflowRecordCount;
    int dataflowErrorCount;
    int batchRawFilesSize;

    public IngestionComposerValidationDto() {}

    public IngestionComposerValidationDto setDagRun(DagRun dagRun) {
        this.dagRun = dagRun;
        return this;
    }

    public IngestionComposerValidationDto setRawFolderPath(String rawFolderPath) {
        this.rawFolderPath = rawFolderPath;
        return this;
    }

    public IngestionComposerValidationDto setJobRunTraceId(String jobRunTraceId) {
        this.jobRunTraceId = jobRunTraceId;
        return this;
    }

    public IngestionComposerValidationDto setDatasetTable(String datasetTable) {
        this.datasetTable = datasetTable;
        return this;
    }

    public IngestionComposerValidationDto setRecCreTms(String recCreTms) {
        this.recCreTms = recCreTms;
        return this;
    }

    public IngestionComposerValidationDto setDataflowJobId(String dataflowJobId) {
        this.dataflowJobId = dataflowJobId;
        return this;
    }

    public IngestionComposerValidationDto setDataflowJobName(String dataflowJobName) {
        this.dataflowJobName = dataflowJobName;
        return this;
    }

    public IngestionComposerValidationDto setTableRecordCount(int tableRecordCount) {
        this.tableRecordCount = tableRecordCount;
        return this;
    }

    public IngestionComposerValidationDto setDataflowRecordCount(int dataflowRecordCount) {
        this.dataflowRecordCount = dataflowRecordCount;
        return this;
    }

    public IngestionComposerValidationDto setDataflowErrorCount(int dataflowErrorCount) {
        this.dataflowErrorCount = dataflowErrorCount;
        return this;
    }

    public IngestionComposerValidationDto setBatchRawFileSize(int batchRawFileSize) {
        this.batchRawFilesSize = batchRawFileSize;
        return this;
    }

    public DagRun getDagRun() {
        return dagRun;
    }

    public String getRawFolderPath() {
        return rawFolderPath;
    }

    public String getJobRunTraceId() {
        return jobRunTraceId;
    }

    public String getDatasetTable() {
        return datasetTable;
    }

    public String getRecCreTms() {
        return recCreTms;
    }

    public String getDataflowJobId() {
        return dataflowJobId;
    }

    public String getDataflowJobName() {
        return dataflowJobName;
    }

    public int getTableRecordCount() {
        return tableRecordCount;
    }

    public int getDataflowRecordCount() {
        return dataflowRecordCount;
    }

    public int getDataflowErrorCount() {
        return dataflowErrorCount;
    }

    public int getBatchRawFilesSize() {
        return batchRawFilesSize;
    }
}
