package ca.loblaw.cerebro.automation.utils.contexts;

public enum Stage {
    LANDING("landing"),
    INGESTION("ingestion"),
    SNAPSHOT("snapshot"),
    CURATION("curation"),
    PUBLICATION("publication"),
    FULFILLMENT("fulfillment");

    public static Stage from(String str) {
        for (Stage stage : Stage.values()) {
            if (stage.value.equals(str)) {
                return stage;
            }
        }
        throw new EnumConstantNotPresentException(Zone.class, str);
    }

    private String value;

    Stage(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
