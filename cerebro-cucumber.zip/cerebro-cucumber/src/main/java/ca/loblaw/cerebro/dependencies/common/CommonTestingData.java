package ca.loblaw.cerebro.dependencies.common;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;

public class CommonTestingData {

    private String testBucket = TestContext.TEST_CONFIG_MAP.get("testBucket");

    private String testDataset = TestContext.TEST_CONFIG_MAP.get("testDataset");

    public String getTestBucket() {
        return testBucket;
    }

    public String getTestDataset() {
        return testDataset;
    }
}
