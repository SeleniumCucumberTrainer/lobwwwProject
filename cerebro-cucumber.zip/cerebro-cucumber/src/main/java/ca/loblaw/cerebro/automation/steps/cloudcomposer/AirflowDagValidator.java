package ca.loblaw.cerebro.automation.steps.cloudcomposer;

import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.exceptions.DagException;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.ComposerMetadataLog;
import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;

/**
 * Validator class to validate DAG run information.
 */
public class AirflowDagValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(AirflowDagValidator.class);
    private static final String TRACE_ID_REGEX = ".*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}.*";

    public AirflowDagValidator() {
        super();
    }

    /**
     * Validates DAG metadata log. Expects metadata log to be present.
     * @param dagRun DAG run to validate.
     */
    public static void validateMetadataLog(DagRun dagRun) {
        Reporter.info(LOG,"Validating metadata log for {}", dagRun.getDagId());

        if (dagRun.hasMetadataLog()) {
            ComposerMetadataLog composerMetadataLog = dagRun.getMetadataLog();

            // Validations
            Assertions.assertThat(composerMetadataLog.getTraceIds().size())
                    .as("Metadata log has one or more trace IDs")
                    .isGreaterThan(0);
            for (String traceId : composerMetadataLog.getTraceIds()) {
                Assertions.assertThat(traceId.matches(TRACE_ID_REGEX))
                        .as("Trace ID %s should match UUID pattern", traceId)
                        .isTrue();
            }
            Assertions.assertThat(composerMetadataLog.getDagName())
                    .as("Metadata log DAG name should be correct")
                    .isEqualTo(dagRun.getDagId());
            Assertions.assertThat(composerMetadataLog.getDagRunId())
                    .as("Metadata log DAG run ID should be correct")
                    .contains(dagRun.getDagRunId());
        } else {
            Assertions.fail("Metadata log was expected, but not present for {}", dagRun.getDagId());
        }
    }

    /**
     * Validates DAG run state.
     * @param dagRun DAG run to validate.
     */
    public static void validateDagRunInfo(DagRun dagRun) {
        Reporter.info(LOG,"Validating DAG {} run info", dagRun.getDagId());

        if (dagRun.hasRunId()) {
            // Validate DAG run
            Assertions.assertThat(dagRun.getState())
                    .as("Check DAG run state")
                    .isEqualTo(AirflowState.SUCCESS);

            Reporter.pass(LOG, "DAG {} with run ID {} was successful", dagRun.getDagId(), dagRun.getDagRunId());
        } else {
            throw new DagException("DAG %s was expected to have a finished run, but did not", dagRun.getDagId());
        }
    }

    /**
     * Validate DAG run task instances.
     * @param dagRun DAG run to validate.
     */
    public static void validateDagTaskInstances(DagRun dagRun) {
        Reporter.info(LOG,"Validating DAG {} run task instances", dagRun.getDagId());

        // No task instances
        if (!dagRun.hasTaskInstances()) {
            Assertions.fail("DAG %s with run ID %s has no task instances",
                    dagRun.getDagId(), dagRun.getDagRunId());
        }
        // Outdated task instances
        else if (dagRun.isOutdated()) {
            Reporter.warn(LOG, "Skipping task instances validation due to outdated DAG run");
        }
        else {
            // Validate task instances
            SoftAssertions taskAssertions = new SoftAssertions();
            for (TaskInstance taskInstance : dagRun.getTaskInstances()) {
                taskAssertions.assertThat(taskInstance.isPassing())
                        .as("Check task %s is passing", taskInstance.getTaskId())
                        .isTrue();
            }
            taskAssertions.assertAll();
            Reporter.pass(LOG, "DAG {} with run ID {} has all tasks passing", dagRun.getDagId(), dagRun.getDagRunId());
        }
    }
}
