package ca.loblaw.cerebro.automation.utils.internal;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Utility class for parsing and handling JSON files, Jackson-annotated Java objects,
 * JSON objects, and JSON strings. It is assumed here that all Java objects used here are Jackson-annotated.
 */
public class JsonUtils {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final ObjectWriter OBJECT_WRITER = OBJECT_MAPPER.writer();
    private static final ObjectReader OBJECT_READER = OBJECT_MAPPER.reader();

    private JsonUtils() {}

    /**
     * Reads a JSON file and maps to a JSON object.
     * @param jsonFilePath Path to JSON file.
     * @return JSON object representation of the JSON file.
     * @throws IOException Error reading JSON file.
     */
    public static JsonNode readToJsonObject(String jsonFilePath) throws IOException {
        return OBJECT_MAPPER.readTree(Files.readAllBytes(Paths.get(jsonFilePath)));
    }

    /**
     * Writes a Java object into a string representation.
     * @param value Java object.
     * @return JSON string.
     * @throws JsonProcessingException Error processing Java object to string.
     */
    public static String writeObjectToString(Object value) throws JsonProcessingException {
        return OBJECT_WRITER.writeValueAsString(value);
    }

    /**
     * Formats a JSON string for indentation and spacing.
     * @param jsonString JSON string to format.
     * @return Formatted JSON string.
     */
    public static String prettyFormat(String jsonString) {
        return new JSONObject(jsonString).toString(4);
    }

    /**
     * Converts a JSON string into a Java object.
     * @param jsonString JSON string.
     * @param classType Java object class type.
     * @return Newly created Java object from JSON string.
     * @throws IOException Error reading JSON string.
     */
    public static <T> T readStringToObject(String jsonString, Class<T> classType) throws IOException {
        return OBJECT_READER.readValue(jsonString, classType);
    }

    public static <T> T readMapToObject(Map<String, Object> jsonMap, Class<T> classType) {
        return OBJECT_MAPPER.convertValue(jsonMap, classType);
    }

    public static Map<String, Map<String, String>> convertToMap(JsonNode node) throws IOException {
        Map<String, Map<String, String>> map = new HashMap<>();
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String key = entry.getKey();
                JsonNode value = entry.getValue();
                map.put(key, convertNodeToMap(value));
            }
        }

        return map;
    }

    private static Map<String, String> convertNodeToMap(JsonNode node) {
        Map<String, String> innerMap = new HashMap<>();
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String key = entry.getKey();
                JsonNode value = entry.getValue();
                innerMap.put(key, value.asText());
            }
        }
        return innerMap;
    }

    public static Map<String, Map<String, String>> readJsonToMap(String filePath) {
        JsonNode node = null;
        try {
            node = readToJsonObject(filePath);
            return convertToMap(node);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
