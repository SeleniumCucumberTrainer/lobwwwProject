package ca.loblaw.cerebro.automation.utils.internal.bash;

import ca.loblaw.cerebro.automation.utils.contexts.OperatingSystemContext;

/**
 * A wrapper class for general utility commands such as coping the files in GCS, creating buckets
 * and removing buckets in GCS Creating BigQuery datasets.
 */
public class BashUtils {
    public static BashOutput getListOfFiles (String uri) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("listFiles"), uri);
        return BashExecutor.executeCommand(command);
    }
    public static BashOutput getListOfFileSize (String uri) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("listOfFileSize"),uri);
        return BashExecutor.executeCommand(command);
    }



    public static void removeListOfFiles(String uri) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("removeListOfFile"),uri);
        BashExecutor.executeCommand(command);
    }

    public static BashOutput removeFolder(String uri) throws Exception
    {
        String command=String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("removeFolder"),uri);
        return BashExecutor.executeCommand(command);
    }
    public static BashOutput copyFileFromGCSToLocal (String gcsPath, String localPath) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("copyFiles"), gcsPath, localPath);
        return BashExecutor.executeCommand(command);
    }

    public static BashOutput copyFileFromLocalToGCS (String localPath, String gcsPath) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("copyFiles"), localPath, gcsPath);
        return BashExecutor.executeCommand(command);
    }

    public static BashOutput copyFileFromGCSToGCS (String copyPath, String pastePath) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("copyFiles"), copyPath, pastePath);
        return BashExecutor.executeCommand(command);
    }
    public static BashOutput moveFolderFromGCSToGCS (String copyPath, String pastePath) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("moveFolder"), copyPath, pastePath);
        return BashExecutor.executeCommand(command);
    }

    public static BashOutput invokeDfJob (String cmd) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("invokeDFJob"), cmd);
        return BashExecutor.executeCommand(command);
    }

    public static BashOutput setVars (String cmd) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("setVars"), cmd);
        return BashExecutor.executeCommand(command);
    }

    public static BashOutput checkStatus (String cmd) throws Exception {
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("checkStatus"), cmd);
        return BashExecutor.executeCommand(command);
    }

    public static BashOutput getListOfFileDates(String uri) throws Exception{
        String command = String.format(OperatingSystemContext.gsUtilCommandConfigMap.get("listFilesDates"), uri);
        return BashExecutor.executeCommand(command);
    }}