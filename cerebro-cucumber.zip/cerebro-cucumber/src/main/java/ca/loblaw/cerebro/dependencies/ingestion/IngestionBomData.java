package ca.loblaw.cerebro.dependencies.ingestion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IngestionBomData {

    private static ThreadLocal<Map<String, String>> props = new ThreadLocal<>();

    private static ThreadLocal<Map<String, String>> sqlQueries = new ThreadLocal<>();

    private static ThreadLocal<Map<String, String>> ingestionMetadata = new ThreadLocal<>();

    private static ThreadLocal<List<String>> validationFiles = new ThreadLocal<>();

    private static ThreadLocal<List<String>> preprocessedFiles = new ThreadLocal<>();

    private static ThreadLocal<List<String>> columnNames = new ThreadLocal<>();

    public void setupState() {
        validationFiles.set(new ArrayList<>());
        preprocessedFiles.set(new ArrayList<>());
        columnNames.set(new ArrayList<>());
    }

    public void cleanState() {
        props.remove();
        sqlQueries.remove();
        ingestionMetadata.remove();
        validationFiles.remove();
        preprocessedFiles.remove();
        columnNames.remove();
    }

    public Map<String, String> getProps() {
        return props.get();
    }

    public void setProps(Map<String, String> propsMap) {
        props.set(propsMap);
    }

    public Map<String, String> getSqlQueries() {
        return sqlQueries.get();
    }

    public void setSqlQueries(Map<String, String> sqlQueriesMap) {
        sqlQueries.set(sqlQueriesMap);
    }

    public Map<String, String> getIngestionMetadata() {
        return ingestionMetadata.get();
    }

    public void setIngestionMetadata(Map<String, String> ingestionMetadataMap) {
        ingestionMetadata.set(ingestionMetadataMap);
    }

    public List<String> getValidationFiles() {
        return validationFiles.get();
    }

    public void setValidationFiles(List<String> validationFilesList) {
        validationFiles.set(validationFilesList);
    }

    public List<String> getPreprocessedFiles() {
        return preprocessedFiles.get();
    }

    public void setPreprocessedFiles(List<String> preprocessedFilesList) {
        preprocessedFiles.set(preprocessedFilesList);
    }

    public List<String> getColumnNames() {
        return columnNames.get();
    }

    public void setColumnNames(List<String> columnNamesList) {
        columnNames.set(columnNamesList);
    }

}
