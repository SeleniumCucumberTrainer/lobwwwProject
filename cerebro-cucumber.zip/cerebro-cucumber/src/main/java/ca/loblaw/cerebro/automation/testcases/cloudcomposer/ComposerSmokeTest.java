package ca.loblaw.cerebro.automation.testcases.cloudcomposer;

import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.steps.cloudcomposer.AirflowDagUpdater;
import ca.loblaw.cerebro.automation.steps.cloudcomposer.AirflowDagValidator;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.fulfillment.FulfillmentSmokeTest;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.integration.IntegrationSmokeTest;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute.TechComputeSmokeTest;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.SkipException;
import org.testng.annotations.*;

import java.io.IOException;
import java.util.*;

public abstract class ComposerSmokeTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(ComposerSmokeTest.class);

    // Test fields
    private final AirflowFunction airflowFunction;
    private final String sheetName;
    private final Project project;

    // Instance fields
    private final String startingDagId;
    private final List<DagRun> pipelineDags = new ArrayList<>();
    private DagRun startingDag;

    // Steps
    private AirflowDagUpdater airflowDagUpdater;
    private AirflowDagValidator airflowDagValidatior;

    public static ComposerSmokeTest fromProject(Project project, String dagId, String sheetName) {
        switch (project) {
            case TECHCOMPUTE_ZONE:
                return new TechComputeSmokeTest(dagId, dagId, sheetName);
            case FULFILLMENT_ZONE:
                return new FulfillmentSmokeTest(dagId, dagId, sheetName);
            case INTEGRATION_ZONE:
                return new IntegrationSmokeTest(dagId, dagId, sheetName);
            default:
                throw new RuntimeException(String.format("Project %s not supported", project));
        }
    }

    public ComposerSmokeTest(String dataName, String startingDagId, String sheetName, Project project, AirflowFunction airflowFunction) {
        super(dataName);
        this.startingDagId = startingDagId;
        this.sheetName = sheetName;
        this.project = project;
        this.airflowFunction = airflowFunction;
    }

    @BeforeClass
    public void composer_smoke_before_class() throws IOException {
        composerSmokeSetup();

        // Link DAG flow (connect upstream and downstream)
        connectPipelineDagFlow();

        // Find most recent run (completed) for starting DAG, then find associated run IDs for downstream DAGs
        findConnectedRunIds();
    }

    private void composerSmokeSetup() {
        airflowDagUpdater = new AirflowDagUpdater(airflowFunction);
        airflowDagValidatior = new AirflowDagValidator();

        // DAG flow
        startingDag = new DagRun(startingDagId, project);
        pipelineDags.add(startingDag);
    }

    private void connectPipelineDagFlow() throws IOException {
        Queue<DagRun> downstreamQueue = new LinkedList<>();
        downstreamQueue.add(startingDag);

        while (!downstreamQueue.isEmpty()) {
            DagRun dagRun = downstreamQueue.remove();

            Reporter.info(LOG, "Getting DAG information and creating DAG links for {}", dagRun.getDagId());

            airflowDagUpdater.setDagRun(dagRun);
            airflowDagUpdater.checkDagInfo();
            airflowDagUpdater.listTasks();
            List<DagRun> downstreamDags = airflowDagUpdater.createAndLinkDownstreamDags();
            downstreamQueue.addAll(downstreamDags);

            if (!pipelineDags.contains(dagRun)) {
                pipelineDags.add(dagRun);
            }
        }
    }

    private void findConnectedRunIds() throws IOException {
        // Find most recent DAG run
        Reporter.info(LOG, "Finding run information for starting DAG {}", startingDag.getDagId());
        airflowDagUpdater.setDagRun(startingDag);
        airflowDagUpdater.findMostRecentRun();
        airflowDagUpdater.getTaskInstances();

        // Find runs for downstream DAGs
        int counter = 1; // Prevent infinite while-loop in case of logic error

        DagRun downstreamDag;
        while ((downstreamDag = findValidDownstreamDag()) != null && counter < pipelineDags.size()) {
            Reporter.info(LOG, "Finding connected run information for downstream DAG {}", downstreamDag.getDagId());
            airflowDagUpdater.setDagRun(downstreamDag);
            airflowDagUpdater.findRunAssociatedWithUpstreamDag();
            airflowDagUpdater.getTaskInstances();
            counter++;
        }
    }

    private DagRun findValidDownstreamDag() {
        for (DagRun pipelineDag : pipelineDags) {
            if (pipelineDag.isValidDownstreamDagToBeFound() && pipelineDag.hasNoError()) {
                return pipelineDag;
            }
        }
        return null;
    }

    @Test(description = "Validate DAG {}", dataProvider = "pipeline_dags")
    public void validate_dag_runs(DagRun pipelineDag, String dagId) throws InterruptedException, IOException {
        // Skip test if no finished run
        if (!pipelineDag.hasFinishedRun()) {
            throw new SkipException("Skipping validation due to no finished run");
        }

        airflowDagUpdater.setDagRun(pipelineDag);

        // DAG run validation
        airflowDagValidatior.validateDagRunInfo(pipelineDag);
        airflowDagValidatior.validateDagTaskInstances(pipelineDag);

        // Metadata log validation.
        // Skip validation if no metadata log task ID.
        // Skip validation and warn in report if DAG run is outdated or metadata log task was not successful.
        if (pipelineDag.hasMetadataLogTaskId()) {
            if (pipelineDag.isOutdated()) {
                Reporter.warn("Skipping metadata log validation due to outdated run");
            } else {
                airflowDagUpdater.retrieveMetadataLog();

                if (pipelineDag.hasMetadataLog()) {
                    airflowDagValidatior.validateMetadataLog(pipelineDag);
                } else {
                    Reporter.warn("Skipping metadata log validation due to no successful metadata log task instance");
                }
            }
        } else {
            LOG.info("Skipping metadata log validation due to no metadata log task");
        }
    }

    @DataProvider(name = "pipeline_dags")
    public Object[][] pipeline_dags() {
        Object[][] data = new Object[pipelineDags.size()][2];

        int dagCounter = 0;
        for (DagRun pipelineDag : pipelineDags) {
            data[dagCounter][0] = pipelineDag;
            data[dagCounter][1] = pipelineDag.getDagId();
            dagCounter++;
        }
        return data;
    }

    @AfterClass(alwaysRun = true)
    public void composer_smoke_after_method() {
        addAllDagsForReporting();
        logPipelineDags();
    }

    private void addAllDagsForReporting() {
        ComposerSmokeFactory.getDagRunsQueue(getSheetName()).addAll(getPipelineDags());
        LOG.info("Added all pipeline DAGs for Excel report");
    }

    private void logPipelineDags() {
        for (DagRun pipelineDag : pipelineDags) {
            Reporter.info(LOG, pipelineDag.toFullString());
        }
    }

    public List<DagRun> getPipelineDags() {
        return pipelineDags;
    }

    public String getSheetName() {
        return sheetName;
    }
}
