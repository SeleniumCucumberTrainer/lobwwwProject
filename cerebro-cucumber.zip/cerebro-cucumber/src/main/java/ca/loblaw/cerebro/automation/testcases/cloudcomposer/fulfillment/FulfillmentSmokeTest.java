package ca.loblaw.cerebro.automation.testcases.cloudcomposer.fulfillment;

import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeTest;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "CloudComposer", "Fulfillment", "Smoke" })
public class FulfillmentSmokeTest extends ComposerSmokeTest {

    private static final String AIRFLOW_PROPERTIES = "src/main/resources/setup/cloudcomposer/fulfillment/airflowFunction.properties";
    private static final AirflowFunction AIRFLOW_FUNCTION;

    static {
        try {
            AIRFLOW_FUNCTION = AirflowFunction.fromPropertiesFile(AIRFLOW_PROPERTIES);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public FulfillmentSmokeTest(String dataName, String startingDagId, String sheetName) {
        super(dataName, startingDagId, sheetName, Project.FULFILLMENT_ZONE, AIRFLOW_FUNCTION);
    }
}
