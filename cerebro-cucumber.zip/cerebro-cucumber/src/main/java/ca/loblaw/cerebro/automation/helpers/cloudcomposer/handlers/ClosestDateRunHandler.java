package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseDagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import org.assertj.core.api.Assertions;

public class ClosestDateRunHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseDagRun responseDagRun = (AirflowResponseDagRun) airflowResponseItem;

        if (responseDagRun.getDagRunId() == null) {
            dagRun.setError("DAG run triggered by upstream DAG not found");
        } else {
            dagRun.setDagRunId(responseDagRun.getDagRunId());
            dagRun.setState(AirflowState.from(responseDagRun.getState()));
        }
    }
}
