package ca.loblaw.cerebro.automation.utils.reports.excel;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.*;

import java.io.IOException;
import java.util.List;

public class DataIntegrityExcelReportGenerator extends ExcelReportGenerator<List<String>> {
    @Override
    public void reportResults(List<String> headers, List<String> results) throws IOException {
        XSSFSheet sheet = reportWorkbook.createSheet("di");

        // Fonts
        XSSFFont headerFont = reportWorkbook.createFont();
        headerFont.setBold(true);

        // Headers
        XSSFRow headerRow = sheet.createRow(0);
        for (int col = 0; col < headers.size(); col++) {
            XSSFRichTextString text = new XSSFRichTextString(headers.get(col));
            text.applyFont(headerFont);

            XSSFCell cell = headerRow.createCell(col);
            cell.setCellType(CellType.STRING);
            cell.setCellValue(text);
        }

        // Results
        for (int row = 0; row < results.size(); row++) {
            int excelRow = row + 1;

            XSSFRow resultRow = sheet.createRow(excelRow);

            int colCounter = 0;
            String result = results.get(row);

            String[] cells = result.split(",");
            for (String cell : cells) {
                createCell(resultRow, colCounter++, cell);
            }
        }
    }


    private void createCell(XSSFRow resultRow, int col, String value) {
        XSSFCell cell = resultRow.createCell(col);
        cell.setCellType(CellType.STRING);
        cell.setCellValue(value);
    }
}
