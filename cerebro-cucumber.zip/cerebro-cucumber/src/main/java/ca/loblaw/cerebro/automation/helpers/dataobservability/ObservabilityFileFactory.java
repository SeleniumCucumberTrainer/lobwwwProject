package ca.loblaw.cerebro.automation.helpers.dataobservability;

import ca.loblaw.cerebro.automation.utils.contexts.OperatingSystemContext;
import ca.loblaw.cerebro.automation.utils.internal.LocalFileUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.assertj.core.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ObservabilityFileFactory {

    private List<String> cloudFilePaths = new ArrayList<>();
    private List<Boolean> hasUuidList = new ArrayList<>();
    private List<Boolean> isValidList = new ArrayList<>();

    public ObservabilityFileFactory include(String cloudFilePath, boolean hasUuid, boolean isValid) {
        cloudFilePaths.add(cloudFilePath);
        hasUuidList.add(hasUuid);
        isValidList.add(isValid);
        return this;
    }

    public List<ObservabilityFile> generate() throws IOException {
        Assertions.assertThat(cloudFilePaths.size()).isEqualTo(hasUuidList.size()).isEqualTo(isValidList.size());

        List<ObservabilityFile> observabilityFiles = new ArrayList<>();
        for (int fileIndex = 0; fileIndex < cloudFilePaths.size(); fileIndex++) {
            ObservabilityFile observabilityFile = new ObservabilityFile();
            observabilityFile.setCloudPath(cloudFilePaths.get(fileIndex));

            // Create temporary empty local files to upload if valid
            if (isValidList.get(fileIndex)) {
                String localPath = OperatingSystemContext.TEMP_DIR + FilenameUtils.getName(cloudFilePaths.get(fileIndex));
                observabilityFile.setLocalPath(localPath);

                // Include UUID if required
                if (hasUuidList.get(fileIndex)) {
                    observabilityFile.setUuid(UUID.randomUUID().toString());
                }
            }

            observabilityFiles.add(observabilityFile);
        }

        // Empty stored list values
        cloudFilePaths.clear();
        hasUuidList.clear();
        isValidList.clear();

        return observabilityFiles;
    }
}
