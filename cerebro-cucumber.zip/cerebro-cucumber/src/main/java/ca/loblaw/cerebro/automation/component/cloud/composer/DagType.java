package ca.loblaw.cerebro.automation.component.cloud.composer;

import ca.loblaw.cerebro.automation.utils.contexts.Project;

/**
 * Cerebro DAG types.
 */
public enum DagType {
    INGESTION,
    SNAPSHOT,
    CURATION,
    PUBLICATION,
    DELTA,
    PUBSUB,
    GENERAL;

    public static DagType determineDagType(String dagId, Project project) {
        switch (project) {
            case TECHCOMPUTE_ZONE:
                if (dagId.endsWith("ingestion")) {
                    return DagType.INGESTION;
                } else if (dagId.endsWith("curation")) {
                    return DagType.CURATION;
                } else if (dagId.endsWith("snapshot")) {
                    return DagType.SNAPSHOT;
                } else if (dagId.endsWith("publication")) {
                    return DagType.PUBLICATION;
                }
                break;
        }

        return GENERAL;
    }
}
