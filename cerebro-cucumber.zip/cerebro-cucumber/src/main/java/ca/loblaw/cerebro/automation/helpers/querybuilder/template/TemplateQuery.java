package ca.loblaw.cerebro.automation.helpers.querybuilder.template;

import ca.loblaw.cerebro.automation.helpers.querybuilder.Query;
import org.apache.commons.lang3.RegExUtils;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class TemplateQuery<T extends TemplateQuery<T>> implements Query {

    private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\$\\{[\\s\\w]+\\}");

    private Set<String> templateVariables = new HashSet<>();

    private String template;

    public static String indent(String s) {
        Pattern beginning = Pattern.compile("^", Pattern.MULTILINE);

        return RegExUtils.replaceAll(s, beginning, "\t");
    }

    protected T castThis() {
        return (T) this;
    }

    public T setTemplate(String template) {
        this.template = template;
        addTemplateVariablesToSet();

        return castThis();
    }

    protected final boolean doesTemplateVariablesContain(String templateVariable) {
        return templateVariables.contains(templateVariable);
    }

    private void addTemplateVariablesToSet() {
        Matcher variableMatcher = VARIABLE_PATTERN.matcher(this.template);

        while(variableMatcher.find()) {
            String match = variableMatcher.group();
            if(!templateVariables.contains(match)){
                templateVariables.add(match);
            }
        }
    }

    @Override
    public String build() {
        assert template != null && !template.isEmpty();
        return template;
    }
}
