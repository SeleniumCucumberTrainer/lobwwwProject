package ca.loblaw.cerebro.automation.utils.reports.extent;

import ca.loblaw.cerebro.automation.utils.internal.Layer;
import ca.loblaw.cerebro.automation.utils.logging.LogLevel;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.helpers.MessageFormatter;

import java.util.NoSuchElementException;

/**
 * Reporter is a utility class for logging to Extent reports and
 * the appropriate Extent test. All methods in Reporter can also accept a
 * Logger object to prevent duplicity when deciding to output to a Logger
 * and the Extent report.
 *
 * Note: Reporter uses the log4j '{}' identifier to format messages.
 */
public class Reporter {

    /**
     * PASS level logging and reporting.
     *
     * @param logger Class logger
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void pass(Logger logger, String message, Object... args) {
        reporterLog(LogLevel.PASS, message, args);
        logger.log(Level.getLevel("PASS"), message, args);
    }

    /**
     * PASS level reporting.
     *
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void pass(String message, Object... args) {
        reporterLog(LogLevel.PASS, message, args);
    }

    /**
     * SKIP level logging and reporting. Used to report skip reason. Ensure a SkipException is thrown in the test method.
     *
     * @param logger Class logger
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void skip(Logger logger, String message, Object... args) {
        reporterLog(LogLevel.SKIP, message, args);
        logger.log(Level.getLevel("SKIP"), message, args);
    }

    /**
     * SKIP level reporting. Used to report skip reason. Ensure a SkipException is thrown in the test method.
     *
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void skip(String message, Object... args) {
        reporterLog(LogLevel.SKIP, message, args);
    }

    /**
     * INFO level logging and reporting. Used for regular reporting.
     *
     * @param logger Class logger
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void info(Logger logger, String message, Object... args) {
        reporterLog(LogLevel.INFO, message, args);
        logger.info(message, args);
    }

    /**
     * INFO level reporting. Used for regular reporting.
     *
     * @param message Message to report
     * @param args Formatting arguments
     */
    public static void info(String message, Object... args) {
        reporterLog(LogLevel.INFO, message, args);
    }

    /**
     * INFO level reporting. Used for regular reporting.
     *
     * @param arg Object string to report.
     */
    public static void info(Logger logger, Object arg) {
        reporterLog(LogLevel.INFO, "{}", arg);
        logger.info(arg);
    }

    /**
     * INFO level reporting. Used for regular reporting.
     *
     * @param arg Object string to report.
     */
    public static void info(Object arg) {
        reporterLog(LogLevel.INFO, "{}", arg);
    }

    public static void info(String[][] tableData, String cssClass) {
        reporterTable(LogLevel.INFO, tableData, cssClass);
    }

    /**
     * WARN level logging and reporting. Used for testing situations that 'pass' but should still not be considered
     * successful due to non-ideal conditions.
     *
     * @param logger Class logger
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void warn(Logger logger, String message, Object... args) {
        reporterLog(LogLevel.WARN, message, args);
        logger.warn(message, args);
    }

    /**
     * WARN level reporting. Used for testing situations that 'pass' but should still not be considered
     * successful due to non-ideal conditions.
     *
     * @param message Message to report
     * @param args Formatting arguments
     */
    public static void warn(String message, Object... args) {
        reporterLog(LogLevel.WARN, message, args);
    }

    /**
     * ERROR level logging and reporting. Used for testing situations that 'fail' and are certain to throw an
     * Assertion exception.
     *
     * @param logger Class logger
     * @param message Message to log and report
     * @param args Formatting arguments
     */
    public static void error(Logger logger, String message, Object... args) {
        reporterLog(LogLevel.ERROR, message, args);
        logger.error(message, args);
    }

    /**
     * ERROR level reporting. Used for testing situations that 'fail' and are certain to throw an
     * Assertion exception.
     *
     * @param message Message to report
     * @param args Formatting arguments
     */
    public static void error(String message, Object... args) {
        reporterLog(LogLevel.ERROR, message, args);
    }

    /*
     * Log message to report based on LogLevel
     */
    private static void reporterLog(LogLevel level, String message, Object... args) {
        String extentKey = retrieveExtentKey();

        if (extentKey == null) {
            return;
        }

        String formattedMessage = parseMessage(MessageFormatter.arrayFormat(message, args).getMessage());

        // Report to Extent Node or Extent Test matching the key
        if (ExtentManager.hasExtentNode(extentKey)) {
            switch (level) {
                case INFO:
                    ExtentManager.getExtentNode(extentKey).info(formattedMessage);
                    break;
                case PASS:
                    ExtentManager.getExtentNode(extentKey).pass(formattedMessage);
                    break;
                case WARN:
                    ExtentManager.getExtentNode(extentKey).warning(formattedMessage);
                    break;
                case SKIP:
                    ExtentManager.getExtentNode(extentKey).skip(formattedMessage);
                    break;
                case ERROR:
                    ExtentManager.getExtentNode(extentKey).fail(formattedMessage);
                    break;
            }
        } else if (ExtentManager.hasExtentTest(extentKey)) {
            switch (level) {
                case INFO:
                    ExtentManager.getExtentTest(extentKey).info(formattedMessage);
                    break;
                case PASS:
                    ExtentManager.getExtentTest(extentKey).pass(formattedMessage);
                    break;
                case WARN:
                    ExtentManager.getExtentTest(extentKey).warning(formattedMessage);
                    break;
                case SKIP:
                    ExtentManager.getExtentTest(extentKey).skip(formattedMessage);
                    break;
                case ERROR:
                    ExtentManager.getExtentTest(extentKey).fail(formattedMessage);
                    break;
            }
        } else {
            throw new NoSuchElementException(String.format("Extent key '%s' was not found in Extent Manager", extentKey));
        }
    }

    private static void reporterTable(LogLevel level, String[][] tableData, String cssClass) {
        String extentKey = retrieveExtentKey();

        if (extentKey == null) {
            return;
        }

        Markup tableMarkup = MarkupHelper.createTable(tableData, cssClass);

        // Report to Extent Node or Extent Test matching the key
        if (ExtentManager.hasExtentTest(extentKey)) {
            switch (level) {
                case INFO:
                    ExtentManager.getExtentTest(extentKey).info(tableMarkup);
                    break;
            }
        }
    }

    private static String retrieveExtentKey() {
        String testClass = ThreadContext.containsKey(Layer.CLASS_NAME) ? ThreadContext.get(Layer.CLASS_NAME) : null;
        String dataName = ThreadContext.containsKey(Layer.DATA_NAME) ? ThreadContext.get(Layer.DATA_NAME) : null;

        if (dataName != null) {
            return dataName;
        } else {
            return testClass;
        }
    }

    /*
     * Parse message for HTML formatting.
     */
    private static String parseMessage(String message) {
        return message.replace("\n", "<br/>").replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
    }
}
