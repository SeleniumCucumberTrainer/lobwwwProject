package ca.loblaw.cerebro.automation.models.validations;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;

public class SnapshotComposerValidationDto {

    DagRun dagRun;
    String jobRunTraceId;
    String sourceName;
    String targetName;
    String recCreTms;
    int tableRecordCount;

    public DagRun getDagRun() {
        return dagRun;
    }

    public SnapshotComposerValidationDto setDagRun(DagRun dagRun) {
        this.dagRun = dagRun;
        return this;
    }

    public String getJobRunTraceId() {
        return jobRunTraceId;
    }

    public SnapshotComposerValidationDto setJobRunTraceId(String jobRunTraceId) {
        this.jobRunTraceId = jobRunTraceId;
        return this;
    }

    public String getSourceName() {
        return sourceName;
    }

    public SnapshotComposerValidationDto setSourceName(String sourceName) {
        this.sourceName = sourceName;
        return this;
    }

    public String getTargetName() {
        return targetName;
    }

    public SnapshotComposerValidationDto setTargetName(String targetName) {
        this.targetName = targetName;
        return this;
    }

    public String getRecCreTms() {
        return recCreTms;
    }

    public SnapshotComposerValidationDto setRecCreTms(String recCreTms) {
        this.recCreTms = recCreTms;
        return this;
    }

    public int getTableRecordCount() {
        return tableRecordCount;
    }

    public SnapshotComposerValidationDto setTableRecordCount(int tableRecordCount) {
        this.tableRecordCount = tableRecordCount;
        return this;
    }
}
