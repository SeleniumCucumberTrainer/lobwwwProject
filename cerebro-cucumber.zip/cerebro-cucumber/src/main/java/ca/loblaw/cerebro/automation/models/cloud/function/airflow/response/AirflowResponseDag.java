package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowResponseDag extends AirflowResponseItem {

    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("is_paused")
    private Boolean isPaused;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public Boolean isPaused() {
        return isPaused;
    }

    public void setPaused(Boolean paused) {
        isPaused = paused;
    }
}
