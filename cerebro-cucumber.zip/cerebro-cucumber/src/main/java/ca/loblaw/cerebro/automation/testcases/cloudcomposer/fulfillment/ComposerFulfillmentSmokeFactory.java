package ca.loblaw.cerebro.automation.testcases.cloudcomposer.fulfillment;

import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeFactory;
import ca.loblaw.cerebro.automation.utils.contexts.Project;

public class ComposerFulfillmentSmokeFactory extends ComposerSmokeFactory {

    public ComposerFulfillmentSmokeFactory() {
        super(
                Project.FULFILLMENT_ZONE,
                "src/main/resources/setup/cloudcomposer/fulfillment/FulfillmentDAGs.xlsx",
                "FulfillmentDAGs",
                "Fulfillment"
        );
    }
}
