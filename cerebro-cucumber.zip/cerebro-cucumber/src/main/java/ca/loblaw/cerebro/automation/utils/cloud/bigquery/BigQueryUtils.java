package ca.loblaw.cerebro.automation.utils.cloud.bigquery;

import ca.loblaw.cerebro.automation.exceptions.QueryException;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;
import com.google.api.gax.retrying.RetrySettings;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.bigquery.*;
import com.google.cloud.http.HttpTransportOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.threeten.bp.Duration;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BigQueryUtils {

    private static final Logger LOG = LogManager.getLogger(BigQueryUtils.class);
    private final static BigQuery BIGQUERY = BigQueryOptions.getDefaultInstance().getService();
    private final static String[] UNITS = new String[]{"B", "KB", "MB", "GB", "TB"};
    private final static byte MAX_RETRY = 5;
    private final static long MAX_BYTES_PROCESSED = 15000000000L; // Around 20 GB

    private BigQueryUtils() {}

    public static TableResult executeQuery(String query) throws InterruptedException {
        LOG.info("Executing BQ query: {}", query);
        long estimatedBytesProcessed = performDryRun(query);

        if (estimatedBytesProcessed < MAX_BYTES_PROCESSED) {
            byte attempt = 0;
            while (attempt < MAX_RETRY) {
                try {
                    return BIGQUERY.query(QueryJobConfiguration.of(query));
                } catch (BigQueryException e) {
                    if (e.getMessage() == null || e.getMessage().isEmpty()) {
                        attempt++;
                    } else {
                        throw e;
                    }
                }
            }
            return BIGQUERY.query(QueryJobConfiguration.of(query));
        } else {
            throw new QueryException("Query not executed due to costs. Please optimize the query.");
        }
    }

    private static long performDryRun(String query) {
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration.newBuilder(query)
                .setDryRun(true)
                .setUseQueryCache(false)
                .build();

        Job job = BIGQUERY.create(JobInfo.of(queryJobConfiguration));
        JobStatistics.QueryStatistics jobStatistics = job.getStatistics();

        long queryBytesProcessed = jobStatistics.getTotalBytesProcessed();

        LOG.info("Estimated query cost is " + formatCost(queryBytesProcessed));
        return queryBytesProcessed;
    }

    private static String formatCost(double totalBytesProcessed) {
        int unitIndex = 0;
        while (totalBytesProcessed >= 1000 && unitIndex < UNITS.length) {
            totalBytesProcessed /= 1000;
            unitIndex++;
        }

        return String.format("%.2f %s", totalBytesProcessed, UNITS[unitIndex]);
    }

    public static Table getTable(String fullTableName) {
        String[] tableSplit = fullTableName.split("\\.");
        return getTable(tableSplit[0], tableSplit[1], tableSplit[2]);
    }

    public static Table getTable(String project, String dataset, String tableName) {
        return BIGQUERY.getTable(TableId.of(project, dataset, tableName));
    }

    public static boolean checkTableExists(String fullTableName) {
        Table bigQueryTable = getTable(fullTableName);
        return bigQueryTable.exists();
    }

    public static List<Column> getColumnsSchemaFromTable(String fullTableName, boolean filterGenerated) throws InterruptedException {
        String[] tableSplit = fullTableName.split("\\.");
        return getColumnsSchemaFromTable(tableSplit[0], tableSplit[1], tableSplit[2], filterGenerated);
    }

    public static List<Column> getColumnsSchemaFromTable(String project, String dataset, String tableName, boolean filterGenerated) throws InterruptedException {
        String columnsSchemaQuery = String.format("SELECT column_name, data_type, is_partitioning_column " +
                        "FROM `%s.%s.INFORMATION_SCHEMA.COLUMNS` " +
                        "WHERE table_name='%s' " +
                        "ORDER BY ordinal_position ASC",
                project, dataset, tableName);

        TableResult tableResult = executeQuery(columnsSchemaQuery);
        LOG.info("Successfully retrieved columns information schema for {}.{}.{}", project, dataset, tableName);

        // Parse to columns
        List<Column> columns = new ArrayList<>();
        for (FieldValueList value : tableResult.getValues()) {
            Column column = new Column();
            column.setName(value.get(0).getStringValue());
            column.setDataType(value.get(1).getStringValue());
            column.setIsPartitioningColumn(Column.Partitioned.valueOf(value.get(2).getStringValue()));

            columns.add(column);
        }

        //Filter system generated columns
        if (filterGenerated) {
            columns = columns.stream()
                    .filter(column -> !column.getName().equalsIgnoreCase("rec_chng_tms")
                            && !column.getName().equalsIgnoreCase("rec_cre_tms")
                            && !column.getName().equalsIgnoreCase("file_name")
                            && !column.getName().equalsIgnoreCase("snapshot_time"))
                    .collect(Collectors.toList());
        }

        return columns;
    }

    public static void deleteTable(String datasetName, String tableName, String project) throws Exception {
        try {
            BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
                    ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS")))
                    //  ServiceAccountCredentials.fromStream(new FileInputStream(TestConfigReader.getGoogleApplicationCredentials()))
            ).build().getService();
            boolean success = bigquery.delete(TableId.of(project, datasetName, tableName));
            if (success) {
                System.out.println("bqTable "+tableName+" deleted successfully");
            } else {
                System.out.println("bqTable "+tableName+" was not found");
            }
        } catch (BigQueryException e) {
            System.out.println("bqTable was not deleted. \n" + e.toString());
        }
    }

    public static void ddlCreateTable(String ddl) throws Exception {
        try {
            BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
                    ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS")))
                    // ServiceAccountCredentials.fromStream(new FileInputStream(TestConfigReader.getGoogleApplicationCredentials()))
            ).build().getService();
            QueryJobConfiguration config = QueryJobConfiguration.newBuilder(ddl).setUseQueryCache(false).build();
            //QueryJobConfiguration config = QueryJobConfiguration.newBuilder(ddl).build();
            Job job = bigquery.create(JobInfo.of(config));
            job = job.waitFor();
            if (job.isDone()) {
                System.out.println("It created successfully");
            } else {
                System.out.println("It was not created");
            }
        } catch (BigQueryException | InterruptedException e) {
//            System.out.println("It was not created. \n" + e.toString());
            e.printStackTrace();
            Assert.fail("It was not created.");
        }
    }

    public static TableResult executeBigQueryCustom(String myBQ) throws Exception {
        TableResult result = null;
        try {
            String myQuery = myBQ;
            Long myCount;

//            String dataFormat = FormatOptions.json().getType();
//            TableId tableId = TableId.of("lt-dia-lake-exp-techdata", "cerebro_testing", "gtin_work_qa");
//            Table table = bigquery.getTable(tableId);
//            Job job = table.extract(dataFormat, "gs://cerebro-exp-tec-testing/logistics_inventorymgmt/ingestion/bq2bq_result .json");

            // BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
            //         ServiceAccountCredentials.fromStream(new FileInputStream(TestConfigReader.getGoogleApplicationCredentials()))
            // ).build().getService();

            BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
                    ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS")))
            ).build().getService();

            QueryJobConfiguration queryConfig =
                    QueryJobConfiguration.newBuilder(myQuery).build();
            Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).build());

            result = queryJob.getQueryResults();
            System.out.println(result.toString());
            myCount = result.getTotalRows();
            if (myCount>0) {
                System.out.println("Query executed successfully. The record count is: " + myCount );
            } else {
                System.out.println("Query failed");
            }


        } catch (BigQueryException e) {
            System.out.println("Execute query error. \n" + e.toString());
        }
        return result;
    }
}
