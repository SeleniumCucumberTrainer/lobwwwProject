package ca.loblaw.cerebro.automation.component.cloud.function;

import ca.loblaw.cerebro.automation.models.cloud.function.airflow.request.AirflowRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponse;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunction;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunctionHttpResponse;
import ca.loblaw.cerebro.automation.utils.internal.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

/**
 * Representational class for the Airflow API Cloud Function, which is used to communicate with the Airflow API.
 */
public class AirflowFunction extends CloudFunctionComponent<AirflowRequest, AirflowResponse> {
    private static final Logger LOG = LogManager.getLogger(AirflowFunction.class);

    public static AirflowFunction fromPropertiesFile(String propertiesFilePath) throws IOException {
        return new AirflowFunction(new CloudFunction.Builder().fromPropertiesFile(propertiesFilePath).build());
    }

    private AirflowFunction(CloudFunction cloudFunction) {
        super(cloudFunction);
    }

    @Override
    public AirflowResponse execute(AirflowRequest airflowRequest) throws IOException {
        // Request JSON string
        String requestJson = JsonUtils.writeObjectToString(airflowRequest);
        LOG.debug("Airflow API request JSON:\n{}", JsonUtils.prettyFormat(requestJson));

        // Trigger Cloud Function
        CloudFunctionHttpResponse cloudFunctionHttpResponse = getCloudFunction().trigger(requestJson);

        // Response JSON string
        String responseJson = cloudFunctionHttpResponse.getResponseString();
        LOG.debug("Airflow API response JSON:\n{}", JsonUtils.prettyFormat(responseJson));

        return JsonUtils.readStringToObject(responseJson, AirflowResponse.class);
    }

    @Override
    public void validateRequestJson(JsonNode requestJsonNode) {

    }

    @Override
    public void validateResponseJson(JsonNode responseJsonNode) {

    }
}
