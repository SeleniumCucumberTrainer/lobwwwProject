package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

import ca.loblaw.cerebro.automation.component.cloud.composer.AirflowState;

import java.util.*;

public class TaskInstance {
    private final String taskId;
    private AirflowState state;
    private String startDate;
    private String endDate;
    private Map<String, Object> keywordArguments; // op_kwargs
    private Set<String> xcomVariables; // Available XCOM variables
    private Map<String, String> xcomEntries; // XCOM entries

    public TaskInstance(String taskId, AirflowState state, String startDate, String endDate, Map<String, Object> keywordArguments) {
        this.taskId = taskId;
        this.state = state;
        this.startDate = startDate;
        this.endDate = endDate;
        this.keywordArguments = keywordArguments;
    }

    public boolean hasKeyword(String keyword) {
        return keywordArguments.containsKey(keyword);
    }

    public Object getArgument(String keyword) {
        return keywordArguments.get(keyword);
    }

    public boolean isPassing() {
        return state == AirflowState.SUCCESS || state == AirflowState.SKIPPED;
    }

    public boolean isCompleted() {
        return state == AirflowState.SUCCESS || state == AirflowState.FAILED;
    }

    public boolean isDoneRunning() {
        return state != null && state != AirflowState.SCHEDULED && state != AirflowState.QUEUED && state != AirflowState.RUNNING;
    }

    public void createXcomVariables(List<String> xcomKeys) {
        xcomVariables = new HashSet<>();
        xcomVariables.addAll(xcomKeys);
    }

    public boolean hasXcomVariable(String xcomKey) {
        return xcomVariables.contains(xcomKey);
    }

    public void addXcomEntry(String xcomKey, String xcomValue) {
        if (xcomEntries == null) {
            xcomEntries = new HashMap<>();
        }
        xcomEntries.put(xcomKey, xcomValue);
    }

    public boolean hasXcomEntry(String xcomKey) {
        return xcomEntries.containsKey(xcomKey);
    }

    public String getXcomEntry(String xcomKey) {
        return xcomEntries.get(xcomKey);
    }

    // Getters and Setters
    public String getTaskId() {
        return taskId;
    }
    public AirflowState getState() {
        return state;
    }
    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setState(AirflowState state) {
        this.state = state;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public Map<String, Object> getKeywordArguments() {
        return keywordArguments;
    }

    public void setKeywordArguments(Map<String, Object> keywordArguments) {
        this.keywordArguments = keywordArguments;
    }

    @Override
    public String toString() {
        return "TaskInstance {" +
                "taskId = " + taskId + ", " +
                "state = " + state + ", " +
                "startDate = " + startDate +
                '}';
    }
}
