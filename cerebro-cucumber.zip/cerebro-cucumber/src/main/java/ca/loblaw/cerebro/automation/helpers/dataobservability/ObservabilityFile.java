package ca.loblaw.cerebro.automation.helpers.dataobservability;

public class ObservabilityFile {
    private String cloudPath;
    private String localPath;
    private String uuid;

    public boolean hasUuid() {
        return this.uuid != null;
    }

    public boolean isValid() {
        return this.localPath != null;
    }

    public String getCloudPath() {
        return cloudPath;
    }

    public void setCloudPath(String cloudPath) {
        this.cloudPath = cloudPath;
    }

    public String getLocalPath() {
        return localPath;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
