package ca.loblaw.cerebro.automation.utils.internal;

import java.util.regex.Pattern;

public class CerebroPatterns {

    public static final Pattern METADATA_LOG_TIMESTAMP = Pattern.compile("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{6} UTC$");
    public static final Pattern REC_CRE_TMS = Pattern.compile("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{6}$");
    public static final Pattern UUID = Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    public static final Pattern CURATION_QUERY = Pattern.compile("query=.*;", Pattern.DOTALL);

    private CerebroPatterns() {}

    /**
     * Escapes special characters in a String by placing a "\" before them.
     * @param s String to escape special characters.
     * @return String that has special characters escaped.
     */
    public static String escapeRegExp(String s) {
        return s.replaceAll("[.+^$?=<>{}\\[\\]\\\\]", "\\\\$0");
    }
}
