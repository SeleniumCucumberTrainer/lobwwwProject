DELETE FROM `lt-dia-lake-${ENV}-raw.entity_vendor.sap_lfa1_hist`
WHERE lifnr = "0009999999"
AND mandt = "200"
AND rec_cre_tms >= "${rec_cre_tms}";

DELETE FROM `lt-dia-lake-${ENV}-raw.entity_vendor.sap_lfa1_snpsht`
WHERE lifnr = "0009999999" AND mandt = "200"
AND rec_cre_tms >= "${rec_cre_tms}";

DELETE FROM `lt-dia-lake-${ENV}-techdata.entity_vendor.vendor_work`
WHERE vend_num = "9999999"
AND rec_cre_tms >= "${rec_cre_tms}";

--DELETE FROM `lt-dia-lake-${ENV}-consume.entity_vendor.vendor_curr`
--WHERE vend_num = "9999999";

--DELETE FROM `lt-dia-lake-${ENV}-consume.entity_vendor.vendor_hist`
--WHERE vend_num = "9999999";

