DELETE FROM `lt-dia-lake-${ENV}-raw.talent_employee.snow_users_hist`
WHERE employee_id = "9999999999QATest"
AND rec_cre_tms >= "${rec_cre_tms}";

DELETE FROM `lt-dia-lake-${ENV}-raw.talent_employee.snow_users_snpsht`
WHERE employee_id = "9999999999QATest"
AND rec_cre_tms >= "${rec_cre_tms}";

DELETE FROM `lt-dia-lake-${ENV}-techdata.talent_employee.beauty_boutique_employee_work`
WHERE emple_id = "9999999999QATest"
AND rec_cre_tms >= "${rec_cre_tms}";

--DELETE FROM `lt-dia-lake-${ENV}-consume.talent_employee.beauty_boutique_employee_curr`
--WHERE emple_id = "9999999999QATest";
