#!/bin/bash

# Fetch all remote branches
git fetch --all

# Iterate over each remote branch
git for-each-ref --format='%(refname:short) %(committerdate)' refs/remotes | while read branch date; do
    # Extract the branch name and remove the "refs/remotes/" prefix
    branch_name=$(echo "$branch" | sed 's|refs/remotes/||')
    # Print branch name and creation date
    echo "$branch_name - $date"
done
read -p "Press Enter to exit..."