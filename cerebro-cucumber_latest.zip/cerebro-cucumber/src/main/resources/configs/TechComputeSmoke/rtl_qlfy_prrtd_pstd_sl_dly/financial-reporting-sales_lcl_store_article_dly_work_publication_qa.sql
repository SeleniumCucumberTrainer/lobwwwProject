insert into `lt-dia-lake-exp-consume.cerebro_testing.sales_lcl_store_article_dly_qa`
select 
post_dt
,trans_dt
,site_num
,artcl_num
,scan_cd
,cmpr_sl_ind
,sl_uom_cd
,promo_ind
,artcl_acct_assn_grp_cd
,tlog_sl_amt
,prrtd_pstd_sl_qty
,prrtd_pstd_sl_amt
,prrtd_pstd_ext_gp_cost
,cast('{param-curr-rec-cre-tms}' as TIMESTAMP) rec_cre_tms
,'sales_lcl_store_article_dly_work_qa' as tech_tables_nm
,cast(work.rec_cre_tms as STRING)    as tech_rec_cre_tms
from `lt-dia-lake-exp-techdata.cerebro_testing.sales_lcl_store_article_dly_work_qa` work
where rec_cre_tms = '2021-05-05 18:31:14.517 UTC';