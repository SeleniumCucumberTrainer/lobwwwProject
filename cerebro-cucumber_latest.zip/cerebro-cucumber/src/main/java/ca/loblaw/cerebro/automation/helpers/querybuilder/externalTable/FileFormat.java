package ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable;

public enum FileFormat {
    CSV("csv"),
    NEWLINE_DELIMITED_JSON("json"),
    PARQUET("parquet");

    private String format;

    FileFormat(String format) {
        this.format = format;
    }

    public String getFormat() {
        return this.format;
    }

    public static FileFormat fromString(String fileType) {
        for(FileFormat fileFormat : FileFormat.values()) {
            if(fileType.trim().toLowerCase().equals(fileFormat.getFormat())) {
                return fileFormat;
            }
        }

        throw new EnumConstantNotPresentException(FileFormat.class, fileType);
    }
}
