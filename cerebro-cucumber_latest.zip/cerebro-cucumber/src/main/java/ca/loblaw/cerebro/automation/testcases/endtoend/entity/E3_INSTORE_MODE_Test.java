package ca.loblaw.cerebro.automation.testcases.endtoend.entity;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "e3-instore-mode", "entity" })
public class E3_INSTORE_MODE_Test extends EndToEndTest {
    public E3_INSTORE_MODE_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/entity/e3_instore.properties");
    }
}
