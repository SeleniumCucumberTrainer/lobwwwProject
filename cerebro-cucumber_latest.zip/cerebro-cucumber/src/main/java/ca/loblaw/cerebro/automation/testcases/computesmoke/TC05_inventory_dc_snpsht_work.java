package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"inventory_dc_snpsht_work","TechComputeSmoke"})
public class TC05_inventory_dc_snpsht_work extends TechComputeCommonFun{
    public TC05_inventory_dc_snpsht_work() throws IOException {
        super("TC05_inventory_dc_snpsht_workTestData.properties");
    }

}
