package ca.loblaw.cerebro.automation.helpers.querybuilder.functions;

import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;

public interface SQLFunction {
    String build(Column column);
}
