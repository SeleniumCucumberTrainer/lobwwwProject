package ca.loblaw.cerebro.automation.testcases.endtoend.talent;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "snow-users", "talent" })
public class Snow_Users_Test extends EndToEndTest {
    public Snow_Users_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/talent/snow_users.properties");
    }
}
