package ca.loblaw.cerebro.automation.testcases.filerouting;

import ca.loblaw.cerebro.automation.interactors.FileRoutingStorageManager;
import ca.loblaw.cerebro.automation.models.data.RawFolders;
import ca.loblaw.cerebro.automation.steps.filerouting.*;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileContainer;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.testng.annotations.*;

import java.util.List;

@Test(groups = { "file-routing", "cloud-function", "smoke" })
public class FileRoutingTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(FileRoutingTest.class);
    public static final int NUM_FILE_COPIES = 5;

    // Fields
    private final String landingFolderPath;
    private final String rawFolderPath;
    private final String testFolderPath;
    private final RawFolders rawFolders;
    private List<CloudStorageFile> landingCloudFiles;
    private List<String> landingCloudFileNames;

    // Cloud components
    private FileRoutingStorageManager fileRoutingStorageManager;

    public FileRoutingTest(String dataName, String landingFolderPath, String rawFolderPath, String testFolderPath) {
        super(dataName);
        this.landingFolderPath = landingFolderPath;
        this.rawFolderPath = rawFolderPath;
        this.testFolderPath = testFolderPath;
        this.rawFolders = new RawFolders(rawFolderPath);
    }

    @BeforeMethod(alwaysRun = true)
    public void file_routing_test_before_method() {
        Reporter.info(LOG, "Landing bucket folder: {}\nRaw bucket folder: {}\nTest folder: {}", landingFolderPath, rawFolderPath, testFolderPath);

        fileRoutingStorageManager = new FileRoutingStorageManager(testFolderPath, landingFolderPath, rawFolderPath, rawFolders);
    }

    @Test(priority = 1, description = "Validate file routing Cloud Function for Landing zone", groups = "copy")
    public void validate_file_routing() throws InterruptedException {
        // Copying test files
        fileRoutingStorageManager.cleanLandingFolder();
        List<String> testFilesToCopyPaths = fileRoutingStorageManager.retrieveTestFilesPaths();
        fileRoutingStorageManager.copyTestFilesToLandingFolderMultiple(NUM_FILE_COPIES);
        fileRoutingStorageManager.waitForLandingFilesToBeRouted(NUM_FILE_COPIES);

        // Landing files
        landingCloudFiles = fileRoutingStorageManager.retrieveLandingFilesSorted();
        landingCloudFileNames = CloudStorageFileContainer.wrap(landingCloudFiles).toFileNamesList();
        validateLandingCloudFiles(landingCloudFiles, testFilesToCopyPaths);

        // Raw files
        List<CloudStorageFile> rawCloudFiles = fileRoutingStorageManager.findRawCloudFilesFromFileNames(landingCloudFileNames, "routed landing files", FileRoutingStorageManager.STAGE_FOLDERS);
        FileRoutingValidator.validateLandingAndRawCloudFiles(landingCloudFiles, rawCloudFiles, FileRoutingStorageManager.STAGE_FOLDERS);

        // Report
        if (rawCloudFiles.contains(null)) {
            Reporter.error(LOG, "Not all landing files were found in raw bucket");
        } else {
            Reporter.info(LOG, "All landing files were found in raw bucket");
        }
    }

    @Test(priority = 2, description = "Cleanup other environment", groups = "cleanup")
    public void cleanup_other_environment() {
        landingCloudFiles = fileRoutingStorageManager.retrieveLandingFilesSorted();
        landingCloudFileNames = CloudStorageFileContainer.wrap(landingCloudFiles).toFileNamesList();
    }

    private void validateLandingCloudFiles(List<CloudStorageFile> landingCloudFiles, List<String> testFilesToCopyPaths) {
        // Validate number of landing files are as expected
        int expectedNumSourceFiles = NUM_FILE_COPIES * testFilesToCopyPaths.size();
        Assertions.assertThat(landingCloudFiles.size())
                .as("Expected %d files in landing, but got %d files", expectedNumSourceFiles, landingCloudFiles.size())
                .isEqualTo(expectedNumSourceFiles);
    }

    @AfterMethod(alwaysRun = true)
    public void file_routing_test_after_class() {
        if (fileRoutingStorageManager != null) {
            fileRoutingStorageManager.cleanUpRawFolderFiles(landingCloudFileNames);
        }
        LOG.info("Cleaned up all raw files");
    }
}
