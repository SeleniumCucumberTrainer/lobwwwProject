package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"beam2bq","TechComputeSmoke"})
public class TC03_beam2bq_curationTest extends TechComputeCommonFun{
   public TC03_beam2bq_curationTest() throws IOException {
        super("TC03_beam2bq_curationTestData.properties");
    }

}
