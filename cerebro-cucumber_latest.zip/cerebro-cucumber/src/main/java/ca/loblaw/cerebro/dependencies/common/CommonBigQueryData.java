package ca.loblaw.cerebro.dependencies.common;

import com.google.cloud.bigquery.TableResult;

public class CommonBigQueryData {

    private TableResult bigQueryResult;

    public TableResult getBigQueryResult() {
        return bigQueryResult;
    }

    public void setBigQueryResult(TableResult bigQueryResult) {
        this.bigQueryResult = bigQueryResult;
    }
}
