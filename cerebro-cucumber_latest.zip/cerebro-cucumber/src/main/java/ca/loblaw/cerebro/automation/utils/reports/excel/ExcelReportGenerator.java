package ca.loblaw.cerebro.automation.utils.reports.excel;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class ExcelReportGenerator<T> {

    // Excel fields
    private static final String BASE_FOLDER = "target/";
    protected final XSSFWorkbook reportWorkbook = new XSSFWorkbook();
    private final Map<String, XSSFCellStyle> cellStyleMap = new HashMap<>();
    protected String reportPath; // Local file report path
    protected String sheetName;

    public void setReportPath(String folder, String fileName) {
        this.reportPath =  BASE_FOLDER + folder + fileName + ".xlsx";
    }

    public abstract void reportResults(List<String> headers, T results) throws IOException;

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public void writeToFileAndClose() throws IOException {
        File reportDirectory = new File(FilenameUtils.getPath(reportPath));
        if (!reportDirectory.exists()) reportDirectory.mkdirs();

        File reportFile = new File(reportPath);
        if (!reportFile.exists()) reportFile.createNewFile();

        try (OutputStream fileOut = new FileOutputStream(reportPath)) {
            reportWorkbook.write(fileOut);
        } finally {
            reportWorkbook.close();
        }
    }

    public XSSFCellStyle createCellStyle(XSSFColor color) {
        XSSFCellStyle cellStyle = reportWorkbook.createCellStyle();
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle.setFillBackgroundColor(color);
        cellStyle.setFillForegroundColor(color);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);

        return cellStyle;
    }

    public void putCellStyle(String name, XSSFCellStyle cellStyle) {
        cellStyleMap.put(name, cellStyle);
    }

    public XSSFCellStyle getCellStyle(String name) {
        return cellStyleMap.get(name);
    }
}
