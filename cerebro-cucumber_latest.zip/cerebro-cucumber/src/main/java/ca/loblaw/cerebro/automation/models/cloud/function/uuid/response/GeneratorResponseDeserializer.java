package ca.loblaw.cerebro.automation.models.cloud.function.uuid.response;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GeneratorResponseDeserializer extends JsonDeserializer<GeneratorResponse> {
    @Override
    public GeneratorResponse deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        JsonNode root = jsonParser.readValueAsTree();
        JsonNode data = root.get("data");

        if (data.isTextual()) {
            return new GeneratorResponse(data.asText());
        } else if (data.isArray()) {
            String uuidFieldName = "uuid-" + TestContext.ENV;
            List<GeneratorResponseFile> responseFileList = new ArrayList<>();

            ArrayNode dataArray = (ArrayNode) data;
            for (JsonNode dataNode : dataArray) {
                String blob = dataNode.get("target_blob").asText();
                String uuid = dataNode.get(uuidFieldName).asText();
                responseFileList.add(new GeneratorResponseFile(blob, uuid));
            }

            return new GeneratorResponse(responseFileList);
        } else {
            throw new JsonParseException(jsonParser, "Field \"data\" is neither JSON string or array");
        }
    }
}
