package ca.loblaw.cerebro.automation.utils.reports.extent;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.ViewName;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ExtentManager is a utility class for handling Extent reports and tests representing the
 * test classes being executed. ExtentManager is thread-safe if the conditions at the bottom are met.
 *
 * Correlation:
 *      Extent Report: Correlates to a TestNG XML 'test' tag (or test bundle to avoid confusion).
 *      Extent Test: Correlates to a run instance of a test class.
 *      Extent Node: Correlates to a test method execution within a test instance.
 *
 * As a result, it is assumed that a TestNG run only runs one suite, and the test bundle within the suite are
 * ran sequentially.
 */
public class ExtentManager {

    private static final String EXTENT_CONFIG_PATH = "src/main/resources/spark-config.xml";

    // Extent report document
    private static ExtentReports EXTENT_REPORT;

    // Extent tests, one per test instance
    private static final ConcurrentHashMap<String, ExtentTest> EXTENT_TEST_MAP = new ConcurrentHashMap<>();

    // Extent nodes, associated with one Extent test
    private static final ConcurrentHashMap<String, ExtentTest> EXTENT_NODE_MAP = new ConcurrentHashMap<>();

    private ExtentManager() {}

    //------------------------------------------------------------------------------------------------------------------
    // Extent Report
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Creates an Extent Report object for the given suite and test bundle.
     *
     * @param suiteName TestNG XML suite name.
     * @param bundleName TestNG XML test bundle name.
     * @throws IOException Error loading config file.
     */
    public synchronized static void createExtentReport(String suiteName, String bundleName) throws IOException {
        // Spark report options
        String reportPath = String.format("target/cerebro-report/%s/%s.html", suiteName, bundleName);
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
        sparkReporter
                .viewConfigurer()
                .viewOrder()
                .as(new ViewName[]{
                        ViewName.DASHBOARD,
                        ViewName.TEST,
                        ViewName.CATEGORY,
                        ViewName.EXCEPTION,
                        ViewName.LOG
                })
                .apply();

        // Load XML config
        sparkReporter.loadXMLConfig(EXTENT_CONFIG_PATH);

        // Create report
        EXTENT_REPORT = new ExtentReports();
        EXTENT_REPORT.attachReporter(sparkReporter);
    }

    /**
     * Saves the Extent Report to a file realization and cleans the ExtentManager. Used at the end of a test bundle.
     */
    public synchronized static void save() {
        EXTENT_REPORT.flush();
        EXTENT_REPORT = null;
        EXTENT_TEST_MAP.clear();
        EXTENT_NODE_MAP.clear();
    }

    //------------------------------------------------------------------------------------------------------------------
    // Extent Tests
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Creates an Extent Test representation of a test class instance.
     *
     * @param testName Unique Extent Test name. Used as the Extent key.
     * @param categories Categories applied to Extent Test.
     */
    public synchronized static void createExtentTest(String testName, String[] categories) {
        ExtentTest extentTest = EXTENT_REPORT.createTest(testName).assignCategory(categories);
        EXTENT_TEST_MAP.put(testName, extentTest);
    }

    public static ExtentTest getExtentTest(String testName) {
        return EXTENT_TEST_MAP.get(testName);
    }

    public static void clearExtentTest(String testName) {
        EXTENT_TEST_MAP.remove(testName);
    }

    public static boolean hasExtentTest(String testName) {
        return EXTENT_TEST_MAP.containsKey(testName);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Extent Nodes
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Creates an Extent Node representation of a test method in a test class instance.
     *
     * @param testName Unique test name for the test class instance. Used as the Extent key.
     * @param nodeName Extent Node name.
     */
    public synchronized static void createExtentNode(String testName, String nodeName, String[] categories) {
        ExtentTest extentNode = EXTENT_TEST_MAP.get(testName).createNode(nodeName).assignCategory(categories);
        EXTENT_NODE_MAP.put(testName, extentNode);
    }

    public static ExtentTest getExtentNode(String testName) {
        return EXTENT_NODE_MAP.get(testName);
    }

    public static void clearExtentNode(String testName) {
        EXTENT_NODE_MAP.remove(testName);
    }

    public static boolean hasExtentNode(String testName) {
        return EXTENT_NODE_MAP.containsKey(testName);
    }
}
