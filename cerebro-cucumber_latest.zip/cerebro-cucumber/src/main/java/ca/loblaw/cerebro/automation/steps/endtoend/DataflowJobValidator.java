package ca.loblaw.cerebro.automation.steps.endtoend;

import ca.loblaw.cerebro.automation.models.cloud.dataflow.DataflowResults;
import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.cloud.dataflow.DataflowService;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.dataflow.v1beta3.Job;
import com.google.dataflow.v1beta3.JobMetrics;
import com.google.dataflow.v1beta3.JobState;
import com.google.dataflow.v1beta3.MetricUpdate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DataflowJobValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(DataflowJobValidator.class);

    public static void validateDataflowJob(String dataflowJobId) throws IOException {
        Job dataflowJob = DataflowService.getDataflowJob(
                Project.TECHCOMPUTE_ZONE.getName(),
                "northamerica-northeast1",
                dataflowJobId
        );

        Assertions.assertThat(dataflowJob)
                .as("Dataflow job exists", dataflowJobId)
                .isNotNull();
        Reporter.pass(LOG, "Dataflow job exists");

        Assertions.assertThat(dataflowJob.getCurrentState())
                .as("Dataflow job state")
                .isEqualTo(JobState.JOB_STATE_DONE);
        Reporter.pass(LOG, "Dataflow job passed");
    }

    public static void validateDataflowInputCount(long dataflowInputCount, long expectedInputCount, String expectedInputInfo) {
        Assertions.assertThat(dataflowInputCount)
                .as("Dataflow job input")
                .isEqualTo(expectedInputCount);

        Reporter.pass(LOG, "Dataflow job input count is equal to {}", expectedInputInfo);
    }

    public static void validateDataflowRecordCount(long dataflowRecordCount, long expectedRecordCount) {
        Assertions.assertThat(dataflowRecordCount)
                .as("Dataflow record count")
                .isEqualTo(expectedRecordCount);

        Reporter.pass(LOG, "Dataflow job record count is equal to number of rows inserted into BigQuery table");
    }

    public static DataflowResults retrieveDataflowMetrics(String dataflowJobId, List<String> inputTasks,
                                                          List<String> recordTasks, List<String> errorTasks) {
        JobMetrics dataflowJobMetrics = DataflowService.getDataflowJobMetrics(
                Project.TECHCOMPUTE_ZONE.getName(),
                "northamerica-northeast1",
                dataflowJobId
        );
        assert dataflowJobMetrics != null;

        // Dataflow results count
        long dataflowInputCount = 0;
        long dataflowRecordCount = 0;
        long dataflowErrorCount = 0;

        Set<String> taskSet = new HashSet<>(); // Set to prevent adding count to duplicate tasks in metrics

        // Parse metrics
        for (MetricUpdate update : dataflowJobMetrics.getMetricsList()) {
            String updateName = update.getName().getName();
            String contextValue = update.getName().getContextMap().get("output_user_name");

            if (updateName.equals("ElementCount")) {
                // Input tasks
                for (String inputTask : inputTasks) {
                    if (contextValue.startsWith(inputTask) && !taskSet.contains(inputTask)) {
                        dataflowInputCount = (long) update.getScalar().getNumberValue();
                        taskSet.add(inputTask);
                        break;
                    }
                }

                // Output tasks
                for (String recordTask : recordTasks) {
                    if (contextValue.startsWith(recordTask) && !taskSet.contains(recordTask)) {
                        dataflowRecordCount = (long) update.getScalar().getNumberValue();
                        taskSet.add(recordTask);
                        break;
                    }
                }

                // Error tasks
                for (String errorTask : errorTasks) {
                    if (contextValue.startsWith(errorTask) && !taskSet.contains(errorTask)) {
                        dataflowErrorCount += (long) update.getScalar().getNumberValue();
                        taskSet.add(errorTask);
                        break;
                    }
                }
            }
        }

        Reporter.info(LOG, "Number of elements inputted into Dataflow is {}", dataflowInputCount);
        Reporter.info(LOG, "Number of elements processed by Dataflow is {}", dataflowRecordCount);
        Reporter.info(LOG, "Number of error elements in Dataflow is {}", dataflowErrorCount);

        return new DataflowResults(dataflowInputCount, dataflowRecordCount, dataflowErrorCount);
    }
}
