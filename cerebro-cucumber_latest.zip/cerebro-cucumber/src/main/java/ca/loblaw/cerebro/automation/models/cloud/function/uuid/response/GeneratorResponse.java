package ca.loblaw.cerebro.automation.models.cloud.function.uuid.response;

import ca.loblaw.cerebro.automation.models.cloud.function.FunctionResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.List;

@JsonDeserialize(using = GeneratorResponseDeserializer.class)
public class GeneratorResponse implements FunctionResponse {

    @JsonProperty("data")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<GeneratorResponseFile> data;

    @JsonProperty("uuid")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String uuid; // UUID only mode

    public GeneratorResponse(String uuid) {
        this.uuid = uuid;
    }

    public GeneratorResponse(List<GeneratorResponseFile> data) {
        this.data = data;
    }

    public List<GeneratorResponseFile> getData() {
        return data;
    }

    public String getUuid() {
        return uuid;
    }
}
