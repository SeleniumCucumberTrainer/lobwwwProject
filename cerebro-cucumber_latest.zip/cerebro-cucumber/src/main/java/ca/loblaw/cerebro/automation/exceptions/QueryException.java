package ca.loblaw.cerebro.automation.exceptions;

public class QueryException extends RuntimeException {

    public QueryException(String message) {
        super(message);
    }

    public QueryException(String message, Object... args) {
        super(String.format(message, args));
    }
}
