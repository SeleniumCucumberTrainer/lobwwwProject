package ca.loblaw.cerebro.automation.models.data;

public class RawFolders {
    private final String landing;
    private final String working;
    private final String processed;
    private final String rejected;

    public RawFolders(String rawFolderPath) {
        this.landing = rawFolderPath.replace("...", "landing");
        this.working = rawFolderPath.replace("...", "working");
        this.processed = rawFolderPath.replace("...", "processed");
        this.rejected = rawFolderPath.replace("...", "rejected");
    }

    public String getFolderFromStage(String stage) {
        switch (stage) {
            case "landing":
                return getLanding();
            case "working":
                return getWorking();
            case "processed":
                return getProcessed();
            default:
                return getRejected();
        }
    }

    public String getLanding() {
        return landing;
    }

    public String getWorking() {
        return working;
    }

    public String getProcessed() {
        return processed;
    }

    public String getRejected() {
        return rejected;
    }
}
