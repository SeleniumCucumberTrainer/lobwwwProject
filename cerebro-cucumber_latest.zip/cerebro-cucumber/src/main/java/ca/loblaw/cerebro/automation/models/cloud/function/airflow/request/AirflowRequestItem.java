package ca.loblaw.cerebro.automation.models.cloud.function.airflow.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

public class AirflowRequestItem {

    @JsonProperty("dag_id")
    private final String dagId;

    @JsonProperty("dag_run_id")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String dagRunId = "";

    @JsonProperty("task_id")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String taskId = "";

    @JsonProperty("extra")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private Map<String, String> extra = new HashMap<>();

    public AirflowRequestItem(String dagId) {
        this.dagId = dagId;
    }

    public String getDagId() {
        return dagId;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public void addExtra(String key, String value) {
        extra.put(key, value);
    }

    public Map<String, String> getExtra() {
        return extra;
    }
}
