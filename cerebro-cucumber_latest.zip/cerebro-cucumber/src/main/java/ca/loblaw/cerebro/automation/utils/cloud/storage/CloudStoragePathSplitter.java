package ca.loblaw.cerebro.automation.utils.cloud.storage;

/**
 * Helper class for splitting a GCS path into
 * its bucket string and file name string.
 */
public class CloudStoragePathSplitter {

    private final String bucketName;

    private final String fileName;

    private CloudStoragePathSplitter(String bucketName, String fileName) {
        this.bucketName = bucketName;
        this.fileName = fileName;
    }

    public static CloudStoragePathSplitter splitPath(String cloudStoragePath) {
        String trimmedPath = cloudStoragePath.replaceFirst("gs://", "");
        String[] splitPath = trimmedPath.split("/", 2);
        return new CloudStoragePathSplitter(splitPath[0], splitPath[1]);
    }

    public String getBucketName() {
        return bucketName;
    }

    public String getFileName() {
        return fileName;
    }
}
