package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstanceState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseTaskInstanceItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseTaskInstances;

import java.util.Map;

public class TaskInstancesHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseTaskInstances responseTaskInstances = (AirflowResponseTaskInstances) airflowResponseItem;

        dagRun.clearTaskInstances();

        // Store task instances
        for (AirflowResponseTaskInstanceItem responseTaskInstanceItem : responseTaskInstances.getTaskList()) {
            String taskId = responseTaskInstanceItem.getTaskId();
            TaskInstanceState taskState = TaskInstanceState.from(responseTaskInstanceItem.getTaskState());
            String startDate = responseTaskInstanceItem.getStartDate();
            String endDate = responseTaskInstanceItem.getEndDate();
            int maxTries = responseTaskInstanceItem.getMaxTries();
            int tryNumber = responseTaskInstanceItem.getTryNumber();
            Map<String, Object> keywordArguments = responseTaskInstanceItem.getKeywordArguments();

            dagRun.addTaskInstance(new TaskInstance(taskId, taskState, startDate, endDate, maxTries, tryNumber, keywordArguments));
        }
    }
}
