package ca.loblaw.cerebro.automation.testcases.endtoend.marketingchannels;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "offer-wallet", "marketingchannels" })
public class Offer_Wallet_Test extends EndToEndTest {
    public Offer_Wallet_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/marketingchannels/offer_wallet.properties");
    }
}
