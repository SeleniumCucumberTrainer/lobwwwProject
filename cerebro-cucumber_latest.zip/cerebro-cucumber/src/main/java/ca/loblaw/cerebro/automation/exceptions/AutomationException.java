package ca.loblaw.cerebro.automation.exceptions;

/**
 * Exception class representing Test Automation Framework programming and setup errors.
 */
public class AutomationException extends RuntimeException {

    public AutomationException(String message) {
        super(message);
    }

    public AutomationException(String message, Object... args) {
        super(String.format(message, args));
    }
}
