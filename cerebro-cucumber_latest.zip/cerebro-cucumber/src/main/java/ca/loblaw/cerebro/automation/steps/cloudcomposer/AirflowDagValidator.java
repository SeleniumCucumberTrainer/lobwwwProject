package ca.loblaw.cerebro.automation.steps.cloudcomposer;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRunState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.exceptions.DagException;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.ComposerMetadataLog;
import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;

/**
 * Validator class to validate DAG run information.
 */
public class AirflowDagValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(AirflowDagValidator.class);
    private static final String TRACE_ID_REGEX = ".*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}.*";

    public AirflowDagValidator() {
        super();
    }

    /**
     * Validates DAG run state.
     * @param dagRun DAG run to validate.
     */
    public static void validateDagRunInfo(DagRun dagRun) {
        Reporter.info(LOG,"Validating DAG {} run info", dagRun.getDagId());

        if (dagRun.hasRunId()) {
            // Validate DAG run
            Assertions.assertThat(dagRun.getState())
                    .as("Check DAG %s run state for %s", dagRun.getDagId(), dagRun.getDagRunId())
                    .isEqualTo(DagRunState.SUCCESS);

            Reporter.pass(LOG, "DAG {} with run ID {} was successful", dagRun.getDagId(), dagRun.getDagRunId());
        } else {
            throw new DagException("DAG %s was expected to have a finished run, but did not", dagRun.getDagId());
        }
    }

    /**
     * Validate DAG run task instances.
     * @param dagRun DAG run to validate.
     */
    public static void validateDagTaskInstances(DagRun dagRun) {
        Reporter.info(LOG,"Validating DAG {} run task instances", dagRun.getDagId());

        // No task instances
        if (!dagRun.hasTaskInstances()) {
            Assertions.fail("DAG %s with run ID %s has no task instances",
                    dagRun.getDagId(), dagRun.getDagRunId());
        }
        // Outdated task instances
        else if (dagRun.isOutdated()) {
            Reporter.warn(LOG, "Skipping task instances validation due to outdated DAG run");
        }
        else {
            // Validate task instances
            SoftAssertions taskAssertions = new SoftAssertions();
            for (TaskInstance taskInstance : dagRun.getTaskInstances()) {
                taskAssertions.assertThat(taskInstance.isPassing())
                        .as("Check task %s is passing", taskInstance.getTaskId())
                        .isTrue();
            }
            taskAssertions.assertAll();
            Reporter.pass(LOG, "DAG {} with run ID {} has all tasks passing", dagRun.getDagId(), dagRun.getDagRunId());
        }
    }
}
