package ca.loblaw.cerebro.automation.steps.endtoend;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.IngestionTasks;
import ca.loblaw.cerebro.automation.models.cloud.bigquery.TotalStats;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.cloudfunction.FileRoutingMetadataLog;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.CurationComposerMetadataLog;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.IngestionComposerMetadataLog;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.PublicationComposerMetadataLog;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.SnapshotComposerMetadataLog;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.dataflow.DataflowMetadataLog;
import ca.loblaw.cerebro.automation.models.validations.CurationComposerValidationDto;
import ca.loblaw.cerebro.automation.models.validations.IngestionComposerValidationDto;
import ca.loblaw.cerebro.automation.models.validations.PublicationComposerValidationDto;
import ca.loblaw.cerebro.automation.models.validations.SnapshotComposerValidationDto;
import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.cloud.logging.CloudLoggingService;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileContainer;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.CerebroPatterns;
import ca.loblaw.cerebro.automation.utils.internal.JsonUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.cloud.logging.LogEntry;
import com.google.cloud.logging.Payload;
import com.google.cloud.logging.Severity;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.IntBinaryOperator;
import java.util.stream.Collectors;

public class DataObservabilityValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(DataObservabilityValidator.class);

    public static void validateFileRoutingMetadataLogs(String landingStartTime, List<CloudStorageFile> nonDfmLandingTestCloudFiles,
                                                       List<CloudStorageFile> nonDfmRawTestCloudFiles) throws InterruptedException {
        Thread.sleep(10000);

        // Find non-DFM files to retrieve metadata log
        List<String> nonDfmFileNames = CloudStorageFileContainer.wrap(nonDfmRawTestCloudFiles).toFileNamesList();
        Reporter.info(LOG, "There are {} non-DFM files routed", nonDfmFileNames.size());

        // Fetch Cloud logs
        CloudLoggingService.Filter filter = new CloudLoggingService.Filter()
                .addCondition("logName", "=", TestContext.replaceTemplateEnv("projects/lt-dia-lake-${ENV}-techcompute/logs/observability_logs_info"))
                .and()
                .addCondition("timestamp", ">=", landingStartTime)
                .and()
                .addMultipleConditions("jsonPayload.cf_file_nm", "=", nonDfmFileNames);
        List<LogEntry> fileRoutingLogs = CloudLoggingService.getLogs(filter, nonDfmFileNames.size());
        Reporter.info(LOG, "Retrieved file routing metadata logs");

        Assertions.assertThat(fileRoutingLogs.size())
                .as("Number of file routing metadata logs")
                .isEqualTo(nonDfmFileNames.size());
        Reporter.pass(LOG, "Number of file routing metadata logs ({}) are equal to number of non-DFM files routed", fileRoutingLogs.size());

        // Convert payloads to Java objects, sorted by landing path name
        // to match landingCloudFiles and rawCloudFiles order
        List<FileRoutingMetadataLog> metadataLogs = convertCloudLoggingJsonPayloads(
                fileRoutingLogs,
                FileRoutingMetadataLog.class,
                Comparator.comparing(FileRoutingMetadataLog::getSourcePath));

        // Validations per file routing metadata log
        SoftAssertions routingAssertions = new SoftAssertions();
        int cloudFileIndex = 0;
        for (FileRoutingMetadataLog fileRoutingMetadataLog : metadataLogs) {
            Reporter.info(LOG, fileRoutingMetadataLog);

            CloudStorageFile landingFile = nonDfmLandingTestCloudFiles.get(cloudFileIndex);
            CloudStorageFile rawFile = nonDfmRawTestCloudFiles.get(cloudFileIndex);
            cloudFileIndex++;

            // --- Validations ---
            String fileName = FilenameUtils.getName(rawFile.getName());

            // cf_execution_rslt
            routingAssertions.assertThat(fileRoutingMetadataLog.getExecutionResult())
                    .as("'%s' file routing metadata log -- cf_execution_rslt", fileName)
                    .isEqualTo("Pass");

            // cf_execution_tms
            routingAssertions.assertThat(fileRoutingMetadataLog.getExecutionTimestamp())
                    .as("'%s' file routing metadata log -- cf_execution_tms", fileName)
                    .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

            // cf_file_nm
            routingAssertions.assertThat(fileRoutingMetadataLog.getFileName())
                    .as("'%s' file routing metadata log -- cf_file_nm", fileName)
                    .isEqualTo(fileName);

            // cf_instance_id
            routingAssertions.assertThat(fileRoutingMetadataLog.getInstanceId())
                    .as("'%s' file routing metadata log -- cf_instance_id", fileName)
                    .isNotBlank();

            // cf_job_nm
            routingAssertions.assertThat(fileRoutingMetadataLog.getJobName())
                    .as("'%s' file routing metadata log -- cf_job_nm", fileName)
                    .isEqualTo("file-router-" + TestContext.ENV + "-qa");

            // cf_serv_acct_id
            routingAssertions.assertThat(fileRoutingMetadataLog.getServiceAccount())
                    .as("'%s' file routing metadata log -- cf_serv_acct_id", fileName)
                    .isEqualTo("sa-cerebro-prd-landing-cfrun@lt-dia-lake-prd-landing.iam.gserviceaccount.com");

            // cf_src_path
            routingAssertions.assertThat(fileRoutingMetadataLog.getSourcePath())
                    .as("'%s' file routing metadata log -- cf_src_path", fileName)
                    .isEqualTo(landingFile.getName().replaceFirst("gs://", ""));

            // cf_src_tms
            routingAssertions.assertThat(fileRoutingMetadataLog.getSourceTimestamp())
                    .as("'%s' file routing metadata log -- cf_src_tms", fileName)
                    .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

            // cf_tgt_path
            routingAssertions.assertThat(fileRoutingMetadataLog.getTargetPath())
                    .as("'%s' file routing metadata log -- cf_tgt_path", fileName)
                    .isEqualTo(rawFile.getName().replaceFirst("gs://", "").replaceFirst("\\.\\.\\.", "landing"));

            // cf_tgt_tms
            routingAssertions.assertThat(fileRoutingMetadataLog.getTargetTimestamp())
                    .as("'%s' file routing metadata log -- cf_tgt_tms", fileName)
                    .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

            // entity_trace_id
            routingAssertions.assertThat(fileRoutingMetadataLog.getEntityTraceId())
                    .as("'%s' file routing metadata log -- entity_trace_id", fileName)
                    .isEqualTo(landingFile.getMetadata().get("uuid-" + TestContext.ENV));

            // zone
            routingAssertions.assertThat(fileRoutingMetadataLog.getZone())
                    .as("'%s' file routing metadata log -- zone", fileName)
                    .isEqualTo("landing");
        }
        routingAssertions.assertAll();
        Reporter.pass(LOG, "All file routing metadata logs are valid");
    }

    public static void validateIngestionComposerMetadataLogs(IngestionComposerValidationDto ingestionDto) throws InterruptedException {
        Thread.sleep(10000);

        DagRun ingestionDag = ingestionDto.getDagRun();
        Reporter.info(LOG, "Retrieving and validating Ingestion composer metadata logs ...");

        // Find ingestion composer metadata logs
        CloudLoggingService.Filter filter = new CloudLoggingService.Filter()
                .addCondition("logName", "=", TestContext.replaceTemplateEnv("projects/lt-dia-lake-${ENV}-techcompute/logs/observability_logs_info"))
                .and()
                .addCondition("jsonPayload.cc_dag_nm", "=", ingestionDag.getDagId())
                .and()
                .addCondition("jsonPayload.cc_dag_run_id", "=", ingestionDag.getDagRunId());

        List<LogEntry> composerLogs = CloudLoggingService.getLogs(filter, 2);
        Assertions.assertThat(composerLogs.size())
                .as("Number of Ingestion composer metadata logs")
                .isEqualTo(1);
        Reporter.pass(LOG, "Only 1 Ingestion composer metadata log was found");

        // Conversion
        LogEntry logEntry = composerLogs.get(0);
        Payload.JsonPayload jsonPayload = logEntry.getPayload();

        Reporter.info(LOG, "Ingestion composer metadata log: {}", jsonPayload.getDataAsMap());
        IngestionComposerMetadataLog metadataLog = JsonUtils.readMapToObject(jsonPayload.getDataAsMap(), IngestionComposerMetadataLog.class);

        // Validations
        SoftAssertions metadataAssertions = new SoftAssertions();

        // --------------------- Log Details ---------------------
        // severity
        metadataAssertions.assertThat(logEntry.getSeverity())
                .as("severity")
                .isEqualTo(Severity.INFO);

        // resource.type
        metadataAssertions.assertThat(logEntry.getResource().getType())
                .as("resource.type")
                .isEqualTo("cloud_composer_environment");

        // --------------------- JSON Payload ---------------------
        // job_run_trace_id
        metadataAssertions.assertThat(metadataLog.getTraceIds())
                .as("jsonPayload.job_run_trace_id")
                .containsExactly(ingestionDto.getJobRunTraceId());

        // zone
        metadataAssertions.assertThat(metadataLog.getZone())
                .as("jsonPayload.zone")
                .isEqualTo("ingestion");

        // cc_serv_acct_id
        metadataAssertions.assertThat(metadataLog.getServiceAccount())
                .as("jsonPayload.cc_serv_acct_id")
                .isEqualTo(TestContext.replaceTemplateEnv("sa-cerebro-${ENV}-tec-dfcontrol@lt-dia-lake-${ENV}-techcompute.iam.gserviceaccount.com"));

        // cc_dag_nm
        metadataAssertions.assertThat(metadataLog.getDagName())
                .as("jsonPayload.cc_dag_nm")
                .isEqualTo(ingestionDag.getDagId());

        // cc_dag_run_id
        metadataAssertions.assertThat(metadataLog.getDagRunId())
                .as("jsonPayload.cc_dag_run_id")
                .isEqualTo(ingestionDag.getDagRunId());

        // cc_dag_execution_strt_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionStartTime())
                .as("jsonPayload.cc_dag_execution_strt_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_execution_end_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionEndTime())
                .as("jsonPayload.cc_dag_execution_end_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_elpsed_tms
        metadataAssertions.assertThat(metadataLog.getDagElapsedTime())
                .as("jsonPayload.cc_dag_elpsed_tms")
                .isNotEmpty();

        // cc_execution_rslt
        metadataAssertions.assertThat(metadataLog.getDagExecutionResult())
                .as("jsonPayload.cc_execution_rslt")
                .isEqualTo("Pass");

        // cc_tbl_rec_cre_tms
        metadataAssertions.assertThat(metadataLog.getTableRecordCreateTimestamp())
                .as("jsonPayload.cc_tbl_rec_cre_tms")
                .isEqualTo(ingestionDto.getRecCreTms() + " UTC");

        // cc_src_nm
        metadataAssertions.assertThat(metadataLog.getSourceName())
                .as("jsonPayload.cc_src_nm")
                .isEqualTo(ingestionDto.getRawFolderPath().replaceFirst("\\.\\.\\.", "landing"));

        // cc_tgt_nm
        metadataAssertions.assertThat(metadataLog.getTargetName())
                .as("jsonPayload.cc_tgt_nm")
                .isEqualTo(ingestionDto.getDatasetTable());

        // cc_no_rows_loaded
        metadataAssertions.assertThat(metadataLog.getNumberRowLoaded())
                .as("jsonPayload.cc_no_rows_loaded")
                .isEqualTo(String.valueOf(ingestionDto.getTableRecordCount()));

        // cc_no_src_entity_present
        metadataAssertions.assertThat(metadataLog.getNumberSourceEntityPresent())
                .as("jsonPayload.cc_no_src_entity_present")
                .isEqualTo(String.valueOf(ingestionDto.getBatchRawFilesSize()));

        // cc_file_processed_tms
        metadataAssertions.assertThat(metadataLog.getFileProcessedTimestamp())
                .as("jsonPayload.cc_file_processed_tms")
                .isEqualTo(convertToMetadataTimestamp(ingestionDag.getTaskInstance(IngestionTasks.MOVE_TO_PROCESSED).getStartDate()));

        // cc_file_working_tms
        metadataAssertions.assertThat(metadataLog.getFileWorkingTimestamp())
                .as("jsonPayload.cc_file_working_tms")
                .isEqualTo(convertToMetadataTimestamp(ingestionDag.getTaskInstance(IngestionTasks.MOVE_TO_WORKING).getStartDate()));

        // cc_file_rejected_tms
        metadataAssertions.assertThat(metadataLog.getFileRejectTimestamp())
                .as("jsonPayload.cc_file_rejected_tms")
                .isNull();

        // df_job_nm
        metadataAssertions.assertThat(metadataLog.getDataflowJobName())
                .as("jsonPayload.df_job_nm")
                .isEqualTo(ingestionDto.getDataflowJobName());

        // df_job_run_id
        metadataAssertions.assertThat(metadataLog.getDataflowJobRunId())
                .as("jsonPayload.df_job_run_id")
                .isEqualTo(ingestionDto.getDataflowJobId());

        // df_job_execution_strt_tms
        metadataAssertions.assertThat(metadataLog.getDataflowJobExecutionStartTime())
                .as("jsonPayload.df_job_execution_strt_tms")
                .isEqualTo(convertToMetadataTimestamp(ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getStartDate()));

        // df_job_execution_end_tms
        metadataAssertions.assertThat(metadataLog.getDataflowJobExecutionEndTime())
                .as("jsonPayload.df_job_execution_end_tms")
                .isEqualTo(convertToMetadataTimestamp(ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getEndDate()));

        // df_job_elpsd_tms
        metadataAssertions.assertThat(metadataLog.getDataflowJobElapsedTime())
                .as("jsonPayload.df_job_elpsd_tms")
                .isNotEmpty();

        // df_execution_rslt
        metadataAssertions.assertThat(metadataLog.getDataflowJobResult())
                .as("jsonPayload.df_execution_rslt")
                .isEqualTo("Pass");

        // df_all_file_nbrs_rows_parsed
        metadataAssertions.assertThat(metadataLog.getDataflowAllRowsParsedCount())
                .as("jsonPayload.df_all_file_nbrs_rows_parsed")
                .isEqualTo(String.valueOf(ingestionDto.getDataflowRecordCount()));

        // df_all_file_nbrs_err_rows - Using >= due to inconsistent behaviour from purely reading Dataflow tasks
        metadataAssertions.assertThat(metadataLog.getDataflowAllErrorRowsCount())
                .as("jsonPayload.df_all_file_nbrs_err_rows")
                .isGreaterThanOrEqualTo(String.valueOf(ingestionDto.getDataflowErrorCount()));

        metadataAssertions.assertAll();
    }

    public static void validateIngestionDataflowMetadataLogs(String ingestionDataflowJobName) {
        // Find logs
        CloudLoggingService.Filter filter = new CloudLoggingService.Filter()
                .addCondition("logName", "=", TestContext.replaceTemplateEnv("projects/lt-dia-lake-${ENV}-techcompute/logs/observability_logs_info"))
                .and()
                .addCondition("jsonPayload.df_job_nm", "=~", ingestionDataflowJobName);

        List<LogEntry> dataflowLogs = CloudLoggingService.getLogs(filter, 1);

        Assertions.assertThat(!dataflowLogs.isEmpty())
                .as("Dataflow Metadata Log not found");

        // Conversion
        List<DataflowMetadataLog> metadataLogs = convertCloudLoggingJsonPayloads(
                dataflowLogs,
                DataflowMetadataLog.class,
                Comparator.comparing(DataflowMetadataLog::getFileName));

        // Validations
        SoftAssertions metadataAssertions = new SoftAssertions();
        metadataAssertions.assertAll();
    }

    public static void validateSnapshotComposerMetadataLog(SnapshotComposerValidationDto snapshotDto) throws InterruptedException {
        Thread.sleep(10000);

        DagRun snapshotDag = snapshotDto.getDagRun();
        Reporter.info(LOG, "Retrieving and validating Snapshot composer metadata logs ...");

        // Find ingestion composer metadata logs
        CloudLoggingService.Filter filter = new CloudLoggingService.Filter()
                .addCondition("logName", "=", TestContext.replaceTemplateEnv("projects/lt-dia-lake-${ENV}-techcompute/logs/observability_logs_info"))
                .and()
                .addCondition("jsonPayload.cc_dag_nm", "=", snapshotDag.getDagId())
                .and()
                .addCondition("jsonPayload.cc_dag_run_id", "=~", CerebroPatterns.escapeRegExp(snapshotDag.getDagRunId()));

        List<LogEntry> composerLogs = CloudLoggingService.getLogs(filter, 2);
        Assertions.assertThat(composerLogs.size())
                .as("Number of Snapshot composer metadata logs")
                .isEqualTo(1);
        Reporter.pass(LOG, "Only 1 Snapshot composer metadata log was found");

        // Conversion
        LogEntry logEntry = composerLogs.get(0);
        Payload.JsonPayload jsonPayload = logEntry.getPayload();

        Reporter.info(LOG, "Snapshot composer metadata log: {}", jsonPayload.getDataAsMap());
        SnapshotComposerMetadataLog metadataLog = JsonUtils.readMapToObject(jsonPayload.getDataAsMap(), SnapshotComposerMetadataLog.class);

        // Validations
        SoftAssertions metadataAssertions = new SoftAssertions();

        // --------------------- Log Details ---------------------
        // severity
        metadataAssertions.assertThat(logEntry.getSeverity())
                .as("severity")
                .isEqualTo(Severity.INFO);

        // resource.type
        metadataAssertions.assertThat(logEntry.getResource().getType())
                .as("resource.type")
                .isEqualTo("cloud_composer_environment");

        // --------------------- JSON Payload ---------------------
        // job_run_trace_id
        metadataAssertions.assertThat(metadataLog.getTraceIds())
                .as("jsonPayload.job_run_trace_id")
                .containsExactly(snapshotDto.getJobRunTraceId());

        // zone
        metadataAssertions.assertThat(metadataLog.getZone())
                .as("jsonPayload.zone")
                .isEqualTo("snapshot");

        // cc_serv_acct_id
        metadataAssertions.assertThat(metadataLog.getServiceAccount())
                .as("jsonPayload.cc_serv_acct_id")
                .isEqualTo(TestContext.replaceTemplateEnv("sa-cerebro-${ENV}-tec-dfcontrol@lt-dia-lake-${ENV}-techcompute.iam.gserviceaccount.com"));

        // cc_dag_nm
        metadataAssertions.assertThat(metadataLog.getDagName())
                .as("jsonPayload.cc_dag_nm")
                .isEqualTo(snapshotDag.getDagId());

        // cc_dag_run_id
        metadataAssertions.assertThat(metadataLog.getDagRunId())
                .as("jsonPayload.cc_dag_run_id")
                .contains(snapshotDag.getDagRunId());

        // cc_dag_execution_strt_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionStartTime())
                .as("jsonPayload.cc_dag_execution_strt_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_execution_end_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionEndTime())
                .as("jsonPayload.cc_dag_execution_end_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_elpsed_tms
        metadataAssertions.assertThat(metadataLog.getDagElapsedTime())
                .as("jsonPayload.cc_dag_elpsed_tms")
                .isNotEmpty();

        // cc_execution_rslt
        metadataAssertions.assertThat(metadataLog.getDagExecutionResult())
                .as("jsonPayload.cc_execution_rslt")
                .isEqualTo("Pass");

        // cc_tbl_rec_cre_tms
        metadataAssertions.assertThat(metadataLog.getTableRecordCreateTimestamp())
                .as("jsonPayload.cc_tbl_rec_cre_tms")
                .isEqualTo(snapshotDto.getRecCreTms() + " UTC");

        // cc_no_rows_loaded
        metadataAssertions.assertThat(metadataLog.getNumberRowLoaded().split("\\.")[0])
                .as("jsonPayload.cc_no_rows_loaded")
                .isEqualTo(String.valueOf(snapshotDto.getTableRecordCount()));

        // cc_src_nm
        metadataAssertions.assertThat(metadataLog.getSourceName())
                .as("jsonPayload.cc_src_nm")
                .isEqualTo(snapshotDto.getSourceName());

        // cc_tgt_nm
        metadataAssertions.assertThat(metadataLog.getTargetName())
                .as("jsonPayload.cc_tgt_nm")
                .isEqualTo(snapshotDto.getTargetName());

        metadataAssertions.assertAll();
    }

    public static void validateCurationComposerMetadataLog(CurationComposerValidationDto curationDto) throws InterruptedException {
        Thread.sleep(10000);

        DagRun curationDag = curationDto.getDagRun();
        Reporter.info(LOG, "Retrieving and validating Curation composer metadata logs ...");

        // Find ingestion composer metadata logs
        CloudLoggingService.Filter filter = new CloudLoggingService.Filter()
                .addCondition("logName", "=", TestContext.replaceTemplateEnv("projects/lt-dia-lake-${ENV}-techcompute/logs/observability_logs_info"))
                .and()
                .addCondition("jsonPayload.cc_dag_nm", "=", curationDag.getDagId())
                .and()
                .addCondition("jsonPayload.cc_dag_run_id", "=~", CerebroPatterns.escapeRegExp(curationDag.getDagRunId()));

        List<LogEntry> composerLogs = CloudLoggingService.getLogs(filter, 2);
        Assertions.assertThat(composerLogs.size())
                .as("Number of Curation composer metadata logs")
                .isEqualTo(1);
        Reporter.pass(LOG, "Only 1 Curation composer metadata log was found");

        // Conversion
        LogEntry logEntry = composerLogs.get(0);
        Payload.JsonPayload jsonPayload = logEntry.getPayload();

        Reporter.info(LOG, "Curation composer metadata log: {}", jsonPayload.getDataAsMap());
        CurationComposerMetadataLog metadataLog = JsonUtils.readMapToObject(jsonPayload.getDataAsMap(), CurationComposerMetadataLog.class);

        // Validations
        SoftAssertions metadataAssertions = new SoftAssertions();

        // --------------------- Log Details ---------------------
        // severity
        metadataAssertions.assertThat(logEntry.getSeverity())
                .as("severity")
                .isEqualTo(Severity.INFO);

        // resource.type
        metadataAssertions.assertThat(logEntry.getResource().getType())
                .as("resource.type")
                .isEqualTo("cloud_composer_environment");

        // --------------------- JSON Payload ---------------------
        // job_run_trace_id
        metadataAssertions.assertThat(metadataLog.getTraceIds())
                .as("jsonPayload.job_run_trace_id")
                .containsExactly(curationDto.getJobRunTraceId());

        // zone
        metadataAssertions.assertThat(metadataLog.getZone())
                .as("jsonPayload.zone")
                .isEqualTo("curation");

        // cc_serv_acct_id
        metadataAssertions.assertThat(metadataLog.getServiceAccount())
                .as("jsonPayload.cc_serv_acct_id")
                .isEqualTo(TestContext.replaceTemplateEnv("sa-cerebro-${ENV}-tec-dfcontrol@lt-dia-lake-${ENV}-techcompute.iam.gserviceaccount.com"));

        // cc_dag_nm
        metadataAssertions.assertThat(metadataLog.getDagName())
                .as("jsonPayload.cc_dag_nm")
                .isEqualTo(curationDag.getDagId());

        // cc_dag_run_id
        metadataAssertions.assertThat(metadataLog.getDagRunId())
                .as("jsonPayload.cc_dag_run_id")
                .contains(curationDag.getDagRunId());

        // cc_dag_execution_strt_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionStartTime())
                .as("jsonPayload.cc_dag_execution_strt_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_execution_end_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionEndTime())
                .as("jsonPayload.cc_dag_execution_end_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_elpsed_tms
        metadataAssertions.assertThat(metadataLog.getDagElapsedTime())
                .as("jsonPayload.cc_dag_elpsed_tms")
                .isNotEmpty();

        // cc_execution_rslt
        metadataAssertions.assertThat(metadataLog.getDagExecutionResult())
                .as("jsonPayload.cc_execution_rslt")
                .isEqualTo("Pass");

        // cc_tbl_rec_cre_tms
        String curationRecCreTms = curationDto.getRecCreTms();
        if (curationRecCreTms.endsWith("000")) curationRecCreTms = curationRecCreTms.substring(0, curationRecCreTms.length() - 3);
        metadataAssertions.assertThat(metadataLog.getTableRecordCreateTimestamp())
                .as("jsonPayload.cc_tbl_rec_cre_tms")
                .isEqualTo(curationRecCreTms + " UTC");

        // cc_no_rows_loaded
        metadataAssertions.assertThat(metadataLog.getNumberRowLoaded())
                .as("jsonPayload.cc_no_rows_loaded")
                .isEqualTo(String.valueOf(curationDto.getTableRecordCount()));

        // cc_src_nm
        metadataAssertions.assertThat(metadataLog.getSourceName())
                .as("jsonPayload.cc_src_nm")
                .isEqualTo(curationDto.getSourceName());

        // cc_tgt_nm
        metadataAssertions.assertThat(metadataLog.getTargetName())
                .as("jsonPayload.cc_tgt_nm")
                .isEqualTo(curationDto.getTargetName());

        // df_job_nm
        metadataAssertions.assertThat(metadataLog.getDataflowJobName())
                .as("jsonPayload.df_job_nm")
                .isEqualTo(curationDto.getDataflowJobName());

        // df_job_run_id
        metadataAssertions.assertThat(metadataLog.getDataflowJobRunId())
                .as("jsonPayload.df_job_run_id")
                .isEqualTo(curationDto.getDataflowJobId());

        // df_job_execution_strt_tms
        metadataAssertions.assertThat(metadataLog.getDataflowJobExecutionStartTime())
                .as("jsonPayload.df_job_execution_strt_tms")
                .isEqualTo(convertToMetadataTimestamp(curationDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getStartDate()));

        // df_job_execution_end_tms
        metadataAssertions.assertThat(metadataLog.getDataflowJobExecutionEndTime())
                .as("jsonPayload.df_job_execution_end_tms")
                .isEqualTo(convertToMetadataTimestamp(curationDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getEndDate()));

        // df_job_elpsd_tms
        metadataAssertions.assertThat(metadataLog.getDataflowJobElapsedTime())
                .as("jsonPayload.df_job_elpsd_tms")
                .isNotEmpty();

        // df_execution_rslt
        metadataAssertions.assertThat(metadataLog.getDataflowJobResult())
                .as("jsonPayload.df_execution_rslt")
                .isEqualTo("Pass");

        metadataAssertions.assertAll();
    }

    public static void validatePublicationComposerMetadataLog(PublicationComposerValidationDto publicationDto) throws InterruptedException {
        Thread.sleep(10000);

        DagRun publicationDag = publicationDto.getDagRun();
        Reporter.info(LOG, "Retrieving and validating Publication composer metadata logs ...");

        // Find ingestion composer metadata logs
        CloudLoggingService.Filter filter = new CloudLoggingService.Filter()
                .addCondition("logName", "=", TestContext.replaceTemplateEnv("projects/lt-dia-lake-${ENV}-techcompute/logs/observability_logs_info"))
                .and()
                .addCondition("jsonPayload.cc_dag_nm", "=", publicationDag.getDagId())
                .and()
                .addCondition("jsonPayload.cc_dag_run_id", "=~", CerebroPatterns.escapeRegExp(publicationDag.getDagRunId()));

        List<LogEntry> composerLogs = CloudLoggingService.getLogs(filter, 2);
        Assertions.assertThat(composerLogs.size())
                .as("Number of Publication composer metadata logs")
                .isEqualTo(1);
        Reporter.pass(LOG, "Only 1 Publication composer metadata log was found");

        // Conversion
        LogEntry logEntry = composerLogs.get(0);
        Payload.JsonPayload jsonPayload = logEntry.getPayload();

        Reporter.info(LOG, "Publication composer metadata log: {}", jsonPayload.getDataAsMap());
        PublicationComposerMetadataLog metadataLog = JsonUtils.readMapToObject(jsonPayload.getDataAsMap(), PublicationComposerMetadataLog.class);

        // Validations
        SoftAssertions metadataAssertions = new SoftAssertions();

        // --------------------- Log Details ---------------------
        // severity
        metadataAssertions.assertThat(logEntry.getSeverity())
                .as("severity")
                .isEqualTo(Severity.INFO);

        // resource.type
        metadataAssertions.assertThat(logEntry.getResource().getType())
                .as("resource.type")
                .isEqualTo("cloud_composer_environment");

        // --------------------- JSON Payload ---------------------
        // job_run_trace_id
        metadataAssertions.assertThat(metadataLog.getTraceIds())
                .as("jsonPayload.job_run_trace_id")
                .containsExactly(publicationDto.getJobRunTraceId());

        // zone
        metadataAssertions.assertThat(metadataLog.getZone())
                .as("jsonPayload.zone")
                .isEqualTo("publication");

        // cc_serv_acct_id
        metadataAssertions.assertThat(metadataLog.getServiceAccount())
                .as("jsonPayload.cc_serv_acct_id")
                .isEqualTo(TestContext.replaceTemplateEnv("sa-cerebro-${ENV}-tec-dfcontrol@lt-dia-lake-${ENV}-techcompute.iam.gserviceaccount.com"));

        // cc_dag_nm
        metadataAssertions.assertThat(metadataLog.getDagName())
                .as("jsonPayload.cc_dag_nm")
                .isEqualTo(publicationDag.getDagId());

        // cc_dag_run_id
        metadataAssertions.assertThat(metadataLog.getDagRunId())
                .as("jsonPayload.cc_dag_run_id")
                .contains(publicationDag.getDagRunId());

        // cc_dag_execution_strt_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionStartTime())
                .as("jsonPayload.cc_dag_execution_strt_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_execution_end_tms
        metadataAssertions.assertThat(metadataLog.getDagExecutionEndTime())
                .as("jsonPayload.cc_dag_execution_end_tms")
                .matches(CerebroPatterns.METADATA_LOG_TIMESTAMP);

        // cc_dag_elpsed_tms
        metadataAssertions.assertThat(metadataLog.getDagElapsedTime())
                .as("jsonPayload.cc_dag_elpsed_tms")
                .isNotEmpty();

        // cc_execution_rslt
        metadataAssertions.assertThat(metadataLog.getDagExecutionResult())
                .as("jsonPayload.cc_execution_rslt")
                .isEqualTo("Pass");

        // cc_tbl_rec_cre_tms
        String publicationRecCreTms = publicationDto.getRecCreTms();
        if (publicationRecCreTms.endsWith("000")) publicationRecCreTms = publicationRecCreTms.substring(0, publicationRecCreTms.length() - 3);
        metadataAssertions.assertThat(metadataLog.getTableRecordCreateTimestamp())
                .as("jsonPayload.cc_tbl_rec_cre_tms")
                .isEqualTo(publicationRecCreTms + " UTC");

        // cc_no_rows_loaded
        metadataAssertions.assertThat(metadataLog.getNumberRowsLoaded())
                .as("jsonPayload.cc_no_rows_loaded")
                .isEqualTo(String.valueOf(publicationDto.getTableStats().values().stream().mapToLong(TotalStats::getInsertedCount).sum()));

        // cc_src_nm
        metadataAssertions.assertThat(metadataLog.getSourceName())
                .as("jsonPayload.cc_src_nm")
                .isEqualTo(publicationDto.getSourceName());

        // cc_tgt_nm
        metadataAssertions.assertThat(metadataLog.getTargetNames())
                .as("jsonPayload.cc_tgt_nm")
                .contains(publicationDto.getTargetNames());

        metadataAssertions.assertAll();
    }

    private static String convertToMetadataTimestamp(String taskInstanceTimestamp) {
        return taskInstanceTimestamp.replace("T", " ").replace("+00:00", " UTC");
    }

    private static <T> List<T> convertCloudLoggingJsonPayloads(List<LogEntry> cloudLogs, Class<T> jsonClass, Comparator<T> comparator) {
        return cloudLogs.stream()
                .map(logEntry -> (Payload.JsonPayload) logEntry.getPayload())
                .map(jsonPayload ->  JsonUtils.readMapToObject(jsonPayload.getDataAsMap(), jsonClass))
                .sorted(comparator)
                .collect(Collectors.toList());
    }
}
