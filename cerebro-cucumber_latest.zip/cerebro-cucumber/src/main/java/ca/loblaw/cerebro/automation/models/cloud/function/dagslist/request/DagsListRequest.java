package ca.loblaw.cerebro.automation.models.cloud.function.dagslist.request;

import ca.loblaw.cerebro.automation.models.cloud.function.FunctionRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DagsListRequest implements FunctionRequest {

    @JsonProperty("filter")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private DagsListRequestFilter dagsListRequestFilter;

    public DagsListRequest(DagsListRequestFilter dagsListRequestFilter) {
        this.dagsListRequestFilter = dagsListRequestFilter;
    }

    public DagsListRequestFilter getDagsListRequestFilter() {
        return dagsListRequestFilter;
    }
}
