package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

import java.util.*;

public class TaskInstance {
    private final String taskId;
    private TaskInstanceState state;
    private String startDate;
    private String endDate;
    private int maxTries;
    private int tryNumber;
    private String taskLogs;
    private Map<String, Object> keywordArguments; // op_kwargs
    private Set<String> xcomVariables; // Available XCOM variables
    private Map<String, String> xcomEntries; // XCOM entries

    public TaskInstance(String taskId, TaskInstanceState state, String startDate, String endDate,
                        int maxTries, int tryNumber, Map<String, Object> keywordArguments) {
        this.taskId = taskId;
        this.state = state;
        this.startDate = startDate;
        this.endDate = endDate;
        this.maxTries = maxTries;
        this.tryNumber = tryNumber;
        this.keywordArguments = keywordArguments;
    }

    public boolean hasKeyword(String keyword) {
        return keywordArguments.containsKey(keyword);
    }

    public Object getArgument(String keyword) {
        return keywordArguments.get(keyword);
    }

    public String getStringArgument(String keyword) {
        return (String) keywordArguments.get(keyword);
    }

    public boolean isPassing() {
        return state == TaskInstanceState.SUCCESS || state == TaskInstanceState.SKIPPED;
    }

    public boolean isFinished() {
        return TaskInstanceState.FINISHED_STATES.contains(state);
    }

    public void createXcomVariables(List<String> xcomKeys) {
        xcomVariables = new HashSet<>();
        xcomVariables.addAll(xcomKeys);
    }

    public boolean hasXcomVariable(String xcomKey) {
        return xcomVariables.contains(xcomKey);
    }

    public void addXcomEntry(String xcomKey, String xcomValue) {
        if (xcomEntries == null) {
            xcomEntries = new HashMap<>();
        }
        xcomEntries.put(xcomKey, xcomValue);
    }

    public boolean hasXcomEntry(String xcomKey) {
        return xcomEntries.containsKey(xcomKey);
    }

    public String getXcomEntry(String xcomKey) {
        return xcomEntries.get(xcomKey);
    }

    // Getters and Setters
    public String getTaskId() {
        return taskId;
    }

    public TaskInstanceState getState() {
        return state;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setState(TaskInstanceState state) {
        this.state = state;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public int getMaxTries() {
        return maxTries;
    }

    public void setMaxTries(int maxTries) {
        this.maxTries = maxTries;
    }

    public int getTryNumber() {
        return tryNumber;
    }

    public void setTryNumber(int tryNumber) {
        this.tryNumber = tryNumber;
    }

    public String getTaskLogs() {
        return taskLogs;
    }

    public void setTaskLogs(String taskLogs) {
        this.taskLogs = taskLogs;
    }

    public Map<String, Object> getKeywordArguments() {
        return keywordArguments;
    }

    public void setKeywordArguments(Map<String, Object> keywordArguments) {
        this.keywordArguments = keywordArguments;
    }

    @Override
    public String toString() {
        return "TaskInstance {" +
                "taskId = " + taskId + ", " +
                "state = " + state + ", " +
                "startDate = " + startDate +
                '}';
    }
}
