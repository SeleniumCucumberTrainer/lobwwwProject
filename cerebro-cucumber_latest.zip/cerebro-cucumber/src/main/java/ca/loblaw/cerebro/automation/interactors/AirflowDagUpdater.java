package ca.loblaw.cerebro.automation.interactors;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagType;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.exceptions.AirflowException;
import ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers.*;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.request.AirflowRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.request.AirflowRequestItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.request.AirflowRequestType;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponse;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseError;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Test step class to interact with Airflow Cloud Function to update a DAG.
 */
public class AirflowDagUpdater implements Interactor {

    private static final Logger LOG = LogManager.getLogger(AirflowDagUpdater.class);

    private final AirflowFunction airflowFunction; // Airflow API Cloud Function to call
    private DagRun dagRun; // DAG to use for Airflow API interactions

    public AirflowDagUpdater(AirflowFunction airflowFunction) {
        this.airflowFunction = airflowFunction;
    }

    public static void connectUpstreamAndDownstreamDag(DagRun upstreamDag, DagRun downstreamDag) {
        boolean connect = true;

        // Check if downstream DAG is actually triggered by upstream DAG
        if (downstreamDag.getDagType() == DagType.PUBLICATION) {
            if (!upstreamDag.hasTask("trigger_publication") && !upstreamDag.hasTask("trigger_" + downstreamDag.getDagId())) {
                connect = false;
            }
        } else {
            if (!upstreamDag.hasTask("trigger_" + downstreamDag.getDagId())) {
                connect = false;
            }
        }

        // Add connect both if not already connected
        if (connect) {
            if (!upstreamDag.getDownstreamDags().contains(downstreamDag)) {
                upstreamDag.addDownstreamDag(downstreamDag);
                downstreamDag.setUpstreamDag(upstreamDag);
            }
        } else {
            String message = String.format("Could not connect upstream DAG %s and downstream DAG %s", upstreamDag.getDagId(), downstreamDag.getDagId());
            throw new AirflowException(message);
        }
    }

    /**
     * Sends an Airflow request to retrieve DAG info.
     *
     * URL: api/v1/dags/{dag_id}
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void checkDagInfo() throws IOException {
        if (dagRun.hasNoError()) {
            // Request
            AirflowRequest airflowRequest = new AirflowRequest(
                    new AirflowRequestItem(dagRun.getDagId()),
                    AirflowRequestType.INFO);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new DagInfoHandler());

            LOG.info("Checked info for DAG {}", dagRun.getDagId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to check DAG info");
        }
    }

    /**
     * Sends an Airflow request to trigger DAG run.
     *
     * URL: api/v1/dags/{dag_id}/dagRuns
     * Method: POST
     * @throws IOException Error reading response JSON.
     */
    public void triggerDag() throws IOException {
        if (dagRun.hasNoError() && !dagRun.isPaused()) {
            // Request
            AirflowRequest airflowRequest = new AirflowRequest(
                    new AirflowRequestItem(dagRun.getDagId()),
                    AirflowRequestType.TRIGGER);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new TriggerDagHandler());

            Reporter.info(LOG, "Triggered DAG {}", dagRun.getDagId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to trigger");
        }
    }

    /**
     * Sends an Airflow request to retrieve DAG run info.
     *
     * URL: api/v1/dags/{dag_id}/dagRuns/{dag_run_id}
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void checkRunInfo() throws IOException {
        if (dagRun.hasNoError() && dagRun.hasRunId()) {
            // Request
            AirflowRequestItem airflowRequestItem = new AirflowRequestItem(dagRun.getDagId());
            airflowRequestItem.setDagRunId(dagRun.getDagRunId());

            AirflowRequest airflowRequest = new AirflowRequest(airflowRequestItem, AirflowRequestType.INFO);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new RunInfoHandler());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to check run info");
        }
    }

    /**
     * Sends an Airflow request to retrieve DAG tasks.
     *
     * URL: api/v1/dags/{dag_id}/tasks
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void listTasks() throws IOException {
        if (dagRun.hasNoError()) {
            // Request
            AirflowRequest airflowRequest = new AirflowRequest(
                    new AirflowRequestItem(dagRun.getDagId()),
                    AirflowRequestType.LIST_TASKS);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new TaskListHandler());

            LOG.info("Listed tasks for DAG {}", dagRun.getDagId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to list DAG tasks");
        }
    }

    public List<DagRun> createAndLinkDownstreamDags() {
        List<DagRun> newDownstreamDags = new ArrayList<>();

        for (String taskId : dagRun.getTasks()) {
            if (taskId.contains("trigger_dg")) {
                // Connect upstream and downstream DAGs
                String downstreamDagId = taskId.replaceFirst("trigger_", "");
                DagRun downstreamDag = new DagRun(downstreamDagId, dagRun.getProject());
                downstreamDag.setUpstreamDag(dagRun);

                dagRun.addDownstreamDag(downstreamDag);

                newDownstreamDags.add(downstreamDag);
            } else if (taskId.contains("trigger_publication")) {
                // Connect upstream and downstream DAGs
                String downstreamDagId = dagRun.getDagId().replaceFirst("curation", "publication");
                DagRun downstreamDag = new DagRun(downstreamDagId, dagRun.getProject());
                downstreamDag.setUpstreamDag(dagRun);

                dagRun.addDownstreamDag(downstreamDag);

                newDownstreamDags.add(downstreamDag);
            }
        }

        LOG.info("Linked all DAG flows for {}", dagRun.getDagId());

        return newDownstreamDags;
    }

    /**
     * Sends an Airflow request to retrieve DAG most recent run.
     *
     * URL: api/v1/dags/{dag_id}/dagRuns?limit=1&order_by=-end_date&state=success,failed
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void findMostRecentRun() throws IOException {
        if (dagRun.hasNoError() && !dagRun.hasRunId() && !dagRun.hasUpstreamDag()) {
            // Request
            AirflowRequest airflowRequest = new AirflowRequest(
                    new AirflowRequestItem(dagRun.getDagId()),
                    AirflowRequestType.RECENT);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new RecentRunHandler());

            LOG.info("Attempted to retrieve most recent run for DAG {}", dagRun.getDagId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to find most recent run");
        }
    }

    /**
     * Sends an Airflow request to retrieve DAG run task instances.
     *
     * URL: api/v1/dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void getTaskInstances() throws IOException {
        if (dagRun.hasNoError() && dagRun.hasRunId()) {
            // Request
            AirflowRequestItem airflowRequestItem = new AirflowRequestItem(dagRun.getDagId());
            airflowRequestItem.setDagRunId(dagRun.getDagRunId());

            AirflowRequest airflowRequest = new AirflowRequest(airflowRequestItem, AirflowRequestType.TASK_INSTANCES);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new TaskInstancesHandler());

            LOG.info("Found task instances for DAG {} with run ID {}", dagRun.getDagId(), dagRun.getDagRunId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to get run task instances");
        }
    }

    /**
     * Sends an Airflow request to find each valid downstream DAG run closest to their respective parent DAG
     * trigger task start date.
     *
     * URL: api/v1/dags/{dag_id}/dagRuns?limit=1&order_by=execution_date&execution_date_gte={start_date}
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void findRunAssociatedWithUpstreamDag() throws IOException {
        if (dagRun.hasNoError() && dagRun.isValidDownstreamDagToBeFound()) {
            // Request
            String upstreamTriggerTaskId = dagRun.getUpstreamDag().hasTaskInstance("trigger_" + dagRun.getDagId())
                    ? "trigger_" + dagRun.getDagId() : "trigger_publication";
            TaskInstance upstreamTriggerTask = dagRun.getUpstreamDag().getTaskInstance(upstreamTriggerTaskId);

            AirflowRequestItem airflowRequestItem = new AirflowRequestItem(dagRun.getDagId());
            airflowRequestItem.addExtra("start_date", upstreamTriggerTask.getStartDate().replace("+00:00", "Z"));

            AirflowRequest airflowRequest = new AirflowRequest(airflowRequestItem, AirflowRequestType.START_DATE);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Update
            handleResponseAndUpdateDag(airflowResponse, new ClosestDateRunHandler());

            LOG.info("Attempted to retrieve associated triggered run for DAG {} from upstream DAG {}",
                    dagRun.getDagId(), dagRun.getUpstreamDag().getDagId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() +
                    " does not meet prerequisites to find run associated with upstream DAG");
        }
    }


    /**
     * Sends an Airflow request to retrieve DAG run task instance info.
     *
     * URL: api/v1/dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances/{task_id}
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void checkTaskInstanceInfo(String taskId) throws IOException {
        if (dagRun.hasNoError() && dagRun.hasRunId() && dagRun.getTasks().contains(taskId)) {
            // Request
            AirflowRequestItem airflowRequestItem = new AirflowRequestItem(dagRun.getDagId());
            airflowRequestItem.setDagRunId(dagRun.getDagRunId());
            airflowRequestItem.setTaskId(taskId);

            AirflowRequest airflowRequest = new AirflowRequest(airflowRequestItem, AirflowRequestType.INFO);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Handle
            handleResponseAndUpdateDag(airflowResponse, new TaskInstanceInfoHandler());

            LOG.debug("Checked '{}' task instance information for DAG {} with run ID {}",
                    taskId, dagRun.getDagId(), dagRun.getDagRunId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to check task instance info");
        }
    }

    /**
     * Sends an Airflow request to retrieve list of XCOm variables from a task instance
     *
     * URL: api/v1/dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances/{task_id}/xcomEntries
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void retrieveXcomVariables(String taskId) throws IOException {
        if (dagRun.hasNoError() && dagRun.hasRunId() && dagRun.getTaskInstance(taskId).isFinished()) {
            // Request
            AirflowRequestItem airflowRequestItem = new AirflowRequestItem(dagRun.getDagId());
            airflowRequestItem.setDagRunId(dagRun.getDagRunId());
            airflowRequestItem.setTaskId(taskId);

            AirflowRequest airflowRequest = new AirflowRequest(airflowRequestItem, AirflowRequestType.XCOM_LIST);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Handle
            handleResponseAndUpdateDag(airflowResponse, new XcomListHandler());

            LOG.info("Retrieved XCOM variables for task {} in DAG {} with run ID {}",
                    taskId, dagRun.getDagId(), dagRun.getDagRunId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to retrieve XCOM variables");
        }
    }

    /**
     * Sends an Airflow request to retrieve an XCOM value from a task instance
     *
     * URL: api/v1/dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances/{task_id}/xcomEntries
     * Method: GET
     * @throws IOException Error reading response JSON.
     */
    public void retrieveXcomValue(String taskId, String xcomKey) throws IOException {
        if (dagRun.hasNoError() && dagRun.hasRunId() && dagRun.getTaskInstance(taskId).hasXcomVariable(xcomKey)) {
            // Request
            AirflowRequestItem airflowRequestItem = new AirflowRequestItem(dagRun.getDagId());
            airflowRequestItem.setDagRunId(dagRun.getDagRunId());
            airflowRequestItem.setTaskId(taskId);
            airflowRequestItem.addExtra("xcom_key", xcomKey);

            AirflowRequest airflowRequest = new AirflowRequest(airflowRequestItem, AirflowRequestType.XCOM);

            // Send
            AirflowResponse airflowResponse = airflowFunction.execute(airflowRequest);

            // Handle
            handleResponseAndUpdateDag(airflowResponse, new XcomValueHandler());

            LOG.info("Retrieved XCOM value for XCOM key {} in task {} for DAG {} with run ID {}",
                    xcomKey, taskId, dagRun.getDagId(), dagRun.getDagRunId());
        } else {
            throw new AirflowException("DAG " + dagRun.getDagId() + " does not meet prerequisites to retrieve XCOM value");
        }
    }

    private void handleResponseAndUpdateDag(AirflowResponse airflowResponse, AirflowUpdateHandler airflowUpdateHandler) {
        AirflowResponseItem airflowResponseItem = airflowResponse.getResponseItem();

        // Handle error response
        if (airflowResponseItem instanceof AirflowResponseError) {
            AirflowResponseError responseError = (AirflowResponseError) airflowResponseItem;
            dagRun.setError(responseError.getError().getTitle());
        }
        // Handle valid response
        else {
            airflowUpdateHandler.handleResponse(airflowResponseItem, dagRun);
        }
    }

    public void setDagRun(DagRun dagRun) {
        this.dagRun = dagRun;
    }
}
