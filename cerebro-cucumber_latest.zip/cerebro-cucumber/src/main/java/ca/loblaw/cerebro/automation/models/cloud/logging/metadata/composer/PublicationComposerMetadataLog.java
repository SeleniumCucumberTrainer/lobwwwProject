package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class PublicationComposerMetadataLog extends ComposerMetadataLog {

    @JsonProperty("cc_src_nm")
    private String sourceName;
    @JsonProperty("cc_tgt_nm")
    private List<String> targetNames;
    @JsonProperty("cc_no_rows_loaded")
    private String numberRowsLoaded;
    @JsonProperty("cc_multiple_statement_rows_loaded")
    private String multipleStatementRowsLoaded;

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public List<String> getTargetNames() {
        return targetNames;
    }

    public void setTargetNames(List<String> targetNames) {
        this.targetNames = targetNames;
    }

    public String getNumberRowsLoaded() {
        return numberRowsLoaded;
    }

    public void setNumberRowsLoaded(String numberRowsLoaded) {
        this.numberRowsLoaded = numberRowsLoaded;
    }

    public String getMultipleStatementRowsLoaded() {
        return multipleStatementRowsLoaded;
    }

    public void setMultipleStatementRowsLoaded(String multipleStatementRowsLoaded) {
        this.multipleStatementRowsLoaded = multipleStatementRowsLoaded;
    }
}
