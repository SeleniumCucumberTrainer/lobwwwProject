package ca.loblaw.cerebro.automation.utils.cloud.storage;

import com.google.cloud.storage.Storage;

import java.util.ArrayList;
import java.util.List;

/**
 * Builder class for determining which blob fields will be included when
 * retrieving blobs using CloudStorageUtils.
 */
public class CloudStorageFileFieldOptions {

    private boolean includeName;

    private boolean includeSize;

    private boolean includeCreateDate;

    private boolean includeMetadata;

    public CloudStorageFileFieldOptions includeName() {
        this.includeName = true;
        return this;
    }

    public CloudStorageFileFieldOptions includeSize() {
        this.includeSize = true;
        return this;
    }

    public CloudStorageFileFieldOptions includeCreateDate() {
        this.includeCreateDate = true;
        return this;
    }

    public CloudStorageFileFieldOptions includeMetadata() {
        this.includeMetadata = true;
        return this;
    }

    public Storage.BlobField[] build() {
        List<Storage.BlobField> blobFieldsList = new ArrayList<>();

        if(this.includeSize) {
            blobFieldsList.add(Storage.BlobField.NAME);
        }

        if(this.includeCreateDate) {
            blobFieldsList.add(Storage.BlobField.TIME_CREATED);
        }

        if(this.includeSize) {
            blobFieldsList.add(Storage.BlobField.SIZE);
        }

        if(this.includeMetadata) {
            blobFieldsList.add(Storage.BlobField.METADATA);
        }

        return blobFieldsList.toArray(new Storage.BlobField[blobFieldsList.size()]);
    }
}
