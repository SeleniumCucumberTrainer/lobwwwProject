package ca.loblaw.cerebro.automation.utils.internal;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Utility class for handling local files in on the OS filesystem.
 */
public class LocalFileUtils {

    private LocalFileUtils() {}

    /**
     * Deletes a local file.
     *
     * @param localFilePath Path of local file to delete.
     * @throws IOException Error deleting local file.
     */
    public static void deleteFile(String localFilePath) throws IOException {
        Files.delete(Paths.get(localFilePath));
    }

    /**
     * Creates an empty local file.
     *
     * @param localFilePath Path of new empty file.
     * @throws IOException Error creating empty file.
     */
    public static void createEmptyFile(String localFilePath) throws IOException {
        Files.createFile(Paths.get(localFilePath));
    }

    /**
     * Checks if a local file exists.
     *
     * @param localFilePath Path of local file.
     * @return Whether local file exists.
     */
    public static boolean checkFileExists(String localFilePath) {
        File file = new File(localFilePath);
        return file.exists();
    }

    /**
     * Reads local file contents to String.
     *
     * @param localFilePath Path of local file.
     * @return Contents of file as String.
     * @throws IOException Error reading file.
     */
    public static String readFileToString(String localFilePath) throws IOException {
        return FileUtils.readFileToString(new File(localFilePath), StandardCharsets.UTF_8);
    }
}
