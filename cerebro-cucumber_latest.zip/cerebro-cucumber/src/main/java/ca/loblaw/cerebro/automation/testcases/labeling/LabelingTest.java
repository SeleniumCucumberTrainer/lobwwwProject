package ca.loblaw.cerebro.automation.testcases.labeling;

import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.cloud.datastore.DatastoreService;
import ca.loblaw.cerebro.automation.utils.internal.CerebroPatterns;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.FullEntity;
import com.google.cloud.datastore.Key;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Set;

@Test(groups = { "labeling", "smoke" })
public class LabelingTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(LabelingTest.class);
    private static final String NAMESPACE = "cerebro_master";
    private static final String KIND = "label";
    private static final int MAX_LABELS = 64;
    private static final int MAX_KEY_LENGTH = 63;
    private static final int MIN_KEY_LENGTH = 1;
    private static final int MAX_VALUE_LENGTH = 63;
    private static final int MIN_VALUE_LENGTH = 0;


    private List<Entity> labelEntities;

    @BeforeClass
    public void labeling_setup() {
        labelEntities = new DatastoreService.QueryBuilder()
                .newBuilder()
                .setNamespace(NAMESPACE)
                .setKind(KIND)
                .queryToList();

        Reporter.info(LOG, "Number of Datastore label entities: {}", labelEntities.size());
    }

    /**
     * Label requirements
     * - Maximum of 64 labels.
     * - Label key and values must be Strings.
     * - Keys have min length of 1 and max length of 63. Values have min length of 0 and max length of 63.
     * - Keys and values must start with a lowercase letter.
     * - Keys and values must only contain lowercase letters, numbers, underscores, and dashes.
     */
    @Test(description = "Validate Datastore Labels")
    public void validate_datastore_labels() {
        for (Entity labelEntity : labelEntities) {
            String dagId = labelEntity.getString("dag_id");
            FullEntity<Key> labelsValueEntity = labelEntity.getEntity("labels");
            Set<String> labelKeys = labelsValueEntity.getNames();

            Reporter.info(LOG, "Checking labels for DAG {}", dagId);

            Assertions.assertThat(labelKeys.size())
                    .as("DAG %s number of labels")
                    .isLessThanOrEqualTo(MAX_LABELS);

            for (String labelKey : labelKeys) {
                String labelValue = labelsValueEntity.getString(labelKey);

                // Key validations
                Assertions.assertThat(!labelKey.isEmpty() && labelKey.length() <= MAX_KEY_LENGTH)
                        .as("DAG %s labels key %s between %d and %d length",
                                dagId, labelKey, MIN_KEY_LENGTH, MAX_KEY_LENGTH)
                        .isTrue();

                Assertions.assertThat(labelKey)
                        .as("DAG %s labels key %s matches requirements pattern",
                                dagId, labelKey)
                        .matches(CerebroPatterns.LABELING);

                // Value validations
                Assertions.assertThat(labelKey.length() <= MAX_VALUE_LENGTH)
                        .as("DAG %s labels key %s value %s between %d and %d length",
                                dagId, labelKey, labelValue, MIN_VALUE_LENGTH, MAX_KEY_LENGTH)
                        .isTrue();

                Assertions.assertThat(labelKey)
                        .as("DAG %s labels key %s value %s matches requirements pattern",
                                dagId, labelKey, labelValue)
                        .matches(CerebroPatterns.LABELING);
            }
        }

        Reporter.pass(LOG, "All labels in Datastore are valid");
    }
}
