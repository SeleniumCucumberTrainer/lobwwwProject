package ca.loblaw.cerebro.automation.helpers.querybuilder;

public interface Query {

    String build();
}
