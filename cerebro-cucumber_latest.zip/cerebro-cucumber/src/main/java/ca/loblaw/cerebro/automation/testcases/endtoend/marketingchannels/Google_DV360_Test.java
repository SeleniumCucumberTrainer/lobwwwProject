package ca.loblaw.cerebro.automation.testcases.endtoend.marketingchannels;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "google-dv360", "marketingchannels" })
public class Google_DV360_Test extends EndToEndTest {
    public Google_DV360_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/marketingchannels/google_dv360.properties");
    }
}