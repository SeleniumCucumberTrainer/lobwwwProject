package ca.loblaw.cerebro.automation.steps.filerouting;

import ca.loblaw.cerebro.automation.models.data.RawFolders;
import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.CerebroPatterns;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.SoftAssertions;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Validator class to validate file routing results.
 */
public class FileRoutingValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(FileRoutingValidator.class);

    public FileRoutingValidator() {
        super();
    }

    public static void validateTestFilesMovedToStageFolder(List<String> rawFileNames, RawFolders rawFolders, String stage) {
        String rawFolder = rawFolders.getFolderFromStage(stage);

        // Check all raw files in stage folder
        validateAllRawFilesInFolder(rawFileNames, rawFolder);
        Reporter.pass("Given test files are all found in '{}' folder", stage);

        // Check all raw files are not in other folders
        if (!stage.equals("landing")) {
            validateAllRawFilesNotInStage(rawFileNames, rawFolders.getLanding());
            Reporter.pass("None of given test files are found in 'landing' folder");
        }

        if (!stage.equals("working")) {
            validateAllRawFilesNotInStage(rawFileNames, rawFolders.getWorking());
            Reporter.pass("None of given test files are found in 'working' folder");
        }

        if (!stage.equals("processed")) {
            validateAllRawFilesNotInStage(rawFileNames, rawFolders.getProcessed());
            Reporter.pass("None of given test files are found in 'processed' folder");
        }

        if (!stage.equals("rejected")) {
            validateAllRawFilesNotInStage(rawFileNames, rawFolders.getRejected());
            Reporter.pass("None of given test files are found in 'rejected' folder");
        }
    }

    private static void validateAllRawFilesInFolder(List<String> rawFileNames, String rawFolder) {
        List<String> rawFilePaths = rawFileNames.stream()
                .map(rawFileName -> rawFolder + rawFileName)
                .collect(Collectors.toList());

        SoftAssertions rawFilesPresentAssertions = new SoftAssertions();
        for (String rawFilePath : rawFilePaths) {
            rawFilesPresentAssertions.assertThat(CloudStorageUtils.doesFileExist(rawFilePath))
                    .as("Does %s exist", rawFilePath)
                    .isTrue();
        }
        rawFilesPresentAssertions.assertAll();
    }

    private static void validateAllRawFilesNotInStage(List<String> rawFileNames, String rawFolder) {
        List<String> rawFilePaths = rawFileNames.stream()
                .map(rawFileName -> rawFolder + rawFileName)
                .collect(Collectors.toList());

        SoftAssertions rawFilesNotPresentAssertions = new SoftAssertions();
        for (String rawFilePath : rawFilePaths) {
            rawFilesNotPresentAssertions.assertThat(CloudStorageUtils.doesFileExist(rawFilePath))
                    .as("Does %s exist", rawFilePath)
                    .isFalse();
        }
        rawFilesNotPresentAssertions.assertAll();
    }

    /**
     * Compares each landing file and raw file from {@code landingCloudFiles} and {@code rawCloudFiles}.
     * It is expected that landing files list size is greater than raw files list size, and both lists are sorted
     * by file name asecnding.
     *
     * Validations include
     *      - Raw file is present
     *      - UUID value has correct format
     *      - Same UUID value in blob metadata
     *
     * @param landingCloudFiles List of landing files
     * @param rawCloudFiles List of raw files.
     */
    public static void validateLandingAndRawCloudFiles(List<CloudStorageFile> landingCloudFiles, List<CloudStorageFile> rawCloudFiles, String... stages) {
        SoftAssertions fileRoutedAssertions = new SoftAssertions();
        SoftAssertions fileDetailsAssertions = new SoftAssertions();

        String uuidKey = "uuid-" + TestContext.ENV;

        int rawFileIndex = 0;

        for (int cloudIndex = 0; cloudIndex < landingCloudFiles.size(); cloudIndex++) {
            CloudStorageFile landingFile = landingCloudFiles.get(cloudIndex);
            CloudStorageFile rawFile = rawCloudFiles.get(rawFileIndex);

            String landingFileName = landingFile.getName();
            String rawFileName = rawFile.getName();

            if (!FilenameUtils.getName(landingFileName).equals(FilenameUtils.getName(rawFileName))) {
                fileRoutedAssertions.fail("No raw file found for landing file %s", landingFileName);
                continue;
            }

            // Validate UUID for non-dfm files
            if (!landingFile.getName().endsWith(".dfm")) {
                fileDetailsAssertions.assertThat(landingFile.getMetadata().containsKey(uuidKey))
                        .as("Check landing file '%s' has UUID present", landingFileName)
                        .isTrue();
                fileDetailsAssertions.assertThat(rawFile.getMetadata().containsKey(uuidKey))
                        .as("Check raw file '%s' has UUID present", rawFileName)
                        .isTrue();

                if (landingFile.getMetadata().containsKey(uuidKey) && rawFile.getMetadata().containsKey(uuidKey)) {
                    String landingFileUuid = landingFile.getMetadata().get(uuidKey);
                    String rawFileUuid = rawFile.getMetadata().get(uuidKey);

                    fileDetailsAssertions.assertThat(landingFileUuid)
                            .as("Check landing file '%s' UUID pattern", landingFileName)
                            .matches(CerebroPatterns.UUID);
                    fileDetailsAssertions.assertThat(rawFileUuid)
                            .as("Check raw file '%s' UUID pattern", rawFileName)
                            .matches(CerebroPatterns.UUID);
                    fileDetailsAssertions.assertThat(landingFileUuid)
                            .as("Compare landing file '%s' and raw file '%s' UUID", landingFileName, rawFileName)
                            .isEqualTo(rawFileUuid);
                }
            }

            rawFileIndex++;
        }

        fileRoutedAssertions.assertAll();
        String printStages = String.join(",", stages);
        Reporter.pass(LOG, "All landing files were found in raw bucket ({})", printStages);

        fileDetailsAssertions.assertAll();
        Reporter.pass(LOG, "All landing and raw files have correct UUIDs");
    }
}
