package ca.loblaw.cerebro.automation.testcases.endtoend.product;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "sap-marm", "product" })
public class SAP_MARM_Test extends EndToEndTest {
    public SAP_MARM_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/product/sap_marm.properties");
    }
}
