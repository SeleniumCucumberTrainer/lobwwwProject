package ca.loblaw.cerebro.automation.testcases.endtoend.merchandising;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "revionics-spo", "merchandising" })
public class Revionics_SPO_Test extends EndToEndTest {
    public Revionics_SPO_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/merchandising/revionics_spo_cost.properties");
    }
}
