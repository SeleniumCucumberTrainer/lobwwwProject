package ca.loblaw.cerebro.automation.component;

import ca.loblaw.cerebro.automation.utils.contexts.Project;

public interface CloudComponent {
    ComponentType getComponentType();
    Project getProject();
}
