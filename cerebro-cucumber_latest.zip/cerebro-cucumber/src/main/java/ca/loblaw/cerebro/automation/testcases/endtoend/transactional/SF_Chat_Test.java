package ca.loblaw.cerebro.automation.testcases.endtoend.transactional;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "sf-chat", "transactional" })
public class SF_Chat_Test extends EndToEndTest {
    public SF_Chat_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/transactional/sf_chat.properties");
    }
}
