package ca.loblaw.cerebro.automation.testcases.endtoend.logistics;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;
@Test(groups = { "dc-serv-lvl", "logistics" })
public class DC_Serv_Lvl_Test extends EndToEndTest {
    public DC_Serv_Lvl_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/logistics/dc_serv_lvl.properties");
    }
}
