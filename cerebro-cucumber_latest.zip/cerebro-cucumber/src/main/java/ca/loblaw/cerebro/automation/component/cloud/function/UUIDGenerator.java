package ca.loblaw.cerebro.automation.component.cloud.function;

import ca.loblaw.cerebro.automation.models.cloud.function.uuid.request.GeneratorRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.uuid.response.GeneratorResponse;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunction;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunctionHttpResponse;
import ca.loblaw.cerebro.automation.utils.internal.JsonUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

/**
 * Representational class for the UUID Generator Cloud Function, which is used to generate an UUID and attach it to
 * a Cloud Storage blob.
 */
public class UUIDGenerator extends CloudFunctionComponent<GeneratorRequest, GeneratorResponse> {

    private static final Logger LOG = LogManager.getLogger(UUIDGenerator.class);
    private static final String propertiesFilePath = "src/main/resources/configs/components/UUIDGenerator.properties";

    public UUIDGenerator() throws IOException {
        super(new CloudFunction.Builder().fromPropertiesFile(propertiesFilePath).build());
    }

    @Override
    public GeneratorResponse execute(GeneratorRequest generatorRequest) throws IOException {
        // Request JSON string
        String requestJson = JsonUtils.writeObjectToString(generatorRequest);
        Reporter.info(LOG, "UUID Generator request JSON:\n{}", JsonUtils.prettyFormat(requestJson));

        // Trigger Cloud Function
        CloudFunctionHttpResponse cloudFunctionHttpResponse = getCloudFunction().trigger(requestJson);

        // Response JSON string
        String responseJson = cloudFunctionHttpResponse.getResponseString();
        Reporter.info(LOG, "UUID Generator response JSON:\n{}", JsonUtils.prettyFormat(responseJson));

        return JsonUtils.readStringToObject(responseJson, GeneratorResponse.class);
    }

    @Override
    public void validateRequestJson(JsonNode requestJsonNode) {

    }

    @Override
    public void validateResponseJson(JsonNode responseJsonNode) {

    }

}
