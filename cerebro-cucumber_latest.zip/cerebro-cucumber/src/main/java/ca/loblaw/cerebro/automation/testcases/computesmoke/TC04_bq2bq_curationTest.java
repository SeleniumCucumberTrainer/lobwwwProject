package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"bq2bq","TechComputeSmoke"})
public class TC04_bq2bq_curationTest extends TechComputeCommonFun{
    public TC04_bq2bq_curationTest() throws IOException {
        super("TC04_bq2bq_curationTestData.properties");
    }

}
