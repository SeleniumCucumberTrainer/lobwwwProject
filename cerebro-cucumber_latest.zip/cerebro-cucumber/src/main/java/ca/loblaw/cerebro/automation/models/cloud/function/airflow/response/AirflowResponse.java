package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import ca.loblaw.cerebro.automation.models.cloud.function.FunctionResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowResponse implements FunctionResponse {

    @JsonProperty("message")
    private AirflowResponseItem responseItem;

    public AirflowResponseItem getResponseItem() {
        return responseItem;
    }

    public void setResponseItem(AirflowResponseItem responseItem) {
        this.responseItem = responseItem;
    }
}
