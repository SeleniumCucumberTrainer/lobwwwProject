package ca.loblaw.cerebro.automation.testcases.endtoend.transactional;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "flipp-pia", "transactional" })
public class Flipp_PIA_Test extends EndToEndTest {
    public Flipp_PIA_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/transactional/flipp_pia.properties");
    }
}
