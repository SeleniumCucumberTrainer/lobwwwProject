package ca.loblaw.cerebro.automation.testcases.endtoend.logistics;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "sap-ekko", "logistics" })
public class SAP_EKKO_Test extends EndToEndTest {
    public SAP_EKKO_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/logistics/sap_ekko.properties");
    }
}
