package ca.loblaw.cerebro.automation.models.cloud.function.dagslist.response;

import ca.loblaw.cerebro.automation.models.cloud.function.FunctionResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class DagsListResponse implements FunctionResponse {

    @JsonProperty("dags_list")
    private List<String> dagsList;

    @JsonProperty("count")
    private Integer count;

    public List<String> getDagsList() {
        return dagsList;
    }

    public void setDagsList(List<String> dagsList) {
        this.dagsList = dagsList;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
