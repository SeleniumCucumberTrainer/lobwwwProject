package ca.loblaw.cerebro.automation.utils.contexts;

/**
 * Available Cerebro environments.
 */
public enum Environment {
    EXP("exp"),
    VAL("val");

    public static Environment from(String str) {
        for (Environment environment : Environment.values()) {
            if (environment.value.equals(str)) {
                return environment;
            }
        }
        throw new EnumConstantNotPresentException(Environment.class, str);
    }

    private final String value;

    Environment(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
