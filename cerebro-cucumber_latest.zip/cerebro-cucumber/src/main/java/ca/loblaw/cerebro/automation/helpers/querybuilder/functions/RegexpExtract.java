package ca.loblaw.cerebro.automation.helpers.querybuilder.functions;

import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;

public class RegexpExtract implements SQLFunction{
    private String template = "REGEXP_EXTRACT(${COLUMN}, '${REGEX}')";
    private String regex;
    public RegexpExtract(String regex){
        this.regex = regex;
    }

    @Override
    public String build(Column column) {

        return template.replace("${COLUMN}", column.getName())
                .replace("${REGEX}", regex);
    }
}
