package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"hanaAuditTLogUpdated","TechComputeSmoke"})
public class TC11_Hana_tlog_updated extends TechComputeCommonFun{
    public TC11_Hana_tlog_updated() throws IOException {
        super("TC11_Hana_tlog_updatedTestData.properties");
    }

}
