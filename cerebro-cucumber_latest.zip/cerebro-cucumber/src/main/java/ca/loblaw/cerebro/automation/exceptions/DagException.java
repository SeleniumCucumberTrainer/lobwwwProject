package ca.loblaw.cerebro.automation.exceptions;

public class DagException extends RuntimeException {

    public DagException(String message) {
        super(message);
    }

    public DagException(String message, Object... args) {
        super(String.format(message, args));
    }
}
