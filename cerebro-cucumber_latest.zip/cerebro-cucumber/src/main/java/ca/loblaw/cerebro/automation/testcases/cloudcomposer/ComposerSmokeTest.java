package ca.loblaw.cerebro.automation.testcases.cloudcomposer;

import ca.loblaw.cerebro.automation.annotations.Depends;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstanceState;
import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.interactors.AirflowDagUpdater;
import ca.loblaw.cerebro.automation.steps.cloudcomposer.AirflowDagValidator;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.fulfillment.FulfillmentSmokeTest;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.integration.IntegrationSmokeTest;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute.TechComputeSmokeTest;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.*;

import java.io.IOException;

@Test(groups = { "cloud-composer", "smoke" })
public abstract class ComposerSmokeTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(ComposerSmokeTest.class);

    // Test fields
    private final AirflowFunction airflowFunction;
    private final String sheetName;
    private final Project project;

    // Instance fields
    private final String dagId;
    private DagRun dagRun;

    // Steps
    private AirflowDagUpdater airflowDagUpdater;

    public static ComposerSmokeTest fromProject(Project project, String dagId, String sheetName) {
        switch (project) {
            case TECHCOMPUTE_ZONE:
                return new TechComputeSmokeTest(dagId, dagId, sheetName);
            case FULFILLMENT_ZONE:
                return new FulfillmentSmokeTest(dagId, dagId, sheetName);
            case INTEGRATION_ZONE:
                return new IntegrationSmokeTest(dagId, dagId, sheetName);
            default:
                throw new RuntimeException(String.format("Project %s not supported", project));
        }
    }

    public ComposerSmokeTest(String dataName, String dagId, String sheetName, Project project, AirflowFunction airflowFunction) {
        super(dataName);
        this.dagId = dagId;
        this.sheetName = sheetName;
        this.project = project;
        this.airflowFunction = airflowFunction;
    }

    @BeforeClass
    public void composer_smoke_setup() throws IOException {
        composerSetup();
        flagsSetup();
    }

    private void flagsSetup() {
        if (dagRun.hasFinishedRun()) {
            addPassFlag("finished_run_exists");

            if (dagRun.hasMetadataLogTaskId()
                    && !dagRun.isOutdated()
                    && dagRun.getTaskInstance("metadata_log").getState() == TaskInstanceState.SUCCESS) {
                addPassFlag("updated_metadata_log_exists");
            }
        }
    }

    private void composerSetup() throws IOException {
        airflowDagUpdater = new AirflowDagUpdater(airflowFunction);

        // DAG flow
        dagRun = new DagRun(dagId, project);
        airflowDagUpdater.setDagRun(dagRun);

        Reporter.info(LOG, "Getting DAG information {}", dagId);
        airflowDagUpdater.checkDagInfo();
        airflowDagUpdater.listTasks();

        Reporter.info(LOG, "Finding run information for starting DAG {}", dagId);
        airflowDagUpdater.findMostRecentRun();
        if (dagRun.hasRunId()) airflowDagUpdater.getTaskInstances();
    }

    @Test(priority = 1, description = "Validate DAG Run", groups = "dag-run")
    @Depends(flags = "finished_run_exists")
    public void validate_dag_runs() {
        AirflowDagValidator.validateDagRunInfo(dagRun);
        AirflowDagValidator.validateDagTaskInstances(dagRun);
    }

    @AfterClass(alwaysRun = true)
    public void composer_smoke_after_method() {
        ComposerSmokeFactory.getDagRunsQueue(getSheetName()).add(dagRun);
        LOG.info("Added DAG {} for Excel report", dagId);
        Reporter.info(dagRun.toFullString());
    }


    public String getSheetName() {
        return sheetName;
    }
}
