package ca.loblaw.cerebro.automation.models.cloud.function.airflow.request;

import ca.loblaw.cerebro.automation.models.cloud.function.FunctionRequest;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowRequest implements FunctionRequest {

    @JsonProperty("message")
    private AirflowRequestItem requestItem;

    @JsonProperty("request_type")
    private AirflowRequestType requestType;

    public AirflowRequest(AirflowRequestItem requestItem, AirflowRequestType requestType) {
        this.requestItem = requestItem;
        this.requestType = requestType;
    }

    public AirflowRequestItem getRequestItem() {
        return requestItem;
    }

    public AirflowRequestType getRequestType() {
        return requestType;
    }
}
