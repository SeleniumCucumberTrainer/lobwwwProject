package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"article_work","TechComputeSmoke"})
public class TC07_article_work extends TechComputeCommonFun{
    public TC07_article_work() throws IOException {
        super("TC07_article_workTestData.properties");
    }

}
