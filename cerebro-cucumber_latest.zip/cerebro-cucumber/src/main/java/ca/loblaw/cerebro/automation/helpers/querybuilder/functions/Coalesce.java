package ca.loblaw.cerebro.automation.helpers.querybuilder.functions;

import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;

public class Coalesce implements SQLFunction {
    private String replacement = "";
    private String template = "COALESCE(${COLUMN}, ${REPLACEMENT})";
    public Coalesce(){}
    public Coalesce(String replacementValue){
        this.replacement = replacementValue;
    }
    @Override
    public String build(Column column) {
        String functionResult = template;
        functionResult = functionResult.replace("${COLUMN}", column.getName());
        if(!replacement.isEmpty()){
            return functionResult.replace("${REPLACEMENT}", replacement);
        }

        switch (column.getDataType()){
            case "TIMESTAMP":
                replacement = "TIMESTAMP('0001-01-01 11:11:11')";
                break;
            case "STRING":
                replacement = "''";
            default:
                break;
        }

        return functionResult.replace("${REPLACEMENT}", replacement);
    }
}
