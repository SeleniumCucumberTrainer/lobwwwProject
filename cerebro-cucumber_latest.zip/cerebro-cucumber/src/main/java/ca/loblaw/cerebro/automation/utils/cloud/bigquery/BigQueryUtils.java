package ca.loblaw.cerebro.automation.utils.cloud.bigquery;

import ca.loblaw.cerebro.automation.exceptions.QueryException;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.bigquery.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BigQueryUtils {

    private static final Logger LOG = LogManager.getLogger(BigQueryUtils.class);
    private final static BigQuery BIGQUERY;

    static {
        try {
            BIGQUERY = BigQueryOptions.newBuilder()
                    .setCredentials(
                            ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS"))))
                    .build()
                    .getService();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private final static String[] UNITS = new String[]{"B", "KB", "MB", "GB", "TB"};
    private final static byte MAX_RETRY = 5;
    private final static long MAX_BYTES_PROCESSED = 50000000000L; // Around 50 GB

    private BigQueryUtils() {}

    public static TableResult executeQuery(String query) throws InterruptedException {
        LOG.info("Executing BQ query: {}", query);
        long estimatedBytesProcessed = performDryRun(query);

        if (estimatedBytesProcessed < MAX_BYTES_PROCESSED) {
            byte attempt = 0;
            while (attempt < MAX_RETRY) {
                try {
                    return BIGQUERY.query(QueryJobConfiguration.newBuilder(query).setJobTimeoutMs(180000L).build());
                } catch (BigQueryException e) {
                    if (e.getMessage() == null || e.getMessage().isEmpty()) {
                        attempt++;
                    } else {
                        throw e;
                    }
                }
            }
            throw new QueryException("Query not executed due to unknown errors. Retried up to " + MAX_RETRY + " times");
        } else {
            throw new QueryException("Query not executed due to costs. Please optimize the query.");
        }
    }

    private static long performDryRun(String query) {
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration.newBuilder(query)
                .setDryRun(true)
                .setUseQueryCache(false)
                .build();

        Job job = BIGQUERY.create(JobInfo.of(queryJobConfiguration));
        JobStatistics.QueryStatistics jobStatistics = job.getStatistics();

        long queryBytesProcessed = jobStatistics.getTotalBytesProcessed();

        LOG.info("Estimated query cost is " + formatCost(queryBytesProcessed));
        return queryBytesProcessed;
    }

    private static String formatCost(double totalBytesProcessed) {
        int unitIndex = 0;
        while (totalBytesProcessed >= 1000 && unitIndex < UNITS.length) {
            totalBytesProcessed /= 1000;
            unitIndex++;
        }

        return String.format("%.2f %s", totalBytesProcessed, UNITS[unitIndex]);
    }

    public static void copyEntireTableTo(String fromTable, String destinationTable) throws InterruptedException {
        String copyStatement = String.format(
                "CREATE OR REPLACE TABLE `%s` COPY `%s`",
                destinationTable,
                fromTable
        );
        executeQuery(copyStatement);
    }

    public static void copyTableMetadataTo(String fromTable, String destinationTable) throws InterruptedException {
        String likeStatement = String.format(
                "CREATE OR REPLACE TABLE `%s` LIKE `%s`",
                destinationTable,
                fromTable
        );
        executeQuery(likeStatement);
    }

    public static boolean deleteTable(String fullTableName) {
        String[] tableSplit = fullTableName.split("\\.");
        return deleteTable(tableSplit[0], tableSplit[1], tableSplit[2]);
    }

    public static boolean deleteTable(String project, String dataset, String tableName) {
        return BIGQUERY.delete(TableId.of(project, dataset, tableName));
    }

    public static Table getTable(String fullTableName) {
        String[] tableSplit = fullTableName.split("\\.");
        return getTable(tableSplit[0], tableSplit[1], tableSplit[2]);
    }

    public static Table getTable(String project, String dataset, String tableName) {
        return BIGQUERY.getTable(TableId.of(project, dataset, tableName));
    }

    public static boolean checkTableExists(String fullTableName) {
        Table bigQueryTable = getTable(fullTableName);
        return bigQueryTable.exists();
    }

    public static List<Column> getColumnsSchemaFromTable(String fullTableName, boolean filterGenerated) throws InterruptedException {
        String[] tableSplit = fullTableName.split("\\.");
        return getColumnsSchemaFromTable(tableSplit[0], tableSplit[1], tableSplit[2], filterGenerated);
    }

    public static List<Column> getColumnsSchemaFromTable(String project, String dataset, String tableName, boolean filterGenerated) throws InterruptedException {
        String columnsSchemaQuery = String.format("SELECT column_name, data_type, is_partitioning_column " +
                        "FROM `%s.%s.INFORMATION_SCHEMA.COLUMNS` " +
                        "WHERE table_name='%s' " +
                        "ORDER BY ordinal_position ASC",
                project, dataset, tableName);

        TableResult tableResult = executeQuery(columnsSchemaQuery);
        LOG.info("Successfully retrieved columns information schema for {}.{}.{}", project, dataset, tableName);

        // Parse to columns
        List<Column> columns = new ArrayList<>();
        for (FieldValueList value : tableResult.getValues()) {
            Column column = new Column();
            column.setName(value.get(0).getStringValue());
            column.setDataType(value.get(1).getStringValue());
            column.setIsPartitioningColumn(Column.Partitioned.valueOf(value.get(2).getStringValue()));

            columns.add(column);
        }

        //Filter system generated columns
        if (filterGenerated) {
            columns = columns.stream()
                    .filter(column -> !column.getName().equalsIgnoreCase("rec_chng_tms")
                            && !column.getName().equalsIgnoreCase("rec_cre_tms")
                            && !column.getName().equalsIgnoreCase("file_name")
                            && !column.getName().equalsIgnoreCase("snapshot_time"))
                    .collect(Collectors.toList());
        }

        return columns;
    }

    public static void ddlCreateTable(String ddl) throws Exception {
        try {
           /* BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
                    ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS")))
            ).build().getService();*/
            QueryJobConfiguration config = QueryJobConfiguration.newBuilder(ddl).setUseQueryCache(false).build();
            Job job = BIGQUERY.create(JobInfo.of(config));
            job = job.waitFor();
            if (job.isDone()) {
                System.out.println("Table was created successfully");
            } else {
                System.out.println("Table was not created");
            }
        } catch (BigQueryException | InterruptedException e) {
            e.printStackTrace();
            Assert.fail("Table was not created.");
        }
    }

    public static TableResult executeBigQueryCustom(String myBQ) throws Exception {
        TableResult result = null;
        try {
            String myQuery = myBQ;
            Long myCount;

            BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
                    ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS")))
            ).build().getService();

            QueryJobConfiguration queryConfig =
                    QueryJobConfiguration.newBuilder(myQuery).build();
            Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).build());

            result = queryJob.getQueryResults();
            System.out.println(result.toString());
            myCount = result.getTotalRows();
            if (myCount>0) {
                System.out.println("Query executed successfully. The record count is: " + myCount );
            } else {
                System.out.println("Query failed");
            }


        } catch (BigQueryException e) {
            System.out.println("Execute query error. \n" + e.toString());
        }
        return result;
    }

    public static TableResult executeQuery(String myBQ, String project) throws Exception {
        TableResult results = null;
        try {
            String myQuery = myBQ;
            Long myCount;
            BigQuery bigquery = BigQueryOptions.newBuilder().setCredentials(
                    ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS")))
            ).setProjectId(project).build().getService();

            results = bigquery.query(QueryJobConfiguration.of(myQuery));
            myCount = results.getTotalRows();

            if (myCount>0) {
                System.out.println("Query executed successfully. The record count is: " + myCount );
            } else {
                System.out.println("Query failed");
            }


        } catch (BigQueryException e) {
            System.out.println("Execute query error. \n" + e.toString());
        }
        return results;
    }
}
