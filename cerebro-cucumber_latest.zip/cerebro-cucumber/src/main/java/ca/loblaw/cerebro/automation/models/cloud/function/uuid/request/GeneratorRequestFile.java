package ca.loblaw.cerebro.automation.models.cloud.function.uuid.request;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GeneratorRequestFile {

    @JsonProperty("target_bucket")
    private String bucket;

    @JsonProperty("target_blob")
    private String blob;

    public GeneratorRequestFile(String bucket, String blob) {
        this.bucket = bucket;
        this.blob = blob;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getBlob() {
        return blob;
    }

    public void setBlob(String blob) {
        this.blob = blob;
    }
}
