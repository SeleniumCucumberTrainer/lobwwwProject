package ca.loblaw.cerebro.automation.helpers.querybuilder.template.complex;

import ca.loblaw.cerebro.automation.helpers.querybuilder.template.TemplateQuery;
import org.apache.commons.lang3.StringUtils;

public class SourceTargetValidationQuery extends TemplateQuery<SourceTargetValidationQuery> {

    protected String sourceQuery;
    protected String targetQuery;

    // Builder
    public SourceTargetValidationQuery setSourceQuery(String sourceQuery) {
        this.sourceQuery = sourceQuery;
        return castThis();
    }

    public SourceTargetValidationQuery setTargetQuery(String targetQuery) {
        this.targetQuery = targetQuery;
        return castThis();
    }

    // Parser
    private String parseSourceTemplateQuery() {
        assert sourceQuery != null;

        return indent(sourceQuery);
    }

    private String parseTargetTemplateQuery() {
        assert targetQuery != null;

        return indent(targetQuery);
    }

    // Build
    @Override
    public String build() {
        String sourceTargetValidationQuery = super.build();

        if(doesTemplateVariablesContain("${SOURCE}")) {
            sourceTargetValidationQuery = StringUtils.replace(sourceTargetValidationQuery,
                    "${SOURCE}", parseSourceTemplateQuery());
        }

        if(doesTemplateVariablesContain("${TARGET}")) {
            sourceTargetValidationQuery = StringUtils.replace(sourceTargetValidationQuery,
                    "${TARGET}", parseTargetTemplateQuery());
        }

        return sourceTargetValidationQuery;
    }
}