package ca.loblaw.cerebro.automation.testcases.cloudcomposer.fulfillment;

import ca.loblaw.cerebro.automation.component.cloud.function.DagsListFunction;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeFactory;
import ca.loblaw.cerebro.automation.utils.contexts.Project;

import java.io.IOException;

public class ComposerFulfillmentSmokeFactory extends ComposerSmokeFactory {

    private static final String DAGS_LIST_PROPERTIES = "src/main/resources/setup/cloudcomposer/fulfillment/dagsListFunction.properties";
    private static final DagsListFunction DAGS_LIST_FUNCTION;

    static {
        try {
            DAGS_LIST_FUNCTION = DagsListFunction.fromPropertiesFile(DAGS_LIST_PROPERTIES);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ComposerFulfillmentSmokeFactory() {
        super(
                DAGS_LIST_FUNCTION,
                Project.FULFILLMENT_ZONE,
                "FulfillmentDAGs",
                "Fulfillment",
                null
        );
    }
}
