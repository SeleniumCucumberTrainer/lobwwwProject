package ca.loblaw.cerebro.automation.component.cloud.composer;

import ca.loblaw.cerebro.automation.component.CloudComponent;
import ca.loblaw.cerebro.automation.component.ComponentType;
import ca.loblaw.cerebro.automation.utils.contexts.Project;

public abstract class CloudComposerComponent implements CloudComponent {

    @Override
    public ComponentType getComponentType() {
        return ComponentType.CLOUD_COMPOSER;
    }

    @Override
    public abstract Project getProject();
}
