package ca.loblaw.cerebro.automation.component.cloud.composer;

import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstanceState;
import ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer.ComposerMetadataLog;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * Representational class for an Airflow DAG run.
 */
public class DagRun extends CloudComposerComponent {

    // DAG general information
    private final String dagId; // DAG ID
    private final Set<String> tasks = new TreeSet<>(); // Available DAG tasks
    private final DagType dagType; // Cerebro DAG type
    private final Project project; // Google Cloud project
    private boolean isPaused = true; // Whether DAG is paused in composer

    // Run specific information
    private String dagRunId; // DAG run ID
    private DagRunState state; // DAG run state
    private String error; // Error message - used if any type of error occurred
    private DagRun upstreamDag; // Upstream DAG run (that calls this DAG)
    private final List<DagRun> downstreamDags = new ArrayList<>(); // Downstream DAG runs called from this DAG
    private final List<TaskInstance> taskInstances = new ArrayList<>(); // DAG run task instances
    private ComposerMetadataLog composerMetadataLog;; // Run metadata log

    public DagRun(String dagId, Project project) {
        this.dagId = dagId;
        this.dagType = DagType.determineDagType(dagId, project);
        this.project = project;
    }

    // Tasks
    public void addTask(String taskId) {
        tasks.add(taskId);
    }

    public boolean hasTask(String taskId) {
        return tasks.contains(taskId);
    }

    // Task instances
    public void addTaskInstance(TaskInstance taskInstance) {
        taskInstances.add(taskInstance);
    }

    public TaskInstance getTaskInstance(String taskId) {
        Optional<TaskInstance> optionalTaskInstance = taskInstances.stream()
                .filter(taskInstance -> taskInstance.getTaskId().equals(taskId))
                .findFirst();

        return optionalTaskInstance.orElse(null);
    }

    public boolean hasTaskInstance(String taskId) {
        return taskInstances.stream()
                .anyMatch(taskInstance -> taskInstance.getTaskId().equals(taskId));
    }

    public boolean taskInstanceIsState(String taskId, TaskInstanceState state) {
        if (hasTaskInstance(taskId)) {
            return getTaskInstance(taskId).getState() == state;
        }
        return false;
    }

    public void clearTaskInstances() {
        taskInstances.clear();
    }

    // Upstream and downstream DAGs
    public boolean hasUpstreamDag() {
        return upstreamDag != null;
    }

    public void addDownstreamDag(DagRun dagRun) {
        downstreamDags.add(dagRun);
    }

    // Conditions
    public boolean hasRunId() {
        return dagRunId != null;
    }

    public boolean hasMetadataLogTaskId() {
        return tasks.stream()
                .anyMatch(task -> task.contains("metadata_log"));
    }

    public String getSuccessfulMetadataLogTaskId() {
        Optional<String> successfulMetadataLogTaskId = taskInstances.stream()
                .filter(taskInstance ->
                        taskInstance.getTaskId().contains("metadata_log") && taskInstance.getState() == TaskInstanceState.SUCCESS)
                .map(taskInstance -> taskInstance.getTaskId())
                .findFirst();
        return successfulMetadataLogTaskId.orElse(null);
    }

    public boolean isOutdated() {
        if (tasks.size() != taskInstances.size()) {
            return true;
        }

        return !tasks.stream()
                .allMatch(taskId -> hasTaskInstance(taskId));
    }

    public boolean hasTaskInstances() {
        return !taskInstances.isEmpty();
    }

    public boolean hasFinishedRun() {
        return hasRunId() && DagRunState.FINISHED_STATES.contains(state);
    }

    /*
     * Valid if:
     * - DAG has a upstream DAG
     * - Upstream DAG has a run ID
     * - Upstream DAG has completed its run
     * - DAG has no state
     * - Upstream DAG has a task instance of the DAG
     */
    public boolean isValidDownstreamDagToBeFound() {

        if (hasUpstreamDag() &&
                upstreamDag.hasFinishedRun() &&
                (upstreamDag.hasTaskInstance("trigger_" + dagId) || upstreamDag.hasTaskInstance("trigger_publication"))
                && this.getState() == null) {

            String upstreamTriggerTaskId = upstreamDag.hasTaskInstance("trigger_" + dagId)
                    ? "trigger_" + dagId : "trigger_publication";

            TaskInstance upstreamTriggerDagTask = upstreamDag.getTaskInstance(upstreamTriggerTaskId);
            return upstreamTriggerDagTask.getState() == TaskInstanceState.SUCCESS;
        }

        return false;
    }

    public boolean hasNoError() {
        return error == null;
    }

    // Getters and Setters
    public String getDagId() {
        return dagId;
    }

    public DagType getDagType() {
        return dagType;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public DagRunState getState() {
        return state;
    }

    public void setState(DagRunState state) {
        this.state = state;
    }

    public Set<String> getTasks() {
        return tasks;
    }

    public DagRun getUpstreamDag() {
        return upstreamDag;
    }

    public void setUpstreamDag(DagRun upstreamDag) {
        this.upstreamDag = upstreamDag;
    }

    public List<DagRun> getDownstreamDags() {
        return downstreamDags;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public boolean isPaused() {
        return isPaused;
    }

    public void setPaused(boolean paused) {
        isPaused = paused;
    }

    public List<TaskInstance> getTaskInstances() {
        return taskInstances;
    }

    public ComposerMetadataLog getMetadataLog() {
        return composerMetadataLog;
    }

    public void setMetadataLog(ComposerMetadataLog composerMetadataLog) {
        this.composerMetadataLog = composerMetadataLog;
    }

    @Override
    public Project getProject() {
        return project;
    }

    @Override
    public String toString() {
        return dagId;
    }

    public String toFullString() {
        return "DagRun {\n" +
                "\tdagId = " + dagId + ",\n" +
                "\ttasks = " + tasksToString() + ",\n" +
                "\tdagType = " + dagType + ",\n" +
                "\tdagRunId = " + dagRunId + ",\n" +
                "\tstate = " + state + ",\n" +
                "\terror = " + error + ",\n" +
                "\tupstreamDag = " + (upstreamDag == null ? "null" : upstreamDag.getDagId()) + ",\n" +
                "\tdownstreamDags = " + downstreamDagsToString() + ",\n" +
                "\tisPaused = " + isPaused + ",\n" +
                "\ttaskInstances = " + taskInstancesToString() + ",\n" +
                "}";
    }

    private String tasksToString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        for (String task : tasks) {
            stringBuilder.append("\n\t\t").append(task).append(",");
        }
        stringBuilder.append("\n\t]");

        // Remove last comma
        int lastCommaIndex = stringBuilder.lastIndexOf(",");
        if (lastCommaIndex != -1) {
            stringBuilder.deleteCharAt(stringBuilder.lastIndexOf(","));
        }

        return stringBuilder.toString();
    }

    private String downstreamDagsToString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        for (DagRun downstreamDag : downstreamDags) {
            stringBuilder.append(", ").append(downstreamDag.getDagId());
        }
        stringBuilder.append("]");

        return StringUtils.replaceOnce(stringBuilder.toString(), ", ", "");
    }

    private String taskInstancesToString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        for (TaskInstance taskInstance : taskInstances) {
            stringBuilder.append("\n\t\t").append(taskInstance.toString()).append(",");
        }
        stringBuilder.append("\n\t]");

        // Remove last comma
        int lastCommaIndex = stringBuilder.lastIndexOf(",");
        if (lastCommaIndex != -1) {
            stringBuilder.deleteCharAt(lastCommaIndex);
        }

        return stringBuilder.toString();
    }
}
