package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRunState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseDagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;

public class RunInfoHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseDagRun responseDagRun = (AirflowResponseDagRun) airflowResponseItem;

        // Update
        dagRun.setState(DagRunState.from(responseDagRun.getState()));
    }
}
