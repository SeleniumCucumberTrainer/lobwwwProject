package ca.loblaw.cerebro.dependencies.common;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;

public class CommonZoneData {

    private String rawZone = TestContext.TEST_CONFIG_MAP.get("rawZone");
    private String tdZone = TestContext.TEST_CONFIG_MAP.get("tdZone");
    private String conZone = TestContext.TEST_CONFIG_MAP.get("conZone");
    private String tcZone = TestContext.TEST_CONFIG_MAP.get("tcZone");
    private String fulZone = TestContext.TEST_CONFIG_MAP.get("fulZone");
    private String abiZone = TestContext.TEST_CONFIG_MAP.get("abiZone");
    private String testBucket = TestContext.TEST_CONFIG_MAP.get("testBucket");
    private String testDataset = TestContext.TEST_CONFIG_MAP.get("testDataset");

    public String getTestBucket() {
        return testBucket;
    }
    public String getTestDataset() {
        return testDataset;
    }
    public String getRawZone() {
        return rawZone;
    }
    public String getTdZone() {
        return tdZone;
    }
    public String getConZone() {
        return conZone;
    }
    public String getTcZone() {
        return tcZone;
    }
    public String getFulZone() {
        return fulZone;
    }
    public String getAbiZone() {
        return abiZone;
    }
}
