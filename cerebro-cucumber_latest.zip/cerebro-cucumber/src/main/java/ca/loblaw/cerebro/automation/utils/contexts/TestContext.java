package ca.loblaw.cerebro.automation.utils.contexts;

import ca.loblaw.cerebro.automation.utils.command.CommandLineExecutor;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Utility class to describe current test context.
 */
public class TestContext {

    private static final String CONFIG_FILE_PATH = "src/main/resources/configs/TestConfig.properties";
    public static final Environment ENV = getEnvironment();
    public static final Zone ZONE = getZone();
    public static final String GOOGLE_APPLICATION_CREDENTIALS = getCredentials();
    public static ConcurrentHashMap<String, String> TEST_CONFIG_MAP;

    private TestContext() {}

    public static void readTestConfigProperties() throws IOException {
        TEST_CONFIG_MAP = new ConcurrentHashMap<>(PropertiesFileUtils.readPropertiesFileToMap(CONFIG_FILE_PATH));
    }

    public static void activateCommandLineServiceAccount() throws IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode serviceAccountJson = objectMapper.readTree(Files.readAllBytes(Paths.get(GOOGLE_APPLICATION_CREDENTIALS)));
        String serviceAccount = serviceAccountJson.get("client_email").asText();
        String projectId = serviceAccountJson.get("project_id").asText();

        CommandLineExecutor.activateServiceAccount(serviceAccount, GOOGLE_APPLICATION_CREDENTIALS, projectId);
    }

    public static String replaceTemplateProject(String value) {
        for (Project project : Project.values()) {
            String property = project.getName();
            String template = project.getTemplate();

            if (value.contains(template)) {
                value = value.replace(template, property);
                break;
            }
        }

        return value;
    }

    public static String replaceAllTemplateProjects(String value) {
        for (Project project : Project.values()) {
            String property = project.getName();
            String template = project.getTemplate();

            if (value.contains(template)) {
                value = value.replace(template, property);
            }
        }

        return value;
    }

    public static String replaceTemplateZone(String value) {
        if (value.contains("${ZONE}")) {
            value = value.replace("${ZONE}", ZONE.toString());
        }

        return value;
    }

    public static String replaceTemplateEnv(String value) {
        if (value.contains("${ENV}")) {
            value = value.replace("${ENV}", ENV.toString());
        }

        return value;
    }

    private static String getCredentials() {
        if (System.getProperty("GOOGLE_APPLICATION_CREDENTIALS") != null) {
            return System.getProperty("GOOGLE_APPLICATION_CREDENTIALS");
        } else {
            return System.getenv("GOOGLE_APPLICATION_CREDENTIALS");
        }
    }

    private static Zone getZone() {
        if (System.getProperty("testZONE") != null) {
            return Zone.from(System.getProperty("testZONE"));
        } else {
            return Zone.from(System.getenv("testZONE"));
        }
    }

    private static Environment getEnvironment() {
        if (System.getProperty("testENV") != null) {
            return Environment.from(System.getProperty("testENV"));
        } else {
            return Environment.from(System.getenv("testENV"));
        }
    }

    public static String getProject(String val){
        if (val.contains("${RAWZONE}")){
            val = val.replace("${RAWZONE}",TEST_CONFIG_MAP.get("rawZone"));
        }
        if (val.contains("${TDZONE}")){
            val = val.replace("${TDZONE}",TEST_CONFIG_MAP.get("tdZone"));
        }
        if (val.contains("${CONZONE}")){
            val = val.replace("${CONZONE}",TEST_CONFIG_MAP.get("conZone"));
        }
        if (val.contains("${TCZONE}")){
            val = val.replace("${TCZONE}",TEST_CONFIG_MAP.get("tcZone"));
        }
        if (val.contains("${FULZONE}")){
            val = val.replace("${FULZONE}",TEST_CONFIG_MAP.get("fulZone"));
        }
        if (val.contains("${ABIZONE}")) {
            val = val.replace("${ABIZONE}", TEST_CONFIG_MAP.get("abiZone"));
        }

        return val;
    }

    public static String getTestDataSet(String val){
        if (val.contains("${TESTDATASET}")){
            val = val.replace("${TESTDATASET}",TEST_CONFIG_MAP.get("testDataSet"));
        }
        return val;
    }

    public static String getTestEnvironment(String val){
        if (val.contains("${ENV}")){
            if(System.getenv("testENV")==null)
                val = val.replace("${ENV}",System.getProperty("testENV"));
            else
                val = val.replace("${ENV}",System.getenv("testENV"));
        }
        return val;
    }

    public static String getTestRegion(String val){

        if (val.contains("${ZONE}")){
            if(System.getenv("testZONE")==null)
                val = val.replace("${ZONE}",System.getProperty("testZONE"));
            else
                val = val.replace("${ZONE}",System.getenv("testZONE"));
        }
        return val;
    }

    public static String getsqlBucket(String val)
    {
        String env = "";
        if(System.getProperty("testENV")==null)
            env=System.getenv("testENV");
        else
            env=System.getProperty("testENV");
        if(val.contains("cerebro-${ENV}"))
            val=val.replace("${ENV}",env);
        switch (env)
        {
            case "exp":
                val=val.replace("${ENV}","northamerica-northeast1-cp--abe4727d-bucket");
                break;
            case "val":
                val=val.replace("${ENV}","northamerica-northeast1-cp--7e87c9e1-bucket");
                break;
        }
        return val;
    }

}
