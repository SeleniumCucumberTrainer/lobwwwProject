package ca.loblaw.cerebro.automation.models.validations;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;

public class CurationComposerValidationDto {

    DagRun dagRun;
    String jobRunTraceId;
    String sourceName;
    String targetName;
    String recCreTms;
    String dataflowJobId;
    String dataflowJobName;
    long tableRecordCount;

    public DagRun getDagRun() {
        return dagRun;
    }

    public CurationComposerValidationDto setDagRun(DagRun dagRun) {
        this.dagRun = dagRun;
        return this;
    }

    public String getJobRunTraceId() {
        return jobRunTraceId;
    }

    public CurationComposerValidationDto setJobRunTraceId(String jobRunTraceId) {
        this.jobRunTraceId = jobRunTraceId;
        return this;
    }

    public String getSourceName() {
        return sourceName;
    }

    public CurationComposerValidationDto setSourceName(String sourceName) {
        this.sourceName = sourceName;
        return this;
    }

    public String getTargetName() {
        return targetName;
    }

    public CurationComposerValidationDto setTargetName(String targetName) {
        this.targetName = targetName;
        return this;
    }

    public String getRecCreTms() {
        return recCreTms;
    }

    public CurationComposerValidationDto setRecCreTms(String recCreTms) {
        this.recCreTms = recCreTms;
        return this;
    }

    public String getDataflowJobId() {
        return dataflowJobId;
    }

    public CurationComposerValidationDto setDataflowJobId(String dataflowJobId) {
        this.dataflowJobId = dataflowJobId;
        return this;
    }

    public String getDataflowJobName() {
        return dataflowJobName;
    }

    public CurationComposerValidationDto setDataflowJobName(String dataflowJobName) {
        this.dataflowJobName = dataflowJobName;
        return this;
    }

    public long getTableRecordCount() {
        return tableRecordCount;
    }

    public CurationComposerValidationDto setTableRecordCount(long tableRecordCount) {
        this.tableRecordCount = tableRecordCount;
        return this;
    }
}
