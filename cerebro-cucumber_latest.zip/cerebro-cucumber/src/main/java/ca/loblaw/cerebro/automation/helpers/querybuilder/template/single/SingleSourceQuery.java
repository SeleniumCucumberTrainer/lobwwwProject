package ca.loblaw.cerebro.automation.helpers.querybuilder.template.single;

import ca.loblaw.cerebro.automation.helpers.querybuilder.template.TemplateQuery;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class SingleSourceQuery extends TemplateQuery<SingleSourceQuery> {

    private String tableName;
    private String subQuery;
    private List<Column> columns;
    private List<CloudStorageFile> files;
    private Integer limit;
    private String fileColumnName;
    private String timestamp;

    // Builders
    public SingleSourceQuery setTableName(String tableName) {
        this.tableName = tableName;
        return this;
    }

    public SingleSourceQuery setColumns(List<Column> columns) {
        this.columns = columns;
        return this;
    }

    public SingleSourceQuery setFiles(List<CloudStorageFile> files) {
        this.files = files;
        return this;
    }

    public SingleSourceQuery setLimit(int limit) {
        this.limit = limit;
        return this;
    }

    public SingleSourceQuery setTimestamp(String timestamp) {
        this.timestamp = timestamp;
        return this;
    }

    public SingleSourceQuery setSubQuery(String subQuery) {
        this.subQuery = subQuery;
        return this;
    }

    public SingleSourceQuery setLimit(Integer limit) {
        this.limit = limit;
        return this;
    }

    public SingleSourceQuery setFileColumnName(String fileColumnName) {
        this.fileColumnName = fileColumnName;
        return this;
    }

    // Parsers
    private String parseTableName() {
        assert tableName != null && !tableName.isEmpty();

        return tableName;
    }

    private String parseSubQuery() {
        assert subQuery != null && !subQuery.isEmpty();

        return subQuery;
    }

    private String parseFileColumnName() {
        assert fileColumnName != null && !fileColumnName.isEmpty();

        return fileColumnName;
    }

    private String parseColumns() {
        assert columns != null && !columns.isEmpty();

        StringBuilder columnsString = new StringBuilder();

        for(Column column : columns) {
            columnsString.append(", ");
            if (column.hasFunctionsApplied()){
                columnsString.append(column.getNameWithFunctionsApplied()).append(column.getAlias());
            } else {
                columnsString.append(column.getName());
            }
        }

        return StringUtils.replaceOnce(columnsString.toString(), ", ", "");
    }

    private String parseCoalesceColumns() {
        assert columns != null && !columns.isEmpty();

        StringBuilder coalesceColumnsString = new StringBuilder();

        for(Column column : columns) {
            coalesceColumnsString.append(", COALESCE(").append(column.getName());

            if(column.getName().toLowerCase().contains("timestamp")) {
                coalesceColumnsString.append(", TIMESTAMP('0001-01-01 11:11:11')) as ");
            } else {
                coalesceColumnsString.append(", '') as ");
            }

            coalesceColumnsString.append(column.getName());
        }

        return StringUtils.replaceOnce(coalesceColumnsString.toString(), ", ", "");
    }

    private String parseFiles() {
        assert files != null && !files.isEmpty();

        StringBuilder filesString = new StringBuilder();

        for(CloudStorageFile file : files) {
            filesString.append(",\n\"").append(file.getName()).append("\"");
        }

        return indent(StringUtils.replaceOnce(filesString.toString(), ",\n", ""));
    }

    private String parseFilesNames() {
        assert files != null && !files.isEmpty();

        StringBuilder filesNamesString = new StringBuilder();

        for(CloudStorageFile file : files) {
            filesNamesString.append(",\n\"").append(FilenameUtils.getName(file.getName())).append("\"");
        }

        return indent(StringUtils.replaceOnce(filesNamesString.toString(), ",\n", ""));
    }

    private String parseLimit() {
        assert limit != null && limit > 0;

        return String.valueOf(limit);
    }

    private String parseTimestamp() {
        assert timestamp != null && !timestamp.isEmpty();

        return timestamp;
    }

    @Override
    public String build() {
        String selectTemplateQuery = super.build();

        if (doesTemplateVariablesContain("${SUBQUERY}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${SUBQUERY}", parseSubQuery());
        }

        if (doesTemplateVariablesContain("${TABLE}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${TABLE}", parseTableName());
        }

        if (doesTemplateVariablesContain("${FILE COLUMN}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${FILE COLUMN}", parseFileColumnName());
        }

        if (doesTemplateVariablesContain("${COLUMNS}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${COLUMNS}", parseColumns());
        }

        if (doesTemplateVariablesContain("${COALESCE COLUMNS}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${COALESCE COLUMNS}", parseCoalesceColumns());
        }

        if (doesTemplateVariablesContain("${FILES}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${FILES}", parseFiles());
        }

        if (doesTemplateVariablesContain("${FILES NAMES}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${FILES NAMES}", parseFilesNames());
        }

        if (doesTemplateVariablesContain("${TIMESTAMP}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${TIMESTAMP}", parseTimestamp());
        }

        if (doesTemplateVariablesContain("${LIMIT}")) {
            selectTemplateQuery = StringUtils.replace(selectTemplateQuery,
                    "${LIMIT}", parseLimit());
        }

        return selectTemplateQuery;
    }
}
