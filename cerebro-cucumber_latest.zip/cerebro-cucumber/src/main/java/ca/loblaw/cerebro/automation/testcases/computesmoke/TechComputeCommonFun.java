package ca.loblaw.cerebro.automation.testcases.computesmoke;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.data.RawFolders;
import ca.loblaw.cerebro.automation.models.pipelines.PublicationType;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.cloud.bigquery.BigQueryUtils;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileContainer;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileFieldOptions;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.contexts.OperatingSystemContext;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import ca.loblaw.cerebro.automation.utils.smokeutil.SmokeSuitPipelineExecutor;
import ca.loblaw.cerebro.dependencies.common.CommonZoneData;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FieldList;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.TableResult;
import org.apache.commons.io.FilenameUtils;
import org.assertj.core.api.Assertions;
import org.testng.annotations.*;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.testng.Assert.assertTrue;

public class TechComputeCommonFun extends BaseTest {

    //============================Parameter================================

    private String gcFilePath;
    private String maxSizeMB;
    private String takeSmallestFile;
    private String localPropfile;
    private String table_to_create;
    private String error_table_to_create;
    private String clone_from_dataset;
    private String clone_from_project;
    private String clone_from_table;
    private String bucketURI;
    private String runtimeArgs;
    private String query;
    private String tmsQuery;
    private String condition;
    private String jarPath_arc;
    private String jarPath_cur;
    private String jobName_src;
    private String jobName_trg;

    //========================runtime=============================
    private String ingestionFile;

    //=============================================================
    private Map<String, String> propertiesMap;
    private static final long ONE_MEGABYTE = 1048576L; // Bytes in one megabyte
    private String ddl;
    private String propertiesName;
    private String downloadedPropFile;
    private CommonZoneData commonZoneData;
    private String mainClass = "ca.loblaw.cerebro.PipelineControl.PipelineControl";
    private String setupFile = "src/main/resources/configs/TechComputeSmoke/tech_compute_smoke_setup.properties";
    private String testDataPath = "src/main/resources/configs/TechComputeSmoke/testdata/";


    public TechComputeCommonFun(String tesDataFilePATH) throws IOException {
        this.propertiesMap = PropertiesFileUtils.readPropertiesFileToMap(testDataPath+"/"+tesDataFilePATH);
        setupProperties();
        setupRemoveConditions();

    }

    private void setupRemoveConditions() {
        // Curation
        if (tmsQuery == null) {
            addRemoveCondition("add_timestmp");
        } else {
            addRemoveCondition("NA");
        }
    }

    private void setupProperties() {
        this.gcFilePath = propertiesMap.get("gcFilePath");
        this.maxSizeMB = propertiesMap.get("maxSizeMB");
        this.takeSmallestFile = propertiesMap.get("takeSmallestFile");
        this.localPropfile = propertiesMap.get("localPropfile");
        this.table_to_create = propertiesMap.get("table_to_create");
        this.error_table_to_create = propertiesMap.get("error_table_to_create");
        this.clone_from_dataset = propertiesMap.get("clone_from_dataset");
        this.clone_from_project = propertiesMap.get("clone_from_project");
        this.clone_from_table = propertiesMap.get("clone_from_table");
        this.bucketURI = propertiesMap.get("testing");
        this.runtimeArgs = propertiesMap.get("runtimeArgs");
        this.query = propertiesMap.get("query");
        this.jarPath_arc = propertiesMap.get("jarPath_arc");
        this.jarPath_cur = propertiesMap.get("jarPath_cur");
        this.jobName_src = propertiesMap.get("jobName_src");
        this.jobName_trg = propertiesMap.get("jobName_trg");
        this.tmsQuery = propertiesMap.get("tmsQuery");
        this.condition = propertiesMap.get("condition");
    }

    @BeforeClass
    public void propertiesFileAndTableSetup() throws Exception {
        //Setup common zone
        this.commonZoneData = new CommonZoneData();

        // pre-requites for dataflow test cases
        if(condition == null){
            //means nothing specific to run
        }
        else if(condition.contains("updateInboundURI")) {
            getIngestionFileBySizeAndFlag(gcFilePath, maxSizeMB, takeSmallestFile);
            updateInboundUriInPropertiesFile(localPropfile);
        }
        else if(condition.contains("updateTMSInPropFile")) {
            updatePropertiesFileWithMax_rec_cre_tms(localPropfile,tmsQuery);
        }
        queryDDLSchemaForGivenTable(clone_from_project, clone_from_table);
        dropGiventable(table_to_create, error_table_to_create, clone_from_dataset, clone_from_project);
        createGivenBQTable(table_to_create, clone_from_project, clone_from_dataset, clone_from_table);


    }

    @Test(description = "Trigger and Validate the Dataflow job" , priority = 1)
    public void triggerAndValidateTheDataflowJob() throws Exception {

        setLocalPropertiesFileLocationToDownloadFolder(localPropfile);
        uploadLocalPropertiesFiletoGCSFromDownloadFolder(bucketURI);
        executeDataflowJobPipelineForCurrentAndArchiveJarInParallel(mainClass, runtimeArgs);
    }

    @Test(description = "Validate the record counts match", priority = 2)
    public void ValidateTheRecordCountsMatch() throws Exception {
        executeQueryAndValidateRecordCountMatch(query);
    }

    public void getIngestionFileBySizeAndFlag(String gcFilePath, String maxSizeMB, String takeSmallestFile) {
        try {
            String bucket = TestContext.getTestEnvironment("gs://" + gcFilePath);
            boolean takeSmallestFileFlag = Boolean.parseBoolean(takeSmallestFile);

            ingestionFile = getIngestionFileBySize(bucket, Integer.parseInt(maxSizeMB), takeSmallestFileFlag);
            Assertions.assertThat(ingestionFile.contains("gs://"))
                    .as("Ingestion file with maximum size " + maxSizeMB + " mb not found in bucket " + bucket)
                    .isTrue();
            Reporter.info("Ingestion file found - " + ingestionFile);
        } catch (Exception e) {
            e.printStackTrace();
            Assertions.fail("Ingestion file not found.");
        }
    }

    public void updateInboundUriInPropertiesFile(String localPropFile) {
        Assertions.assertThat(ingestionFile).as("Ingestion file not found").isNotNull();
        Reporter.info("Found ingestion file - " + ingestionFile);

        try {
            Map<String, String> file = PropertiesFileUtils.readPropertiesFileToMap(localPropFile);

            String oldInboundURI = file.get("inboundURI");
            String newInboundUri = FilenameUtils.getPath(oldInboundURI) + FilenameUtils.getName(ingestionFile);
            newInboundUri = newInboundUri.replaceAll("-(exp|val|prd)-", "-\\${ENV}-");
            file.put("inboundURI", newInboundUri);

            PropertiesFileUtils.writeMapToPropertiesFile(file,localPropFile);
        } catch (IOException e) {
            Reporter.error("Error when updating the property file - " + localPropFile);
            e.printStackTrace();
        }
        Reporter.info("Inbound URI is updated in file - " + localPropFile);
    }

    public void queryDDLSchemaForGivenTable(String project, String table) {
        try {
            project = TestContext.getProject(project);
            String query = "SELECT ddl FROM region-northamerica-northeast1.INFORMATION_SCHEMA.TABLES where table_catalog = '" + project + "' and table_name = '" + table + "'";
            System.out.println("Query: " + query);
            Reporter.info("Query : " + query);
            TableResult schema = BigQueryUtils.executeQuery(query, project);
            this.ddl = schema.getValues().iterator().next().get(0).getStringValue();
            Reporter.info("DDL Schema : " + this.ddl,"Scrollable");
        } catch (Exception e) {
            e.printStackTrace();
            Assertions.fail("Failed creating DDL schema");
        }
    }

    public void dropGiventable(String table, String eventLog, String dataset, String project) throws Exception {
        project = TestContext.getProject(project);
        dataset = TestContext.getTestDataSet(dataset);
        BigQueryUtils.deleteTable(project, dataset, table);
        BigQueryUtils.deleteTable(project, dataset, eventLog);
        Reporter.info("Successfully dropped \n" + "Project : " + project + "\nDataset : " + dataset + "\n Table : " + table);
    }

    public void createGivenBQTable(String qa_table, String project, String dataset, String ddlTable) throws Exception {
        project = TestContext.getProject(project);
        dataset = TestContext.getTestDataSet(dataset);

        String location = this.ddl.split("`")[1];
        String domSubdom = location.split("[.]")[1];

        if (this.ddl.contains("raw")) {
            this.ddl = this.ddl.replace("{{project.raw}}", project);
        } else if (this.ddl.contains("techdata")) {
            this.ddl = this.ddl.replace("{{project.techdata}}", project);
        } else if (this.ddl.contains("consume")) {
            this.ddl = this.ddl.replace("{{project.consume}}", project);
        } else if (this.ddl.contains("fulfillment")) {
            this.ddl = this.ddl.replace("{{project.fulfillment}}", project);
        } else if (this.ddl.contains("abi")) {
            this.ddl = this.ddl.replace("{{project.abi}}", project);
        }
        if (ddlTable.contains("sdm_product_hierarchy_scancode_work")) {
            this.ddl = this.ddl.replace("." + domSubdom + ".", "." + dataset + ".");
        } else {
            this.ddl = this.ddl.replace(domSubdom, dataset);
        }
        this.ddl = this.ddl.replace(ddlTable, qa_table);
        this.ddl = this.ddl.replace("CREATE TABLE", "CREATE OR REPLACE TABLE");
        //Convert DDL statement to a single line
        this.ddl = this.ddl.replaceAll("\r", " ")
                .replaceAll("\n", " ")
                .replace("\"true\"", "\\\"true\\\"")
                .replace("\"false\"", "\\\"false\\\"");

        BigQueryUtils.ddlCreateTable(this.ddl);
        Reporter.info("Successfully created the table : " + this.ddl,"Scrollable");
    }

    public void setLocalPropertiesFileLocationToDownloadFolder(String localPath) throws Exception {
        try {
            String[] path = localPath.split("/");
            this.propertiesName = path[path.length - 1];
            Date date = new Date();
            final SimpleDateFormat sdf =
                    new SimpleDateFormat("yyyy-MM-dd");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
            Map<String, String> localMap = PropertiesFileUtils.readPropFileUpdateConfigParam(localPath);
            localMap.put("fileLocation", localMap.get("fileLocation") + sdf.format(date.getTime()) + "/");
            this.downloadedPropFile = OperatingSystemContext.filePathConfigMap.get("downloadDirectory") + "/" + this.propertiesName;
            PropertiesFileUtils.writeMapToPropertiesFile(localMap,this.downloadedPropFile);
            TestContext.TEST_CONFIG_MAP.put("downloadedPropFile", this.downloadedPropFile);
        } catch (Exception e) {
            e.printStackTrace();
            Assertions.fail("Failed to set local properties path.");
        }
    }

    public void uploadLocalPropertiesFiletoGCSFromDownloadFolder(String bucketURI) {
        try {
            String cloudFilePath = commonZoneData.getTestBucket() + "/" + bucketURI + this.propertiesName;
            CloudStorageUtils.uploadFile(this.downloadedPropFile, cloudFilePath);
            Reporter.info("Successfully uploaded from " + this.downloadedPropFile + " to " + cloudFilePath);
        } catch (Exception e) {
            e.printStackTrace();
            Assertions.fail("Failed to upload the modified properties file.");
        }
    }

    public void executeDataflowJobPipelineForCurrentAndArchiveJarInParallel(String mainClass, String runtimeArgs) {
        try {
            Map<String, String> props = PropertiesFileUtils.readPropertiesFileToMap(setupFile);
            String project = TestContext.getTestEnvironment(props.get("project"));
            String region = props.get("region");
            String functionName = TestContext.getTestEnvironment(props.get("cloudFunctionName"));

            List<Map<String, String>> dt = getJarData();

            List<Boolean> jobsResult = triggerJobs(dt, project, region, functionName, mainClass, runtimeArgs);

            if (jobsResult.contains(false) || jobsResult.size() != 2) {
                Reporter.info("DF jobs failed or not completed.");
            } else {
                Reporter.info("Dataflow jobs successfully completed.");
            }
        } catch (Exception e) {
            Reporter.error("Failed to invoke cloud function");
            e.printStackTrace();
        }
    }

    public void execute_bigquery_retrieve_results(String query) throws Exception {

        List<Map<String, String>> dt = new ArrayList<Map<String, String>>();
        Map<String, String> jarMap_src = new HashMap<String, String>();
        jarMap_src.put("Query", query);

        dt.add(jarMap_src);

        String bigQuery = dt.get(0).get("Query");
        bigQuery = TestContext.getTestEnvironment(bigQuery);
        Reporter.info("Query : \n" + bigQuery);
        bigQuery = TestContext.getProject(bigQuery);
        bigQuery = TestContext.getTestDataSet(bigQuery);
        System.out.println("Execute query : " + bigQuery);

        TableResult queryResult = BigQueryUtils.executeBigQueryCustom(bigQuery);
        Assertions.assertThat(queryResult.getTotalRows() > 0)
                .as("Query execution failed , Empty rows returned")
                .isTrue();
        Reporter.info("Total Number of Rows : " + queryResult.getTotalRows());
    }

    public void executeQueryAndValidateRecordCountMatch(String query) throws Exception {

        String bigQuery = TestContext.getTestEnvironment(query);
        Reporter.info("Query : \n" + bigQuery);
        bigQuery = TestContext.getProject(bigQuery);
        bigQuery = TestContext.getTestDataSet(bigQuery);
        System.out.println("Execute query : " + bigQuery);
        TableResult queryResult = BigQueryUtils.executeBigQueryCustom(bigQuery);

        String validation = "equals"; String fieldName = "record_count";

        List<String> listCount = new ArrayList<>();
        FieldList columnName = queryResult.getSchema().getFields();
        Assertions.assertThat(queryResult.getTotalRows() > 1)
                .as("Group by rows on the query did not result in more than 1 row")
                .isTrue();
        if (validation.equalsIgnoreCase("equals")) {
            for (FieldValueList row : queryResult.iterateAll()) {
                for (Field col : columnName) {
                    System.out.println(col.getName() + ": " + row.get(col.getName()).getStringValue());
                    Reporter.info(col.getName() + ": " + row.get(col.getName()).getStringValue());
                    if (col.getName().equalsIgnoreCase(fieldName)) {
                        listCount.add(row.get(col.getName()).getStringValue());

                    }
                }
            }
            Assertions.assertThat(listCount.stream().distinct().count() <= 1)
                    .as("The Records count do not match")
                    .isTrue();
            Reporter.info("Record Count Assertion Passed");
            System.out.println("Record Count Assertion Passed");
        }
    }


    //====================================================================================
    private List<Boolean> triggerJobs(List<Map<String, String>> dt, String project, String region, String functionName, String mainClass, String runtimeArgs) throws InterruptedException {
        List<Boolean> jobsResult = new ArrayList<>();
        ExecutorService executor = Executors.newFixedThreadPool(2);

        for (Map<String, String> arg : dt) {
            String jarPath = arg.get("jarPath");
            String jobName = arg.get("jobName");

            executor.execute(() -> {
                SmokeSuitPipelineExecutor pipeline = new SmokeSuitPipelineExecutor(runtimeArgs, mainClass, jarPath, jobName);
                try {
                    pipeline.setupCloudFunction(project, region, functionName)
                            .trigger();

                    jobsResult.add(pipeline.waitFor());
                } catch (Exception e) {
                    System.out.println("Failed when executing pipeline " + mainClass);
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            });
            Thread.sleep(60000);
        }
        executor.shutdown();
        do {
            if (jobsResult.size() == 2) {
                executor.shutdownNow();
            }
            executor.awaitTermination(30000, TimeUnit.MILLISECONDS);
        }
        while (!executor.isTerminated());

        return jobsResult;
    }

    /***
     * Get ingestion file from the bucket within max size.
     * @param bucket Valid GCS path (e.g. gs://path_to_bucket)
     * @param maxSizeMB Maximum size of the file in MB
     * @param takeSmallestFile A flag to take the smallest file found
     * @return The full gcs path of the ingestion file that's closest to maxSizeMB.
     * If takeLeastFile flag is set to true, then it returns the smallest file.
     */
    public String getIngestionFileBySize(String bucket, int maxSizeMB, boolean takeSmallestFile) {
        long maxSize = maxSizeMB * ONE_MEGABYTE;

        try {
            List<CloudStorageFile> cloudStorageFiles = CloudStorageUtils.listFiles(bucket,
                    new CloudStorageFileFieldOptions().includeName().includeSize());

            List<CloudStorageFile> filteredFiles = filterMetaFiles(cloudStorageFiles);
            List<CloudStorageFile> sortedFilesBySizeAsc = CloudStorageFileContainer.wrap(filteredFiles).sortBySize(true).getCloudStorageFileList();

            if (takeSmallestFile) {
                return getIngestionSmallestFileBySize(sortedFilesBySizeAsc, maxSize);
            } else {
                return getIngestionLargestFileBySize(sortedFilesBySizeAsc, maxSize);
            }
        } catch (NoSuchElementException e) {
            Reporter.error("No valid files were found from bucket " + bucket);
            throw e;
        } catch (Exception e) {
            Reporter.error("Error when reading file from bucket " + bucket);
            throw e;
        }
    }

    private List<CloudStorageFile> filterMetaFiles(List<CloudStorageFile> files) {
        Pattern validFilesPattern = Pattern.compile("[a-zA-Z_0-9]+[_-][0-9]{1,2}[0-9-_:A-Z.]+\\.[a-z.]+");
        files.removeIf(s -> {
            String fileFullName = s.getName();
            String fileName = fileFullName.substring(fileFullName.lastIndexOf("/") + 1);
            Matcher matcher = validFilesPattern.matcher(fileName);
            return !matcher.find() || fileFullName.endsWith(".dfm");
        });
        return files;
    }

    public String getIngestionSmallestFileBySize(List<CloudStorageFile> sortedFilesBySizeAsc, long maxSize) {
        for (CloudStorageFile file : sortedFilesBySizeAsc) {
            long fileSize = file.getSize();

            if (fileSize < ONE_MEGABYTE) {

            } else if (fileSize <= maxSize) {
                return file.getName();
            } else {
                return file.getName();
            }
        }

        throw new NoSuchElementException();
    }

    public String getIngestionLargestFileBySize(List<CloudStorageFile> sortedFilesBySizeAsc, long maxSize) {
        String largestValidFile = "";

        for (CloudStorageFile file : sortedFilesBySizeAsc) {
            long fileSize = file.getSize();

            if (fileSize < ONE_MEGABYTE) {

            } else if (fileSize <= maxSize) {
                largestValidFile = file.getName();
            } else {
                return !largestValidFile.isEmpty() ? largestValidFile : file.getName();
            }
        }

        if (largestValidFile.isEmpty()) {
            throw new NoSuchElementException();
        }

        return largestValidFile;
    }

    public void updatePropertiesFileWithMax_rec_cre_tms(String localPropFile, String query)  {
        query = TestContext.getTestEnvironment(query);
        query = TestContext.getProject(query);
        query = TestContext.getTestDataSet(query);
        try {
            TableResult results = BigQueryUtils.executeQuery(query);
            String updated_rec_cre_tms = String.valueOf(results.getValues().iterator().next().get("rec_cre_tms").getStringValue()).replace("+00", " UTC");
            assertTrue(results.getTotalRows() == 1);
            Map<String, String> propMap = PropertiesFileUtils.readPropertiesFileToMap(localPropFile);
            propMap.put("rec_cre_tms", propMap.get("rec_cre_tms").replace("rec_cre_tms",   updated_rec_cre_tms ));
            if (propMap.containsKey("sink.table") && propMap.get("sink.table").contains("user_work_qa")) {
                propMap.put("rec_cre_tms", updated_rec_cre_tms);
            } else {
                propMap.put("rec_cre_tms", "'" + updated_rec_cre_tms + "'");
            }
            PropertiesFileUtils.writeMapToPropertiesFile(propMap, localPropFile);
            System.out.println("Successfully updated file " + localPropFile + " with rec_cre_tms: " + updated_rec_cre_tms);
        } catch (IOException io){
            Assertions.fail("Failed when performing read/write operation to file: "+localPropFile);
        } catch (Exception e) {
            Assertions.fail("Failed when executing bigQuery: "+query);
        }
    }

    public List<Map<String, String>> getJarData() {

        List<Map<String, String>> allJarMapList = new ArrayList<Map<String, String>>();

        Map<String, String> jarMap_arc = new HashMap<String, String>();
        jarMap_arc.put("jarPath", this.jarPath_arc);
        jarMap_arc.put("jobName", this.jobName_src);

        Map<String, String> jarMap_curr = new HashMap<String, String>();
        jarMap_curr.put("jarPath", this.jarPath_cur);
        jarMap_curr.put("jobName", this.jobName_trg);

        allJarMapList.add(jarMap_arc);
        allJarMapList.add(jarMap_curr);
        return allJarMapList;
    }

}


