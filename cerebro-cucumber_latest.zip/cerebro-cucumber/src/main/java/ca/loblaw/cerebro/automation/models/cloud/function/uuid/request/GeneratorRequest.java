package ca.loblaw.cerebro.automation.models.cloud.function.uuid.request;

import ca.loblaw.cerebro.automation.models.cloud.function.FunctionRequest;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class GeneratorRequest implements FunctionRequest {

    @JsonProperty("uuid_only_mode")
    private String uuidOnly = "false";

    @JsonProperty("data")
    private List<GeneratorRequestFile> data;

    public String getUuidOnly() {
        return uuidOnly;
    }

    public void setUuidOnly(String uuidOnly) {
        this.uuidOnly = uuidOnly;
    }

    public List<GeneratorRequestFile> getData() {
        return data;
    }

    public void setData(List<GeneratorRequestFile> data) {
        this.data = data;
    }

}
