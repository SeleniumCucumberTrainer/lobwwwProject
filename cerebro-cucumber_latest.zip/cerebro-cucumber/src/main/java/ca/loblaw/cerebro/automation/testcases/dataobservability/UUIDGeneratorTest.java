package ca.loblaw.cerebro.automation.testcases.dataobservability;

import ca.loblaw.cerebro.automation.component.cloud.function.UUIDGenerator;
import ca.loblaw.cerebro.automation.helpers.dataobservability.ObservabilityFile;
import ca.loblaw.cerebro.automation.helpers.dataobservability.ObservabilityFileFactory;
import ca.loblaw.cerebro.automation.models.cloud.function.uuid.request.GeneratorRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.uuid.request.GeneratorRequestFile;
import ca.loblaw.cerebro.automation.models.cloud.function.uuid.response.GeneratorResponse;
import ca.loblaw.cerebro.automation.models.cloud.function.uuid.response.GeneratorResponseFile;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStoragePathSplitter;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.LocalFileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

@Test(groups = { "data-observability", "cloud-function", "uuid" })
public class UUIDGeneratorTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(UUIDGeneratorTest.class);

    private static UUIDGenerator UUID_GENERATOR;
    private static final Pattern UUID_PATTERN = Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    private static final String FOLDER_PATH = TestContext.replaceTemplateEnv("gs://cerebro-${ENV}-raw-testing/data_observability/");
    private static final String UUID_KEY = TestContext.replaceTemplateEnv("uuid-${ENV}");
    private static final String[] VALID_FILE_NAMES = new String[] {
            FOLDER_PATH + "valid1.txt",
            FOLDER_PATH + "valid2.txt",
            FOLDER_PATH + "valid3.txt",
            FOLDER_PATH + "valid4.txt"
    };
    private static String[] INVALID_FILE_NAMES = new String[] {
            FOLDER_PATH + "invalid1.txt",
            FOLDER_PATH + "invalid2.txt",
            FOLDER_PATH + "invalid3.txt",
            FOLDER_PATH + "invalid4.txt"
    };

    // Instance fields
    private final ObservabilityFileFactory observabilityFileFactory = new ObservabilityFileFactory();
    private List<ObservabilityFile> observabilityFiles;
    private GeneratorRequest generatorRequest;
    private GeneratorResponse generatorResponse;

    @BeforeSuite
    public void uuid_generator_test_before_suite() throws IOException {
        UUID_GENERATOR = new UUIDGenerator();
    }

    @BeforeMethod
    public void uuid_generator_test_before_method() {
        observabilityFiles = new ArrayList<>();
        generatorRequest = new GeneratorRequest();
    }

    @Test(description = "Validate request containing a single valid Cloud Storage file")
    public void validate_single_valid_cloud_files() throws IOException {
        observabilityFiles = observabilityFileFactory
                .include(FOLDER_PATH + VALID_FILE_NAMES[0], false, true)
                .generate();
        createLocalFilesAndUploadToCloudStorage();

        // Generator
        sendRequestAndRetrieveResponse();

        // Validate
        validateGeneratorResponseAndUpdate();
    }

    @Test(description = "Validate request containing multiple valid Cloud Storage file")
    public void validate_multiple_valid_cloud_files() throws IOException {
        observabilityFiles = observabilityFileFactory
                .include(FOLDER_PATH + VALID_FILE_NAMES[0], false, true)
                .include(FOLDER_PATH + VALID_FILE_NAMES[1], false, true)
                .include(FOLDER_PATH + VALID_FILE_NAMES[2], false, true)
                .include(FOLDER_PATH + VALID_FILE_NAMES[3], false, true)
                .generate();
        createLocalFilesAndUploadToCloudStorage();

        // Generator
        sendRequestAndRetrieveResponse();

        // Validate
        validateGeneratorResponseAndUpdate();
    }

    private void validateGeneratorResponseAndUpdate() {
        // UUID only mode
        if (generatorRequest.getUuidOnly().equals(String.valueOf(true))) {
            Assertions.assertThat(generatorResponse.getUuid()).matches(UUID_PATTERN);
        } else {
            Assertions.assertThat(generatorResponse.getUuid()).isNull();

            List<GeneratorResponseFile> responseFiles = generatorResponse.getData();
            Assertions.assertThat(responseFiles.size()).isEqualTo(observabilityFiles.size());

            // Generator response files
            SoftAssertions observabilitiesAssertions = new SoftAssertions();
            for (int fileIndex = 0; fileIndex < responseFiles.size(); fileIndex++) {
                GeneratorResponseFile responseFile = responseFiles.get(fileIndex);
                ObservabilityFile observabilityFile = observabilityFiles.get(fileIndex);

                CloudStoragePathSplitter observabilitySplitter = CloudStoragePathSplitter.splitPath(observabilityFile.getCloudPath());

                // Validate
                observabilitiesAssertions.assertThat(responseFile.getBlob()).isEqualTo(observabilitySplitter.getFileName());
                observabilitiesAssertions.assertThat(responseFile.getUuid()).matches(UUID_PATTERN);

                // Update
                observabilityFile.setUuid(responseFile.getUuid());
            }
            observabilitiesAssertions.assertAll();
        }
    }

    private void createLocalFilesAndUploadToCloudStorage() throws IOException {
        for (ObservabilityFile observabilityFile : observabilityFiles) {
            String localPath = observabilityFile.getLocalPath();
            String cloudPath = observabilityFile.getCloudPath();

            if (observabilityFile.isValid()) {
                LocalFileUtils.createEmptyFile(localPath);

                if (!observabilityFile.hasUuid()) {
                    CloudStorageUtils.uploadFile(localPath, cloudPath);
                    LOG.info("Uploaded observability file to {}", cloudPath);
                } else {
                    String uuid = observabilityFile.getUuid();

                    Map<String, String> metadata = new HashMap<>();
                    metadata.put(UUID_KEY, uuid);

                    CloudStorageUtils.uploadFileWithMetadata(localPath, cloudPath, metadata);
                    LOG.info("Uploaded observability file to {} with {} {}", cloudPath, UUID_KEY, uuid);
                }
            }
        }
    }

    private void sendRequestAndRetrieveResponse() throws IOException {
        generatorRequest.setData(createRequestFromObservabilityFiles());
        generatorResponse = UUID_GENERATOR.execute(generatorRequest);
    }

    private List<GeneratorRequestFile> createRequestFromObservabilityFiles() {
        List<GeneratorRequestFile> generatorRequestFiles = new ArrayList<>();

        for (ObservabilityFile observabilityFile : observabilityFiles) {
            CloudStoragePathSplitter splitter = CloudStoragePathSplitter.splitPath(observabilityFile.getCloudPath());
            generatorRequestFiles.add(new GeneratorRequestFile(splitter.getBucketName(), splitter.getFileName()));
        }

        return generatorRequestFiles;
    }

    @AfterMethod
    public void uuid_generator_test_after_method() throws IOException {
        for (ObservabilityFile observabilityFile : observabilityFiles) {
            CloudStorageUtils.deleteFile(observabilityFile.getCloudPath());
            LocalFileUtils.deleteFile(observabilityFile.getLocalPath());
        }

        LOG.info("Cleaned up all observability files");
    }
}
