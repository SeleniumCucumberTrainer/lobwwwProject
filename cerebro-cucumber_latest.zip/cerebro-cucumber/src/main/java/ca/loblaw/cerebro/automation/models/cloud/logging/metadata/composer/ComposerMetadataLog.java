package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "zone", defaultImpl = ComposerMetadataLog.class, visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = IngestionComposerMetadataLog.class, name="ingestion"),
        @JsonSubTypes.Type(value = CurationComposerMetadataLog.class, name="curation"),
        @JsonSubTypes.Type(value = SnapshotComposerMetadataLog.class, name="snapshot"),
        @JsonSubTypes.Type(value = PublicationComposerMetadataLog.class, name="publication")
})
public class ComposerMetadataLog {
    @JsonProperty("job_run_trace_id")
    private List<String> traceIds;

    @JsonProperty("zone")
    private String zone;

    @JsonProperty("cc_serv_acct_id")
    private String serviceAccount;

    // DAG
    @JsonProperty("cc_dag_nm")
    private String dagName;

    @JsonProperty("cc_dag_run_id")
    private String dagRunId;

    @JsonProperty("cc_dag_execution_strt_tms")
    private String dagExecutionStartTime;

    @JsonProperty("cc_dag_elpsd_tms")
    private String dagElapsedTime;

    @JsonProperty("cc_dag_execution_end_tms")
    private String dagExecutionEndTime;

    @JsonProperty("cc_execution_rslt")
    private String dagExecutionResult;

    @JsonProperty("cc_tbl_rec_cre_tms")
    private String tableRecordCreateTimestamp;

    public List<String> getTraceIds() {
        return traceIds;
    }

    public void setTraceIds(List<String> traceIds) {
        this.traceIds = traceIds;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getServiceAccount() {
        return serviceAccount;
    }

    public void setServiceAccount(String serviceAccount) {
        this.serviceAccount = serviceAccount;
    }

    public String getDagName() {
        return dagName;
    }

    public void setDagName(String dagName) {
        this.dagName = dagName;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public String getDagExecutionStartTime() {
        return dagExecutionStartTime;
    }

    public void setDagExecutionStartTime(String dagExecutionStartTime) {
        this.dagExecutionStartTime = dagExecutionStartTime;
    }

    public String getDagElapsedTime() {
        return dagElapsedTime;
    }

    public void setDagElapsedTime(String dagElapsedTime) {
        this.dagElapsedTime = dagElapsedTime;
    }

    public String getDagExecutionEndTime() {
        return dagExecutionEndTime;
    }

    public void setDagExecutionEndTime(String dagExecutionEndTime) {
        this.dagExecutionEndTime = dagExecutionEndTime;
    }

    public String getDagExecutionResult() {
        return dagExecutionResult;
    }

    public void setDagExecutionResult(String dagExecutionResult) {
        this.dagExecutionResult = dagExecutionResult;
    }

    public String getTableRecordCreateTimestamp() {
        return tableRecordCreateTimestamp;
    }

    public void setTableRecordCreateTimestamp(String tableRecordCreateTimestamp) {
        this.tableRecordCreateTimestamp = tableRecordCreateTimestamp;
    }
}
