package ca.loblaw.cerebro.automation.interactors;

import ca.loblaw.cerebro.automation.models.data.RawFolders;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileContainer;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileFieldOptions;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Test step class to interact with Landing bucket and Raw bucket for the file routing process.
 */
public class FileRoutingStorageManager implements Interactor {

    private static final Logger LOG = LogManager.getLogger(FileRoutingStorageManager.class);
    public static final String[] STAGE_FOLDERS = {"landing", "processed", "rejected", "working"};
    private static final int FILE_COPY_TIMEOUT = 220000;
    private static final int MIN_LANDING_WAIT_TIME_PER_FILE = 12500;

    private final String testFolderPath; // GCS path for folder that stores test files to be copied to landing
    private final String landingFolderPath; // GCS path for PRD-landing folder
    private final String rawFolderPath; // GCS path for raw storage folder after routing
    private final RawFolders rawFolders; // GCS paths for raw storage folders

    // Instances
    private List<String> testFilesToCopyPaths;
    private long timeToWaitForRouting = 0;

    public FileRoutingStorageManager(String testFolderPath, String landingFolderPath, String rawFolderPath, RawFolders rawFolders) {
        this.testFolderPath = testFolderPath;
        this.landingFolderPath = landingFolderPath;
        this.rawFolderPath = rawFolderPath;
        this.rawFolders = rawFolders;
    }

    //------------------------------------------------------------------------------------------------------------------
    // Test Folder
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Retrieve GCS paths of all test files in test folder. This should always be called first.
     * @return List of GCS paths strings
     */
    public List<String> retrieveTestFilesPaths() {
        List<CloudStorageFile> filesToCopy = CloudStorageUtils.listFiles(
                testFolderPath,
                new CloudStorageFileFieldOptions().includeName());
        this.testFilesToCopyPaths = CloudStorageFileContainer.wrap(filesToCopy).toGcsNamesList();

        Reporter.info(LOG, "Test files to copy: {}", testFilesToCopyPaths);
        return testFilesToCopyPaths;
    }

    /**
     * Copies all files in test folder to landing bucket pipeline folder
     */
    public void copyTestFilesToLandingFolder() {
        Assertions.assertThat(testFilesToCopyPaths.size())
                .as("Number of test files to copy")
                .isGreaterThan(0);

        long startingTime = System.currentTimeMillis();
        CloudStorageUtils.copyFolder(testFolderPath, landingFolderPath, false);
        timeToWaitForRouting = System.currentTimeMillis() - startingTime;

        Reporter.info(LOG, "Copied {} test files to landing bucket", testFilesToCopyPaths.size());
    }

    public void waitForLandingFilesToBeRouted() throws InterruptedException {
        if (timeToWaitForRouting != 0) {
            Thread.sleep(timeToWaitForRouting);
        }

        Thread.sleep((long) testFilesToCopyPaths.size() * MIN_LANDING_WAIT_TIME_PER_FILE);
    }

    public void waitForLandingFilesToBeRouted(int numCopies) throws InterruptedException {
        Thread.sleep((long) numCopies * testFilesToCopyPaths.size() * MIN_LANDING_WAIT_TIME_PER_FILE);
    }

    /**
     * Copies all files in test folder to raw bucket landing folder
     */
    public void copyTestFilesToRawFolder() {
        Assertions.assertThat(testFilesToCopyPaths.size())
                .as("Number of test files to copy")
                .isGreaterThan(0);
        CloudStorageUtils.copyFolder(testFolderPath, rawFolders.getLanding(), false);
        Reporter.info(LOG, "Copied {} test files to raw bucket landing folder", testFilesToCopyPaths.size());
    }

    /**
     * Copies all test files, in parallel, to landing folder 'numCopies' of times.
     * The new landing files will have a count appended to the file name.
     *
     * @param numCopies Number of copies.
     * @throws InterruptedException Executor for copying files is interrupted while waiting.
     */
    public void copyTestFilesToLandingFolderMultiple(int numCopies) throws InterruptedException {
        // Find
        Pair<List<String>, List<String>> orderedPathsPair = getCopyAndDestinationPathsPair(testFilesToCopyPaths, numCopies);

        // Copy files from testing bucket multiple times in parallel
        ExecutorService executorService = Executors.newFixedThreadPool(orderedPathsPair.getLeft().size());
        for (int copyIndex = 0; copyIndex < orderedPathsPair.getLeft().size(); copyIndex++) {
            int finalCopyIndex = copyIndex;

            executorService.execute(() -> CloudStorageUtils.copyFile(
                    orderedPathsPair.getLeft().get(finalCopyIndex),
                    orderedPathsPair.getRight().get(finalCopyIndex)
            ));
        }
        executorService.shutdown();
        executorService.awaitTermination(FILE_COPY_TIMEOUT, TimeUnit.MILLISECONDS);

        Reporter.info(LOG, "Copied {} test files to landing bucket", numCopies * testFilesToCopyPaths.size());
    }

    private Pair<List<String>, List<String>> getCopyAndDestinationPathsPair(List<String> testFilesToCopyPaths, int numCopies) {
        List<String> orderedFilesToCopyPaths = new ArrayList<>();
        List<String> orderedDestinationFilesPaths = new ArrayList<>();

        for (int fileIndex = 1; fileIndex <= numCopies; fileIndex++) {
            for (String fileToCopyPath : testFilesToCopyPaths) {
                orderedFilesToCopyPaths.add(fileToCopyPath);
                orderedDestinationFilesPaths.add(convertToSourceFilePath(fileToCopyPath, landingFolderPath, fileIndex));
            }
        }

        Assertions.assertThat(orderedFilesToCopyPaths.size()).isEqualTo(orderedDestinationFilesPaths.size());
        return Pair.of(orderedFilesToCopyPaths, orderedDestinationFilesPaths);
    }

    private String convertToSourceFilePath(String fileToCopyPath, String landingFolderPath, int fileIndex) {
        String localFileName = FilenameUtils.getName(fileToCopyPath);
        String[] localFileNameArr = localFileName.split("\\.", 2);
        String localFileBaseName = localFileNameArr[0];
        String localFileExtension = localFileNameArr[1];

        return landingFolderPath + localFileBaseName + fileIndex + "." + localFileExtension;
    }

    //------------------------------------------------------------------------------------------------------------------
    // Landing Folder
    //------------------------------------------------------------------------------------------------------------------

    /**
     * Lists all Cloud Storage files in landing folder, sorted by file name ascending.
     * @return List of CloudStorageFile representing files in landing folder
     */
    public List<CloudStorageFile> retrieveLandingFilesSorted() {
        List<CloudStorageFile> landingCloudFiles = CloudStorageUtils
                .listFiles(landingFolderPath, new CloudStorageFileFieldOptions().includeName().includeSize().includeMetadata())
                .stream()
                .sorted()
                .collect(Collectors.toList());
        Reporter.info(LOG, "Retrieved {} files from landing bucket", landingCloudFiles.size());
        return landingCloudFiles;
    }

    /**
     * Deletes Cloud Storage landing folder and everything in the folder
     */
    public void cleanLandingFolder() {
        CloudStorageUtils.deleteFolder(landingFolderPath);
        LOG.info("Cleaned landing bucket {}", landingFolderPath);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Raw Folder
    //------------------------------------------------------------------------------------------------------------------

    public List<CloudStorageFile> retrieveRawFiles(String stage) {
        List<CloudStorageFile> rawCloudFiles = CloudStorageUtils.listFiles(
                rawFolders.getFolderFromStage(stage),
                new CloudStorageFileFieldOptions().includeName().includeSize().includeCreateDate().includeMetadata()
        );

        Reporter.info(LOG, "Retrieved {} files from raw bucket '{}' folder", rawCloudFiles.size(), stage);
        return rawCloudFiles;
    }

    /**
     * Finds and retrieves list of all Cloud Storage raw files from their respective landing files.
     * If a raw file is not found, null is added to the list.
     *
     * @param fileNames List of file names to find.
     * @param stages List of stage folders to check in raw zone for routed files.
     * @return List of Cloud Storage raw files.
     */
    public List<CloudStorageFile> findRawCloudFilesFromFileNames(List<String> fileNames, String fileMessage, String... stages) {
        List<String> rawCloudFilesPaths = fileNames.stream()
                .map(fileName -> rawFolderPath + fileName)
                .collect(Collectors.toList());
        return findRawCloudFilesInStages(rawCloudFilesPaths, fileMessage, stages);
    }

    private List<CloudStorageFile> findRawCloudFilesInStages(List<String> rawCloudFilesPaths, String fileMessage, String... stages) {
        List<CloudStorageFile> rawCloudFiles = new ArrayList<>();

        // Cloud Storage file object equivalents from the given raw cloud files paths
        int findCounter = 0;

        outerTargetFilesLoop: for (String rawCloudFilePath : rawCloudFilesPaths) {
            for (String ingestionFolder : stages) {
                if (CloudStorageUtils.doesFileExist(rawCloudFilePath.replace("...", ingestionFolder))) {
                    // File found in a raw folder
                    CloudStorageFile targetFile = CloudStorageUtils.getFile(
                            rawCloudFilePath.replace("...", ingestionFolder),
                            new CloudStorageFileFieldOptions().includeName().includeSize().includeCreateDate().includeMetadata()
                    );
                    rawCloudFiles.add(targetFile);
                    findCounter++;

                    // No need to search other stage folders since raw file can only be in 1 stage folder at a time
                    continue outerTargetFilesLoop;
                }
            }
        }

        String printStages = String.join(",", stages);
        Reporter.info(LOG, "Found {} {} in raw bucket ({})", findCounter, fileMessage, printStages);
        return rawCloudFiles;
    }

    /**
     * Finds and deletes list of all Cloud Storage raw files from a list of file names.
     */
    public void cleanUpRawFolderFiles(List<String> fileNames) {
        for (String fileName : fileNames) {
            String rawCloudFilePath = rawFolderPath + fileName;
            boolean atLeastOneDeleted = false;

            for (String stage : STAGE_FOLDERS) {
                if (CloudStorageUtils.doesFileExist(rawCloudFilePath.replace("...", stage))) {
                    boolean isDeleted = CloudStorageUtils.deleteFile(rawCloudFilePath.replace("...", stage));
                    if (isDeleted) {
                        LOG.info("{} was deleted", fileName);
                        atLeastOneDeleted = true;
                    } else {
                        LOG.warn("{} failed to be deleted", fileName);
                    }
                }
            }

            if (!atLeastOneDeleted) {
                LOG.warn("{} was not found for deletion", fileName);
            }
        }
    }

    public List<String> getTestFilesToCopyPaths() {
        return testFilesToCopyPaths;
    }
}
