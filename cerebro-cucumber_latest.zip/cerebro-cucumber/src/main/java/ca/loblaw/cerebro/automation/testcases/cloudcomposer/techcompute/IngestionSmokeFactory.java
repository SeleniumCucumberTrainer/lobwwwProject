package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

public class IngestionSmokeFactory extends ComposerTechComputeSmokeFactory {

    public IngestionSmokeFactory() {
        super("Ingestion", "ingestion");
    }
}
