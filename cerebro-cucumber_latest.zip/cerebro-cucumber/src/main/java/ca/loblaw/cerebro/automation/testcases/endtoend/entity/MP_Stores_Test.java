package ca.loblaw.cerebro.automation.testcases.endtoend.entity;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "mp-stores", "entity" })
public class MP_Stores_Test extends EndToEndTest {
    public MP_Stores_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/entity/mp_stores.properties");    }
}
