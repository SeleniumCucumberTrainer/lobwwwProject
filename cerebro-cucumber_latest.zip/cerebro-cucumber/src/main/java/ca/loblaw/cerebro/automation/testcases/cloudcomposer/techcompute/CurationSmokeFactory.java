package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

public class CurationSmokeFactory extends ComposerTechComputeSmokeFactory {

    public CurationSmokeFactory() {
        super("Curation", "curation");
    }
}
