package ca.loblaw.cerebro.automation.steps.endtoend;

import ca.loblaw.cerebro.automation.steps.Validator;
import ca.loblaw.cerebro.automation.utils.cloud.datastore.DatastoreService;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.google.cloud.datastore.Entity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;

import java.util.List;
import java.util.stream.Collectors;

public class ControlFlowValidator implements Validator {

    private static final Logger LOG = LogManager.getLogger(ControlFlowValidator.class);

    public static void validateDataflowControlFlowInsert(String sourceRecCreTms, String sourceTable, String sourceLayer,
                                                         String targetTable, String targetLayer) {
        // Find control flow entity inserted
        List<Entity> entityList = new DatastoreService.QueryBuilder()
                .newBuilder()
                .setNamespace("cerebro_master")
                .setKind("control_flow_pipelines")
                .addEqualFilter("src_rec_cre_tms", sourceRecCreTms)
                .addEqualFilter("trgt_ds_tbl_nm", targetTable)
                .queryToList();

        Assertions.assertThat(entityList.size())
                .as("Number of control flow entities inserted")
                .isEqualTo(1);
        Reporter.pass(LOG, "Only 1 control flow entity was inserted");

        // Validate entity
        Entity insertFlowControl = entityList.get(0);
        SoftAssertions entityAssertions = new SoftAssertions();

        entityAssertions.assertThat(insertFlowControl.getString("src_ds_tbl_nm"))
                .as("src_ds_tbl_nm")
                .isEqualTo(sourceTable);

        entityAssertions.assertThat(insertFlowControl.getString("src_data_layer_nm"))
                .as("src_data_layer_nm")
                .isEqualTo(sourceLayer);

        entityAssertions.assertThat(insertFlowControl.getString("trgt_ds_tbl_nm"))
                .as("trgt_ds_tbl_nm")
                .isEqualTo(targetTable);

        entityAssertions.assertThat(insertFlowControl.getString("trgt_data_layer_nm"))
                .as("trgt_data_layer_nm")
                .isEqualTo(targetLayer);

        entityAssertions.assertThat((int) insertFlowControl.getLong("status"))
                .as("status")
                .isEqualTo(0);

        entityAssertions.assertAll();
        Reporter.pass(LOG, "Inserted entity is valid");
    }

    public static void validateDataflowControlFlowInsertOneToMany(String sourceRecCreTms, String sourceTable, String sourceLayer,
                                                                  String[] targetTables, String targetLayer) {
        // Find control flow entity inserted
        List<Entity> entityList = new DatastoreService.QueryBuilder()
                .newBuilder()
                .setNamespace("cerebro_master")
                .setKind("control_flow_pipelines")
                .addEqualFilter("src_rec_cre_tms", sourceRecCreTms)
                .queryToList();

        Assertions.assertThat(entityList.size())
                .as("Number of control flow entities inserted")
                .isEqualTo(targetTables.length);
        Reporter.pass(LOG, "Only {} control flow entities were inserted", targetTables.length);

        // Validate entity
        SoftAssertions entityAssertions = new SoftAssertions();
        for (Entity insertFlowControl : entityList) {
            // Source dataset table name
            entityAssertions.assertThat(insertFlowControl.getString("src_ds_tbl_nm"))
                    .as("src_ds_tbl_nm")
                    .isEqualTo(sourceTable);

            // Source data layer name
            entityAssertions.assertThat(insertFlowControl.getString("src_data_layer_nm"))
                    .as("src_data_layer_nm")
                    .isEqualTo(sourceLayer);

            // Target dataset table name
            entityAssertions.assertThat(targetTables)
                    .as("trgt_ds_tbl_nm")
                    .contains(insertFlowControl.getString("trgt_ds_tbl_nm"));

            // Target data layer name
            entityAssertions.assertThat(insertFlowControl.getString("trgt_data_layer_nm"))
                    .as("trgt_data_layer_nm")
                    .isEqualTo(targetLayer);

            // Status
            entityAssertions.assertThat((int) insertFlowControl.getLong("status"))
                    .as("status")
                    .isEqualTo(0);
        }
        entityAssertions.assertAll();
        Reporter.pass(LOG, "Inserted entities are valid");
    }

    public static void validateDatastoreControlFlowUpdate(String sourceRecCreTms, String sourceTable, String sourceLayer,
                                                          String targetRecCreTms, String targetTable, String targetLayer) {
        List<Entity> entityList = new DatastoreService.QueryBuilder()
                .newBuilder()
                .setNamespace("cerebro_master")
                .setKind("control_flow_pipelines")
                .addEqualFilter("trgt_rec_cre_tms", targetRecCreTms)
                .addEqualFilter("trgt_ds_tbl_nm", targetTable)
                .queryToList();

        Assertions.assertThat(entityList.size())
                .as("Number of control flow entities found and updated")
                .isEqualTo(1);
        Reporter.pass(LOG, "Only 1 control flow entity was found and updated");

        // Validate entity
        Entity updateControlFlow = entityList.get(0);
        SoftAssertions entityAssertions = new SoftAssertions();

        entityAssertions.assertThat(updateControlFlow.getString("src_ds_tbl_nm"))
                .as("src_ds_tbl_nm")
                .isEqualTo(sourceTable);

        entityAssertions.assertThat(updateControlFlow.getString("src_data_layer_nm"))
                .as("src_data_layer_nm")
                .isEqualTo(sourceLayer);

        entityAssertions.assertThat(updateControlFlow.getString("src_rec_cre_tms"))
                .as("src_rec_cre_tms")
                .isEqualTo(sourceRecCreTms);

        entityAssertions.assertThat(updateControlFlow.getString("trgt_ds_tbl_nm"))
                .as("trgt_ds_tbl_nm")
                .isEqualTo(targetTable);

        entityAssertions.assertThat(updateControlFlow.getString("trgt_data_layer_nm"))
                .as("trgt_data_layer_nm")
                .isEqualTo(targetLayer);

        entityAssertions.assertThat((int) updateControlFlow.getLong("status"))
                .as("status")
                .isEqualTo(1);

        entityAssertions.assertAll();
        Reporter.pass(LOG, "Updated entity is valid");
    }

    public static void validateDatastoreControlFlowUpdateOneToMany(String sourceRecCreTms, String sourceTable, String sourceLayer,
                                                                   String targetRecCreTms, String[] targetTables, String targetLayer) {
        List<Entity> entityList = new DatastoreService.QueryBuilder()
                .newBuilder()
                .setNamespace("cerebro_master")
                .setKind("control_flow_pipelines")
                .addEqualFilter("trgt_rec_cre_tms", targetRecCreTms)
                .queryToList();

        Assertions.assertThat(entityList.size())
                .as("Number of control flow entities found and updated")
                .isEqualTo(targetTables.length);
        Reporter.pass(LOG, "Only {} control flow entities were found and updated", targetTables.length);

        // Validate entity
        SoftAssertions entityAssertions = new SoftAssertions();

        for (Entity updateFlowControl : entityList) {
            entityAssertions.assertThat(updateFlowControl.getString("src_ds_tbl_nm"))
                    .as("src_ds_tbl_nm")
                    .isEqualTo(sourceTable);

            entityAssertions.assertThat(updateFlowControl.getString("src_data_layer_nm"))
                    .as("src_data_layer_nm")
                    .isEqualTo(sourceLayer);

            entityAssertions.assertThat(updateFlowControl.getString("src_rec_cre_tms"))
                    .as("src_rec_cre_tms")
                    .isEqualTo(sourceRecCreTms);

            entityAssertions.assertThat(targetTables)
                    .as("trgt_ds_tbl_nm")
                    .contains(updateFlowControl.getString("trgt_ds_tbl_nm"));

            entityAssertions.assertThat(updateFlowControl.getString("trgt_data_layer_nm"))
                    .as("trgt_data_layer_nm")
                    .isEqualTo(targetLayer);

            entityAssertions.assertThat((int) updateFlowControl.getLong("status"))
                    .as("status")
                    .isEqualTo(1);
        }

        entityAssertions.assertAll();
        Reporter.pass(LOG, "Updated entities are valid");
    }
}
