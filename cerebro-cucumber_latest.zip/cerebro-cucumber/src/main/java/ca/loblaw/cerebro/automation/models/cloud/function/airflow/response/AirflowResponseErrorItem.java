package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AirflowResponseErrorItem {

    @JsonProperty("detail")
    private String detail;

    @JsonProperty("status")
    private int status;

    @JsonProperty("title")
    private String title;

    @JsonProperty("type")
    private String type;

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
