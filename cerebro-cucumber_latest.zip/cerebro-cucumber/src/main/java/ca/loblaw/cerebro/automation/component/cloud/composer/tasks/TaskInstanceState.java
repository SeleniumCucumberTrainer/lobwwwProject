package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

import java.util.HashSet;
import java.util.Set;

/**
 * Apache Airflow states for task instances.
 */
public enum TaskInstanceState {
    DEFERRED("deferred"),
    FAILED("failed"),
    QUEUED("queued"),
    RESTARTING("restarting"),
    REMOVED("removed"),
    RUNNING("running"),
    SCHEDULED("scheduled"),
    SKIPPED("skipped"),
    SUCCESS("success"),
    UP_FOR_RETRY("up_for_retry"),
    UP_FOR_RESCHEDULE("up_for_reschedule"),
    UPSTREAM_FAILED("upstream_failed");

    public static final Set<TaskInstanceState> FINISHED_STATES = new HashSet<TaskInstanceState>() {{
        add(FAILED);
        add(REMOVED);
        add(SUCCESS);
        add(SKIPPED);
        add(UPSTREAM_FAILED);
    }};

    private final String state;

    TaskInstanceState(String state) {
        this.state = state;
    }

    public static TaskInstanceState from(String stateValue) {
        if (stateValue == null) {
            return null;
        }

        for (TaskInstanceState taskInstanceState : TaskInstanceState.values()) {
            if (taskInstanceState.getState().equals(stateValue)) {
                return taskInstanceState;
            }
        }

        throw new EnumConstantNotPresentException(TaskInstanceState.class, stateValue);
    }

    public String getState() {
        return state;
    }

    @Override
    public String toString() {
        return this.state;
    }
}
