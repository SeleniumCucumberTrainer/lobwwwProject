package ca.loblaw.cerebro.automation.steps;

/**
 * Any class defining this interface is expected to have validation methods that uses
 * Assertions and/or SoftAssertions
 */
public interface Validator {

}
