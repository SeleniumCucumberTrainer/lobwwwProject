package ca.loblaw.cerebro.automation.models.cloud.dataflow;

public class DataflowResults {

    private final long inputCount;
    private final long recordCount;
    private final long errorCount;

    public DataflowResults(long inputCount, long recordCount, long errorCount) {
        this.inputCount = inputCount;
        this.recordCount = recordCount;
        this.errorCount = errorCount;
    }

    public long getInputCount() {
        return inputCount;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public long getErrorCount() {
        return errorCount;
    }
}
