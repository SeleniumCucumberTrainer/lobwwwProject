package ca.loblaw.cerebro.automation.listeners;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.annotations.*;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 * Listener module that executes before or after a TestNG configuration method
 */
public class ConfigListener extends TestListenerAdapter {

    private static final Logger LOG = LogManager.getLogger(ConfigListener.class);

    @Override
    public void onConfigurationFailure(ITestResult itr) {
        Method configMethod = itr.getMethod().getConstructorOrMethod().getMethod();

        String configStr = "Unknown Configuration";
        if (isConfigType(configMethod, BeforeSuite.class)) {
            configStr = "@BeforeSuite";
        } else if (isConfigType(configMethod, BeforeTest.class)) {
            configStr = "@BeforeTest";
        } else if (isConfigType(configMethod, BeforeClass.class)) {
            configStr = "@BeforeClass";
        } else if (isConfigType(configMethod, BeforeMethod.class)) {
            configStr = "@BeforeMethod";
        } else if (isConfigType(configMethod, AfterSuite.class)) {
            configStr = "@AfterSuite";
        } else if (isConfigType(configMethod, AfterTest.class)) {
            configStr = "@AfterTest";
        } else if (isConfigType(configMethod, AfterClass.class)) {
            configStr = "@AfterClass";
        } else if (isConfigType(configMethod, AfterMethod.class)) {
            configStr = "@AfterMethod";
        }

        LOG.error(configStr + " -- ", itr.getThrowable());
    }

    public boolean isConfigType(Method configMethod, Class<? extends Annotation> annotationClass) {
        return configMethod.getAnnotation(annotationClass) != null;
    }
}
