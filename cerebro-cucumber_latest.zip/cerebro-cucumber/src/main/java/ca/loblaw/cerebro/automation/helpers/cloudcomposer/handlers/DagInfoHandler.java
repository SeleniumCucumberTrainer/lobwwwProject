package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseDag;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;

public class DagInfoHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem responseItem, DagRun dagRun) {
        AirflowResponseDag responseDag = (AirflowResponseDag) responseItem;

        // Update
        dagRun.setPaused(responseDag.isPaused());
    }

}
