package ca.loblaw.cerebro.automation.testcases.endtoend.product;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;
@Test(groups = { "apprl-delv-seas-cost", "product" })
public class Apprl_Delv_Seas_Cost_Test extends EndToEndTest {
    public Apprl_Delv_Seas_Cost_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/product/apprl_delv_seas_cost.properties");
    }
}
