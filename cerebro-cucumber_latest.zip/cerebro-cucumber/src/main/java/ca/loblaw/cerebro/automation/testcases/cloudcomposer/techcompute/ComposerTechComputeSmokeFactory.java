package ca.loblaw.cerebro.automation.testcases.cloudcomposer.techcompute;

import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.component.cloud.function.DagsListFunction;
import ca.loblaw.cerebro.automation.testcases.cloudcomposer.ComposerSmokeFactory;
import ca.loblaw.cerebro.automation.utils.contexts.Project;

import java.io.IOException;

public abstract class ComposerTechComputeSmokeFactory extends ComposerSmokeFactory {
    private static final String DAGS_LIST_PROPERTIES = "src/main/resources/setup/cloudcomposer/techcompute/dagsListFunction.properties";
    private static final DagsListFunction DAGS_LIST_FUNCTION;

    static {
        try {
            DAGS_LIST_FUNCTION = DagsListFunction.fromPropertiesFile(DAGS_LIST_PROPERTIES);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ComposerTechComputeSmokeFactory(String outputSheetName, String filter) {
        super(
                DAGS_LIST_FUNCTION,
                Project.TECHCOMPUTE_ZONE,
                "TechComputeDAGs",
                outputSheetName,
                filter
        );
    }
}
