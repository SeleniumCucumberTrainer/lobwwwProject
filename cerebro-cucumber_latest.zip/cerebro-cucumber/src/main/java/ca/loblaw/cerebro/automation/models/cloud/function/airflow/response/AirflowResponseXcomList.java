package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class AirflowResponseXcomList extends AirflowResponseItem {

    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("dag_run_id")
    private String dagRunId;

    @JsonProperty("task_id")
    private String taskId;

    @JsonProperty("xcom_entries")
    private List<String> xcomEntries;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public List<String> getXcomEntries() {
        return xcomEntries;
    }

    public void setXcomEntries(List<String> xcomEntries) {
        this.xcomEntries = xcomEntries;
    }
}
