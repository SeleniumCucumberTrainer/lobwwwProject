package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class AirflowResponseTaskInstances extends AirflowResponseItem {
    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("dag_run_id")
    private String dagRunId;

    @JsonProperty("task_instances")
    private List<AirflowResponseTaskInstanceItem> taskList;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public String getDagRunId() {
        return dagRunId;
    }

    public void setDagRunId(String dagRunId) {
        this.dagRunId = dagRunId;
    }

    public List<AirflowResponseTaskInstanceItem> getTaskList() {
        return taskList;
    }

    public void setTaskList(List<AirflowResponseTaskInstanceItem> taskList) {
        this.taskList = taskList;
    }
}
