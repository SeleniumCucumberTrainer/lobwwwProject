package ca.loblaw.cerebro.automation.models.cloud.logging.metadata.composer;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SnapshotComposerMetadataLog extends ComposerMetadataLog {

    @JsonProperty("cc_src_nm")
    private String sourceName;
    @JsonProperty("cc_tgt_nm")
    private String targetName;

    @JsonProperty("cc_no_rows_loaded")
    private String numberRowLoaded;

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
    }

    public String getNumberRowLoaded() {
        return numberRowLoaded;
    }

    public void setNumberRowLoaded(String numberRowLoaded) {
        this.numberRowLoaded = numberRowLoaded;
    }
}
