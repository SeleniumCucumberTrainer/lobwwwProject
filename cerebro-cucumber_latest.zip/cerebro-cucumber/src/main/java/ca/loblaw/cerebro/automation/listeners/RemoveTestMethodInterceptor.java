package ca.loblaw.cerebro.automation.listeners;

import ca.loblaw.cerebro.automation.annotations.Remove;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import org.testng.IMethodInstance;
import org.testng.IMethodInterceptor;
import org.testng.ITestContext;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

public class RemoveTestMethodInterceptor implements IMethodInterceptor {
    @Override
    public List<IMethodInstance> intercept(List<IMethodInstance> fullMethodInstances, ITestContext testContext) {
        List<IMethodInstance> finalMethodInstances = new ArrayList<>();

        Map<Object, List<IMethodInstance>> instanceMap = fullMethodInstances.stream()
                .collect(Collectors.groupingBy((IMethodInstance::getInstance)));

        for (Object instance : instanceMap.keySet()) {
            BaseTest baseTest = (BaseTest) instance;
            Set<String> removeConditions = baseTest.getRemoveConditions();
            List<IMethodInstance> methodInstances = instanceMap.get(instance);

            // Case 1: No ignore tests Set
            if (baseTest.getRemoveConditions().isEmpty()) {
                finalMethodInstances.addAll(methodInstances);
                continue;
            }

            // Case 2: Test methods to remove
            for (IMethodInstance methodInstance : methodInstances) {
                Method method = methodInstance.getMethod().getConstructorOrMethod().getMethod();
                if (!method.isAnnotationPresent(Remove.class)) {
                    finalMethodInstances.add(methodInstance);
                    continue;
                }

                // Remove test method from final execution if @Remove condition in ignore tests set
                Remove removeAnnotation = method.getAnnotation(Remove.class);
                if (removeConditions.contains(removeAnnotation.condition())) {
                    continue;
                }

                finalMethodInstances.add(methodInstance);
            }
        }
        return finalMethodInstances;
    }
}
