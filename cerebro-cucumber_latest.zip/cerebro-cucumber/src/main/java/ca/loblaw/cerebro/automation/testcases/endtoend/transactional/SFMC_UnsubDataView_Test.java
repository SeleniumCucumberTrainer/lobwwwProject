package ca.loblaw.cerebro.automation.testcases.endtoend.transactional;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;
@Test(groups = { "sfmc-unsubdataview", "transactional" })
public class SFMC_UnsubDataView_Test extends EndToEndTest {
    public SFMC_UnsubDataView_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/transactional/sfmc_unsubdataview.properties");
    }
}
