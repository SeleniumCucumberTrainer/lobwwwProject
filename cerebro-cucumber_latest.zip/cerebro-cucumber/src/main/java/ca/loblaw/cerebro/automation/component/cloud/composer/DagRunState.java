package ca.loblaw.cerebro.automation.component.cloud.composer;

import java.util.HashSet;
import java.util.Set;

/**
 * Apache Airflow states for DAG runs.
 */
public enum DagRunState {
    SUCCESS("success"),
    FAILED("failed"),
    RUNNING("running"),
    QUEUED("queued");

    public static final Set<DagRunState> FINISHED_STATES = new HashSet<DagRunState>() {{
        add(FAILED);
        add(SUCCESS);
    }};

    private final String state;

    DagRunState(String state) {
        this.state = state;
    }

    public static DagRunState from(String stateValue) {
        if (stateValue == null) {
            return null;
        }

        for (DagRunState dagRunState : DagRunState.values()) {
            if (dagRunState.getState().equals(stateValue)) {
                return dagRunState;
            }
        }

        throw new EnumConstantNotPresentException(DagRunState.class, stateValue);
    }

    public String getState() {
        return state;
    }

    @Override
    public String toString() {
        return this.state;
    }
}
