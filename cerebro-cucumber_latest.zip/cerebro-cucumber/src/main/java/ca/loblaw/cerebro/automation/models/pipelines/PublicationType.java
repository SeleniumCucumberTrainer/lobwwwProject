package ca.loblaw.cerebro.automation.models.pipelines;

public enum PublicationType {
    DELTA_TRUNCATE,
    DELTA_HIST,
    CURR_HIST,
    OTHER;

    public static PublicationType from(String stateValue) {
        if (stateValue == null) {
            return null;
        }

        for (PublicationType publicationType : PublicationType.values()) {
            if (publicationType.name().equals(stateValue)) {
                return publicationType;
            }
        }

        throw new EnumConstantNotPresentException(PublicationType.class, stateValue);
    }
}
