package ca.loblaw.cerebro.automation.models.cloud.bigquery;

public class TotalStats {
    private long insertedCount = 0;
    private long deletedCount = 0;

    public long getInsertedCount() {
        return insertedCount;
    }

    public void addInsertedCount(long insertedCount) {
        this.insertedCount += insertedCount;
    }

    public void addDeletedCount(long deletedCount) {
        this.deletedCount += deletedCount;
    }

    public long getDeletedCount() {
        return deletedCount;
    }
}
