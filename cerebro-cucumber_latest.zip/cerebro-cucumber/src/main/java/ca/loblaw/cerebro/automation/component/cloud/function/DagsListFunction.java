package ca.loblaw.cerebro.automation.component.cloud.function;

import ca.loblaw.cerebro.automation.models.cloud.function.dagslist.request.DagsListRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.dagslist.response.DagsListResponse;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunction;
import ca.loblaw.cerebro.automation.utils.cloud.function.CloudFunctionHttpResponse;
import ca.loblaw.cerebro.automation.utils.internal.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class DagsListFunction extends CloudFunctionComponent<DagsListRequest, DagsListResponse> {

    private static final Logger LOG = LogManager.getLogger(DagsListFunction.class);

    public static DagsListFunction fromPropertiesFile(String propertiesFilePath) throws IOException {
        return new DagsListFunction(new CloudFunction.Builder().fromPropertiesFile(propertiesFilePath).build());
    }

    public DagsListFunction(CloudFunction cloudFunction) {
        super(cloudFunction);
    }

    @Override
    public DagsListResponse execute(DagsListRequest dagsListRequest) throws IOException {
        // Request JSON string
        String requestJson = JsonUtils.writeObjectToString(dagsListRequest);
        LOG.debug("DAGs list request JSON:\n{}", JsonUtils.prettyFormat(requestJson));

        // Trigger Cloud Function
        CloudFunctionHttpResponse cloudFunctionHttpResponse = getCloudFunction().trigger(requestJson);

        // Response JSON string
        String responseJson = cloudFunctionHttpResponse.getResponseString();
        LOG.debug("DAGs list response JSON:\n{}", JsonUtils.prettyFormat(responseJson));

        return JsonUtils.readStringToObject(responseJson, DagsListResponse.class);
    }

    @Override
    public void validateRequestJson(JsonNode requestJsonNode) {

    }

    @Override
    public void validateResponseJson(JsonNode responseJsonNode) {

    }

}