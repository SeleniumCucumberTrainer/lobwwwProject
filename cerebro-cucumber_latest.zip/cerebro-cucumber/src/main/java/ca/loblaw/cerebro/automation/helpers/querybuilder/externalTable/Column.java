package ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable;

import ca.loblaw.cerebro.automation.helpers.querybuilder.functions.SQLFunction;

import java.util.ArrayList;
import java.util.List;

public class Column {
    private String name;
    private String dataType;
    private String alias;
    private Partitioned isPartitioningColumn;
    private List<SQLFunction> functions;

    public Column(){
        this.functions = new ArrayList<>();
    }
    public Column(Column column){
        this.functions = new ArrayList<>();
        this.name = column.getName();
        this.dataType = column.getDataType();
        this.alias = column.getAlias();
        this.isPartitioningColumn = column.getIsPartitioningColumn();
    }

    public enum Partitioned {
        YES,
        NO;

        public String getPartitioned() {
            return this.name();
        }
    }

    public String getName() {
        return name;
    }

    public Column setName(String name) {
        this.name = name;
        return this;
    }

    public String getDataType() {
        return dataType;
    }

    public Column setDataType(String dataType) {
        this.dataType = dataType;
        return this;
    }

    public Partitioned getIsPartitioningColumn() {
        return isPartitioningColumn;
    }

    public Column setIsPartitioningColumn(Partitioned isPartitioningColumn) {
        this.isPartitioningColumn = isPartitioningColumn;
        return this;
    }

    public String getAlias() {
        if(alias == null)
            return " AS " + getName();

        if(alias.isEmpty())
            return " AS " + getName();

        return " AS " + alias;
    }

    public Column setAlias(String alias) {
        this.alias = alias;
        return this;
    }

    public Column applyFunction(SQLFunction function){
        this.functions.add(function);
        return this;
    }

    public List<SQLFunction> getFunctions(){
        return this.functions;
    }

    public Column setFunctions(List<SQLFunction> functions) {
        this.functions = functions;
        return this;
    }

    public boolean hasFunctionsApplied(){
        return !this.functions.isEmpty();
    }

    public String getNameWithFunctionsApplied(){
        Column col = new Column(this);
        for (SQLFunction function : functions) {
            col.setName(function.build(col));
        }
        return col.getName();
    }
}
