package ca.loblaw.cerebro.automation.utils.cloud.storage;

import com.google.cloud.storage.Blob;

import java.util.Comparator;
import java.util.Map;

/**
 * Representational class for a Cloud Storage Blob.
 */
public class CloudStorageFile implements Comparable<CloudStorageFile>{

    private String name; // Full GCS path
    private Long size;
    private Long createTime;
    private Map<String, String> metadata;

    /**
     * Creates a CloudStorageFile from a Blob.
     *
     * @param blob Cloud Storage blob.
     * @return CloudStorageFile representation.
     */
    public static CloudStorageFile from(Blob blob) {
        return new CloudStorageFile(
                String.format("gs://%s/%s", blob.getBucket(), blob.getName()),
                blob.getSize(),
                blob.getCreateTime(),
                blob.getMetadata()
        );
    }

    private CloudStorageFile(String name, Long size, Long createTime, Map<String, String> metadata) {
        this.name = name;
        this.size = size;
        this.createTime = createTime;
        this.metadata = metadata;
    }

    public String getName() {
        return name;
    }

    public Long getSize() {
        return size;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public CloudStorageFile setName(String name) {
        this.name = name;
        return this;
    }

    public CloudStorageFile setSize(Long size) {
        this.size = size;
        return this;
    }

    public CloudStorageFile setCreateTime(Long createTime) {
        this.createTime = createTime;
        return this;
    }

    public CloudStorageFile setMetadata(Map<String, String> metadata) {
        this.metadata = metadata;
        return this;
    }

    /**
     * Compare to another CloudStorageFile by name. Default comparator.
     */
    @Override
    public int compareTo(CloudStorageFile other) {
        return getName().compareTo(other.getName());
    }

    // Comparators

    /**
     * Compare to another CloudStorageFile by create time.
     */
    public static class CreateTimeComparator implements Comparator<CloudStorageFile> {
        @Override
        public int compare(CloudStorageFile o1, CloudStorageFile o2) {
            return o1.getCreateTime().compareTo(o2.getCreateTime());
        }
    }

    /**
     * Compare to another CloudStorageFile by file size.
     */
    public static class SizeComparator implements Comparator<CloudStorageFile> {
        @Override
        public int compare(CloudStorageFile o1, CloudStorageFile o2) {
            return o1.getSize().compareTo(o2.getSize());
        }
    }

}
