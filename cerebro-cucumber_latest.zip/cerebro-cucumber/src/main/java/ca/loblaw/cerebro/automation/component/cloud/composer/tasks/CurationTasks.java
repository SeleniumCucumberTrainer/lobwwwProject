package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

public class CurationTasks {

    public static final String GET_TARGET_TABLE = "get_trgt_tbl";
    public static final String GET_JOB_RUN_TRACE_ID = "get_job_run_trace_id";
    public static final String GET_REC_CRE_TMS = "get_rec_cre_tms";
    public static final String CHECK_CURATION = "check_curation";
    public static final String READ_PROPERTY = "read_property";
    public static final String ADD_TMS_PROPERTY = "add_tms_property";
    public static final String GET_CURRENT_TMS = "get_cur_tms";
    public static final String GET_TABLES_SQL = "get_tables_sql";
    public static final String TRIGGER_DATAFLOW_JOB = "trigger_dataflow_job";
    public static final String METADATA_LOG = "metadata_log";
    public static final String UPDATE_FLOW_CONTROL = "update_flow_control";
    public static final String INSERT_TO_CONTROL = "insert_to_control";
    public static final String TRIGGER_PUBLICATION = "trigger_publication";
}
