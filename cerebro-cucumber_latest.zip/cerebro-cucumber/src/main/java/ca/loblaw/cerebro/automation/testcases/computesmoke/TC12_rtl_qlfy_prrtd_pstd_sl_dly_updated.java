package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"rtl_qlfy_prrtd_pstd_sl_dly__ct_updated","TechComputeSmoke"})
public class TC12_rtl_qlfy_prrtd_pstd_sl_dly_updated extends TechComputeCommonFun{
    public TC12_rtl_qlfy_prrtd_pstd_sl_dly_updated() throws IOException {
        super("TC12_rtl_qlfy_prrtd_pstd_sl_dly_updatedTestData.properties");
    }

}
