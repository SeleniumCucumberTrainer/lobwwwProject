package ca.loblaw.cerebro.automation.utils.cloud.datastore;

import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.datastore.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class DatastoreService {

    private static final Datastore DATASTORE;

    static {
        try {
            DATASTORE = DatastoreOptions.newBuilder()
                    .setCredentials(
                            ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS"))))
                    .build()
                    .getService();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private DatastoreService() {}

    public static class QueryBuilder {

        private EntityQuery.Builder queryBuilder;
        private List<StructuredQuery.Filter> currentFilters = new LinkedList<>();

        public QueryBuilder() {}

        public QueryBuilder newBuilder() {
            queryBuilder = Query.newEntityQueryBuilder();
            return this;
        }

        public QueryBuilder setNamespace(String namespace) {
            queryBuilder.setNamespace(namespace);
            return this;
        }

        public QueryBuilder setKind(String kind) {
            queryBuilder.setKind(kind);
            return this;
        }

        public QueryBuilder addEqualFilter(String key, String value) {

            currentFilters.add(StructuredQuery.PropertyFilter.eq(key, value));

            if (currentFilters.size() == 1) {
                queryBuilder.setFilter(currentFilters.get(0));
            } else {
                queryBuilder.setFilter(StructuredQuery.CompositeFilter
                        .and(
                                currentFilters.get(0),
                                currentFilters.stream().skip(1).toArray(StructuredQuery.Filter[]::new)
                        )
                );
            }
            return this;
        }

        public QueryBuilder orderByDesc(String key) {
            queryBuilder.addOrderBy(StructuredQuery.OrderBy.desc(key));
            return this;
        }

        public QueryBuilder orderByAsc(String key) {
            queryBuilder.addOrderBy(StructuredQuery.OrderBy.asc(key));
            return this;
        }

        public QueryResults<Entity> query() {
            QueryResults<Entity> queryResults = DATASTORE.run(queryBuilder.build());
            queryBuilder = null;

            return queryResults;
        }

        public List<Entity> queryToList() {
            List<Entity> entityList = new ArrayList<>();
            QueryResults<Entity> queryResults = query();

            queryResults.forEachRemaining(entityList::add);

            return entityList;
        }
    }
}
