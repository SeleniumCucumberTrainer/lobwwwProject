package ca.loblaw.cerebro.automation.models.cloud.function.uuid.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GeneratorResponseFile {

    @JsonProperty("target_blob")
    private String blob;

    @JsonProperty("uuid")
    @JsonAlias( {"uuid-exp", "uuid-val"})
    private String uuid;

    public GeneratorResponseFile() {}

    public GeneratorResponseFile(String blob, String uuid) {
        this.blob = blob;
        this.uuid = uuid;
    }

    public String getBlob() {
        return blob;
    }

    public void setBlob(String blob) {
        this.blob = blob;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

}
