package ca.loblaw.cerebro.automation.testcases.cloudcomposer;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.function.DagsListFunction;
import ca.loblaw.cerebro.automation.models.cloud.function.dagslist.request.DagsListRequest;
import ca.loblaw.cerebro.automation.models.cloud.function.dagslist.request.DagsListRequestFilter;
import ca.loblaw.cerebro.automation.models.cloud.function.dagslist.response.DagsListResponse;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.internal.ExcelReader;
import ca.loblaw.cerebro.automation.utils.reports.excel.ComposerDagRunExcelReportGenerator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;

public class ComposerSmokeFactory {

    private static final Logger LOG = LogManager.getLogger(ComposerSmokeFactory.class);
    private static final ConcurrentHashMap<String, ConcurrentLinkedQueue<DagRun>> DAG_RUNS_FACTORY_MAP = new ConcurrentHashMap<>();
    private static final List<String> DAG_RUN_HEADERS = Arrays.asList(
            "DAG ID", "Is Paused", "DAG Run ID", "State", "Error", "Tasks Instances");

    // Factory details
    private final DagsListFunction dagsListFunction;
    private final String outputExcelName;
    private final String outputSheetName;
    private final Project project;
    private final String filter;

    public ComposerSmokeFactory(DagsListFunction dagsListFunction, Project project,
                                String outputExcelName, String outputSheetName, String filter) {
        this.dagsListFunction = dagsListFunction;
        this.project = project;
        this.outputExcelName = outputExcelName;
        this.outputSheetName = outputSheetName;
        this.filter = filter;
    }

    public static ConcurrentLinkedQueue<DagRun> getDagRunsQueue(String sheetName) {
        return DAG_RUNS_FACTORY_MAP.get(sheetName);
    }

    @Factory
    public Object[] createComposerTechComputeSmokeTests() throws IOException {
        DagsListRequest dagsListRequest = new DagsListRequest(new DagsListRequestFilter(null, null, filter));
        DagsListResponse dagsListResponse = dagsListFunction.execute(dagsListRequest);
        List<String> dagsList = dagsListResponse.getDagsList();

        DAG_RUNS_FACTORY_MAP.put(outputSheetName, new ConcurrentLinkedQueue<>());

        return dagsList.stream()
                .filter(dagId -> !dagId.isEmpty())
                .map(dagId -> ComposerSmokeTest.fromProject(project, dagId, outputSheetName))
                .toArray();
    }

    @AfterSuite(alwaysRun = true)
    public void composer_smoke_factory_after_suite() throws IOException {
        LOG.info("Generating {} result excel", outputExcelName);

        ComposerDagRunExcelReportGenerator composerDagRunExcelReportGenerator = new ComposerDagRunExcelReportGenerator();
        composerDagRunExcelReportGenerator.setReportPath("composer-reports/", outputExcelName);

        // Create Excel sheet for each DAG runs queue
        for (String sheetName : DAG_RUNS_FACTORY_MAP.keySet()) {
            LOG.info("DAG runs for '{}' has size {}", sheetName, DAG_RUNS_FACTORY_MAP.get(sheetName).size());
            List<DagRun> totalDags = DAG_RUNS_FACTORY_MAP.get(sheetName).stream()
                    .sorted(Comparator.comparing(DagRun::getDagId))
                    .collect(Collectors.toList());
            Set<DagRun> checkedDags = new HashSet<>();
            List<DagRun> excelResultDags = new ArrayList<>();

            for (DagRun dagRun : totalDags) {
                if (!dagRun.hasUpstreamDag()) {
                    exportDownstreamDags(checkedDags, excelResultDags, dagRun);
                }
            }

            composerDagRunExcelReportGenerator.setSheetName(sheetName);
            composerDagRunExcelReportGenerator.reportResults(DAG_RUN_HEADERS, excelResultDags);
        }

        composerDagRunExcelReportGenerator.writeToFileAndClose();
    }

    private void exportDownstreamDags(Set<DagRun> checkedDags, List<DagRun> excelResultDags, DagRun dagRun) {
        if (checkedDags.contains(dagRun)) {
            return;
        }

        // Add to result list and report downstream DAGs
        excelResultDags.add(dagRun);
        checkedDags.add(dagRun);
        for (DagRun downstreamDagRun: dagRun.getDownstreamDags()) {
            exportDownstreamDags(checkedDags, excelResultDags, downstreamDagRun);
        }
    }
}
