package ca.loblaw.cerebro.automation.testcases.computesmoke;

import org.testng.annotations.Test;

import java.io.IOException;


@Test(groups = {"@parquet2bq_ttd","TechComputeSmoke"})
public class TC01_parquet2bq_IngestionTest extends TechComputeCommonFun {
    public TC01_parquet2bq_IngestionTest() throws IOException {
        super("TC01_parquet2bq_ingestionTestData.properties");

    }
}


