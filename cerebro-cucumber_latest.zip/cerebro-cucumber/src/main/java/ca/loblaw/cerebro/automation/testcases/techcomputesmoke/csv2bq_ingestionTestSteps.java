package ca.loblaw.cerebro.automation.testcases.techcomputesmoke;

import org.testng.annotations.Test;

public class csv2bq_ingestionTestSteps extends TechComputeCommonFun{



    //************************************ Test Parameters ************************************************************
    String gcFilePath = "cerebro-${ENV}-raw-transactional-webfeed/OMNITURE/processed/OMNITURE.omniture_raw_feeds__ct/";
    String maxSizeMB = "10";
    String takeSmallestFile = "true";
    String localPropfile = "src/main/resources/configs/TechComputeSmoke/csv2bq_omniture_raw_feed.properties";
    String table_to_create = "omniture_raw_feeds_hist_qa";
    String error_table_to_create = "omniture_raw_feeds_hist_qa_error";
    String clone_from_dataset = "${TESTDATASET}";
    String clone_from_project = "${RAWZONE}";
    String clone_from_table = "omniture_raw_feeds_hist";
    String testing = "logistics_inventorymgmt/ingestion";
    String runtimeArgs = "src/main/resources/configs/TechComputeSmoke/csv2bq_omniture_raw_feed_RuntimeArgs.properties";
    String query = "SELECT rec_cre_tms,count(*) as record_count  FROM `lt-dia-lake-${ENV}-raw.cerebro_testing.omniture_raw_feeds_hist_qa`group by 1";

    //************************************* Test Steps *****************************************************************

    @Test(description = "Update inboundURI based on Ingestion File size-csv2bq", priority = 1)
    public void Update_inboundURI_Based_on_Ingestion_File_size_csv2bq() throws Exception {

        get_ingestion_file_by_size(gcFilePath, maxSizeMB, takeSmallestFile);
        update_inbound_uri(localPropfile);
    }
    @Test(description = "Create a BigQuery table-csv2bq", priority = 2)
    public void Create_a_BigQuery_table_csv2bq() throws Exception {

        query_ddl(clone_from_project, clone_from_table);
        drop_the_table(table_to_create, error_table_to_create, clone_from_dataset, clone_from_project);
        create_a_BQ_table(table_to_create, clone_from_project, clone_from_dataset, clone_from_table);
    }
    @Test(description = "Perform the test-csv2bq" , priority = 3)
    public void Perform_the_test_csv2bq() throws Exception {

        set_local_properties_file(localPropfile);
        upload_properties_file_toGCS(testing);
        execute_pipeline_specificjar_curate(mainClass, runtimeArgs);
    }

    @Test(description = "Validate the record counts match-csv2bq", priority = 4)
    public void Validate_the_record_counts_match_csv2bq() throws Exception {

        execute_bigquery_retrieve_results(query);
        validate_resultset();
    }

    //****************************************End of TestCase***********************************************************

  }

