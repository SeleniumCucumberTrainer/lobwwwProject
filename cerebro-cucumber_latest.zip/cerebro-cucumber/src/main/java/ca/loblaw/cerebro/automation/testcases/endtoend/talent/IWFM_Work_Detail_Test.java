package ca.loblaw.cerebro.automation.testcases.endtoend.talent;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "iwfm-work-detail", "talent" })
public class IWFM_Work_Detail_Test extends EndToEndTest {
    public IWFM_Work_Detail_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/talent/iwfm_work_detail.properties");    }
}
