package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"site_work","TechComputeSmoke"})
public class TC10_site_work extends TechComputeCommonFun{
    public TC10_site_work() throws IOException {
        super("TC10_site_workTestData.properties");
    }

}
