package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"entity_user_curation","TechComputeSmoke"})
public class TC06_entity_user extends TechComputeCommonFun{
    public TC06_entity_user() throws IOException {
        super("TC06_entity_userTestData.properties");
    }

}
