package ca.loblaw.cerebro.automation.models.validations;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.bigquery.TotalStats;

import java.util.Map;

public class PublicationComposerValidationDto {

    DagRun dagRun;
    String jobRunTraceId;
    String sourceName;
    String[] targetNames;
    String recCreTms;
    Map<String, TotalStats> tableStats;

    public DagRun getDagRun() {
        return dagRun;
    }

    public PublicationComposerValidationDto setDagRun(DagRun dagRun) {
        this.dagRun = dagRun;
        return this;
    }

    public String getJobRunTraceId() {
        return jobRunTraceId;
    }

    public PublicationComposerValidationDto setJobRunTraceId(String jobRunTraceId) {
        this.jobRunTraceId = jobRunTraceId;
        return this;
    }

    public String getSourceName() {
        return sourceName;
    }

    public PublicationComposerValidationDto setSourceName(String sourceName) {
        this.sourceName = sourceName;
        return this;
    }

    public String[] getTargetNames() {
        return targetNames;
    }

    public PublicationComposerValidationDto setTargetNames(String[] targetNames) {
        this.targetNames = targetNames;
        return this;
    }

    public String getRecCreTms() {
        return recCreTms;
    }

    public PublicationComposerValidationDto setRecCreTms(String recCreTms) {
        this.recCreTms = recCreTms;
        return this;
    }

    public Map<String, TotalStats> getTableStats() {
        return tableStats;
    }

    public PublicationComposerValidationDto setTableStats(Map<String, TotalStats> tableStats) {
        this.tableStats = tableStats;
        return this;
    }
}
