package ca.loblaw.cerebro.automation.utils.cloud.logging;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import com.google.api.gax.paging.Page;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.logging.LogEntry;
import com.google.cloud.logging.Logging;
import com.google.cloud.logging.LoggingOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CloudLoggingService {

    private static final Logger LOG = LogManager.getLogger(CloudLoggingService.class);
    private static final Logging CLOUD_LOGGING;

    static {
        try {
            CLOUD_LOGGING = LoggingOptions.newBuilder()
                    .setCredentials(
                            ServiceAccountCredentials.fromStream(new FileInputStream(System.getenv("GOOGLE_APPLICATION_CREDENTIALS"))))
                    .build()
                    .getService();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static class Filter {
        private final StringBuilder stringBuilder;

        public Filter() {
            this.stringBuilder = new StringBuilder();
        }

        public Filter addCondition(String key, String operator, String value) {
            stringBuilder.append(key).append(operator).append("\"").append(value).append("\"");
            return this;
        }

        public Filter addMultipleConditions(String key, String operator, List<String> values) {
            begin();
            for (int i = 0;  i < values.size(); i++) {
                addCondition(key, operator, values.get(i));
                if (i != values.size() - 1) {
                    or();
                }
            }
            end();

            return this;
        }

        public Filter and() {
            stringBuilder.append(" AND ");
            return this;
        }

        public Filter or() {
            stringBuilder.append(" OR ");
            return this;
        }

        public Filter begin() {
            stringBuilder.append("(");
            return this;
        }

        public Filter end() {
            stringBuilder.append(")");
            return this;
        }

        public String build() {
            return stringBuilder.toString();
        }
    }

    public static List<LogEntry> getLogs(Filter filter) {
        LOG.debug("Cloud Logging filter is: \n{}", filter.build());

        Page<LogEntry> logEntryPage = CLOUD_LOGGING.listLogEntries(
                Logging.EntryListOption.filter(filter.build())
        );

        List<LogEntry> logEntries = new ArrayList<>();
        for (LogEntry logEntry : logEntryPage.getValues()) {
            logEntries.add(logEntry);
        }

        return logEntries;
    }

    public static List<LogEntry> getLogs(Filter filter, int size) {
        LOG.debug("Cloud Logging filter is: \n{}\n\nCloud Logging page size is {}", filter.build(), size);

        Page<LogEntry> logEntryPage = CLOUD_LOGGING.listLogEntries(
                Logging.EntryListOption.filter(filter.build()),
                Logging.EntryListOption.pageSize(size)
        );

        List<LogEntry> logEntries = new ArrayList<>();
        for (LogEntry logEntry : logEntryPage.getValues()) {
            logEntries.add(logEntry);
        }

        return logEntries;
    }
}
