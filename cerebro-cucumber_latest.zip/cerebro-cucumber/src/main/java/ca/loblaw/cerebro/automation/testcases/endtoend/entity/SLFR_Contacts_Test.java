package ca.loblaw.cerebro.automation.testcases.endtoend.entity;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "slfr-contacts", "entity" })
public class SLFR_Contacts_Test extends EndToEndTest {
    public SLFR_Contacts_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/entity/slfr_contacts.properties");
    }
}
