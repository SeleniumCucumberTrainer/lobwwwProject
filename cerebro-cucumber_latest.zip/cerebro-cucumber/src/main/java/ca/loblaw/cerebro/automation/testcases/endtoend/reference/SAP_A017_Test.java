package ca.loblaw.cerebro.automation.testcases.endtoend.reference;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = { "sap_a017", "reference" })
public class SAP_A017_Test extends EndToEndTest {
    public SAP_A017_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/reference/sap_a017.properties");
    }
}