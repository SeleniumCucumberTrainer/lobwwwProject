package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstanceState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstance;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseTask;

public class TaskInstanceInfoHandler implements AirflowUpdateHandler {

    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {
        AirflowResponseTask responseTask = (AirflowResponseTask) airflowResponseItem;

        // Update
        if (dagRun.hasTaskInstance(responseTask.getTaskId())) {
            TaskInstance taskInstance = dagRun.getTaskInstance(responseTask.getTaskId());
            taskInstance.setState(TaskInstanceState.from(responseTask.getTaskState()));
            taskInstance.setStartDate(responseTask.getStartDate());
            taskInstance.setEndDate(responseTask.getEndDate());
            taskInstance.setMaxTries(responseTask.getMaxTries());
            taskInstance.setTryNumber(responseTask.getTryNumber());
            taskInstance.setKeywordArguments(responseTask.getKeywordArguments());
        } else {
            TaskInstance taskInstance = new TaskInstance(
                    responseTask.getTaskId(),
                    TaskInstanceState.from(responseTask.getTaskState()),
                    responseTask.getStartDate(),
                    responseTask.getEndDate(),
                    responseTask.getMaxTries(),
                    responseTask.getTryNumber(),
                    responseTask.getKeywordArguments()
            );
            dagRun.addTaskInstance(taskInstance);
        }
    }
}
