package ca.loblaw.cerebro.automation.testcases.computesmoke;


import org.testng.annotations.Test;

import java.io.IOException;

@Test(groups = {"csv2bq","TechComputeSmoke"})
public class TC02_csv2bq_ingestionTest extends TechComputeCommonFun{
   public TC02_csv2bq_ingestionTest() throws IOException {
        super("TC02_csv2bq_ingestionTestData.properties");
    }

}
