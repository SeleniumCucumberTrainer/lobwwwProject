package ca.loblaw.cerebro.automation.utils.internal;

import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/**
 * Utility class that handles reading and writing properties files.
 */
public class PropertiesFileUtils {

    private static final Logger LOG = LogManager.getLogger(PropertiesFileUtils.class);

    private PropertiesFileUtils() {}

    /**
     * Reads a properties file and convert it into a Map.
     *
     * @param propertiesFilePath Path to properties file.
     * @return Map representation of the properties file.
     * @throws IOException Error reading properties file.
     */
    public static Map<String, String> readPropertiesFileToMap(String propertiesFilePath) throws IOException {
        Map<String, String> propertiesMap = new HashMap<>();

        // Read .properties
        FileReader reader = new FileReader(propertiesFilePath);
        Properties properties = new Properties();
        properties.load(reader);

        // Convert to Map
        for (String key: properties.stringPropertyNames()) {
            String value = properties.getProperty(key);

            // Update template variables
            value = TestContext.replaceTemplateEnv(value);
            value = TestContext.replaceTemplateZone(value);
            value = TestContext.replaceTemplateProject(value);

            propertiesMap.put(key, value);
        }

        LOG.info("Created Map from {}", propertiesFilePath);

        return propertiesMap;
    }

    public static Map<String, String> readPropertiesStringToMap(String contents) throws IOException {
        Map<String, String> propertiesMap = new HashMap<>();

        // Read properties String
        Properties properties = new Properties();
        properties.load(new ByteArrayInputStream(contents.getBytes(StandardCharsets.UTF_8)));

        // Convert to Map
        for (String key: properties.stringPropertyNames()) {
            String value = properties.getProperty(key);
            propertiesMap.put(key, value);
        }

        return propertiesMap;
    }

    /**
     * Writes all key and values of a Map into a properties file.
     * Note: This will create/truncate the properties file before writing.
     *
     * @param propertiesMap Map to write.
     * @param propertiesFilePath Path of properties file to write to.
     * @throws IOException Error writing to properties file.
     */
    public static void writeMapToPropertiesFile(Map<String, String> propertiesMap, String propertiesFilePath) throws IOException {
        List<String> propertiesLines = new ArrayList<>();

        for (String key : propertiesMap.keySet()) {
            propertiesLines.add(key + "=" + propertiesMap.get(key));
        }

        Files.write(Paths.get(propertiesFilePath), propertiesLines, StandardCharsets.UTF_8);
    }
    public static Map<String, String> readPropFileUpdateConfigParam(String filePath) throws IOException {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        FileReader reader=new FileReader(filePath);
        FilenameUtils s;
        Properties p=new Properties();
        p.load(reader);
        for (String key : p.stringPropertyNames()) {
            String value = p.getProperty(key);
            if(key.contains("sqlPath")) value=TestContext.getsqlBucket(value);
            if (value.contains("${ENV}")) value = TestContext.getTestEnvironment(value);
            if (value.contains("${TESTDATASET}")) value = TestContext.getTestDataSet(value);
            map.put(key, value);
        }
        return map;
    }
}
