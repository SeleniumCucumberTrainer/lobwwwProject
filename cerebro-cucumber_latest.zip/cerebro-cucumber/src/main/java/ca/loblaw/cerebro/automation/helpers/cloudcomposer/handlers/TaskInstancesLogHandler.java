package ca.loblaw.cerebro.automation.helpers.cloudcomposer.handlers;

import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.models.cloud.function.airflow.response.AirflowResponseItem;

public class TaskInstancesLogHandler implements AirflowUpdateHandler {
    @Override
    public void handleResponse(AirflowResponseItem airflowResponseItem, DagRun dagRun) {

    }
}
