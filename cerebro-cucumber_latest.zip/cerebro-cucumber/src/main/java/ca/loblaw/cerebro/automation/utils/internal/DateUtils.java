package ca.loblaw.cerebro.automation.utils.internal;

import java.time.DateTimeException;
import java.time.format.DateTimeFormatter;

public class DateUtils {
    private static final DateTimeFormatter SHORT_TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final DateTimeFormatter TIMESTAMP_FORMATTER  = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");

    /**
     * Attempts to convert a shortened timestamp format to the regular timestamp format. If the given timestamp is not
     * actually short, return it due to parse failure.
     * E.g. 2024-03-12 21:57:24.562 -> 2024-03-12 21:57:24.562000
     *
     * @param timestamp Given timestamp to convert.
     * @return Timestamp in regular form or original timestamp.
     */
    public static String convertShortTimestampToRegular(String timestamp) {
        try {
            return TIMESTAMP_FORMATTER.format(SHORT_TIMESTAMP_FORMATTER.parse(timestamp));
        } catch (DateTimeException e) {
            return timestamp;
        }
    }
}
