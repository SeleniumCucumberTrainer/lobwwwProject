package ca.loblaw.cerebro.automation.utils.internal;

import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for reading an Excel file.
 */
public class ExcelReader {

    /**
     * Read raw rows of an Excel file.
     * @param excelPath Path to Excel file.
     * @param sheetName Excel sheet to read.
     * @return Rows of a given sheet in the Excel file.
     */
    public static List<Row> getRows(String excelPath, String sheetName) {
        try (FileInputStream fileInputStream = new FileInputStream(excelPath);
             Workbook workbook = WorkbookFactory.create(fileInputStream)) {

            Sheet sheet = workbook.getSheet(sheetName);

            // Add all rows to list
            List<Row> sheetRows = new ArrayList<>();
            for (Row row : sheet) {
                sheetRows.add(row);
            }
            return sheetRows;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
