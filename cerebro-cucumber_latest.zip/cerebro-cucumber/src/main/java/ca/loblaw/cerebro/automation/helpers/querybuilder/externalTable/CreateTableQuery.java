package ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable;

import ca.loblaw.cerebro.automation.helpers.querybuilder.Query;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class CreateTableQuery implements Query {
    private String tableName;
    private List<Column> columns;
    private String tableQuery = "";

    public CreateTableQuery fromQuery(String query){
        this.tableQuery = query;
        return this;
    }

    public String getTableName() {
        return tableName;
    }

    public CreateTableQuery setTableName(String tableName) {
        this.tableName = tableName;
        return this;
    }

    public List<Column> getColumns() {
        return columns;
    }

    public CreateTableQuery setColumns(List<Column> columns) {
        this.columns = columns;
        return this;
    }

    @Override
    public String build() {
        StringBuilder createTableQuery = new StringBuilder();
        // Table name
        createTableQuery.append("CREATE OR REPLACE TABLE `" + parseTableName() + "`\n");

        //Table query
        if(!this.tableQuery.isEmpty()) {
            createTableQuery.append(" as\n").append(this.tableQuery);
        }
        //Columns
        else {
            createTableQuery.append("(" + parseColumns() + ")\n");
        }

        return createTableQuery.toString();
    }


    // Parsers
    private String parseTableName() {
        assert tableName != null && !tableName.isEmpty();

        return tableName;
    }

    private String parseColumns() {
        assert columns != null && !columns.isEmpty();

        StringBuilder columnsString = new StringBuilder();
        for (Column column : columns) {
            columnsString.append(", ").append(column.getName()).append(" ").append(column.getDataType());
        }

        return StringUtils.replaceOnce(columnsString.toString(), ", ", "");
    }
}
