package ca.loblaw.cerebro.automation.component.cloud.composer.tasks;

public class PublicationTasks {

    public static final String GET_TARGET_TABLE = "get_trgt_tbl";
    public static final String GET_JOB_RUN_TRACE_ID = "get_job_run_trace_id";
    public static final String GET_REC_CRE_TMS = "get_rec_cre_tms";
    public static final String GET_CURRENT_TMS = "get_cur_tms";
    public static final String PUBLISH = "publish";
    public static final String UPDATE_FLOW_CONTROL = "update_flow_control";
    public static final String PUBLISH_MESSAGE_FOR_FULFILLMENT_TOPIC = "publish_message_for_fulfillment_topic";
    public static final String METADATA_LOG = "metadata_log";
}
