package ca.loblaw.cerebro.automation.testcases.endtoend.merchandising;

import ca.loblaw.cerebro.automation.testcases.endtoend.EndToEndTest;
import org.testng.annotations.Test;

import java.io.IOException;
@Test(groups = { "ipfr-promo", "merchandising" })
public class IPFR_Promo_Test extends EndToEndTest {
    public IPFR_Promo_Test() throws IOException {
        super("src/main/resources/setup/endtoend/pipelines/merchandising/ipfr_promo.properties");
    }
}
