package ca.loblaw.cerebro.automation.testcases;

import ca.loblaw.cerebro.automation.annotations.ConfigCondition;
import ca.loblaw.cerebro.automation.annotations.Depends;
import ca.loblaw.cerebro.automation.annotations.Remove;
import ca.loblaw.cerebro.automation.exceptions.AutomationException;
import ca.loblaw.cerebro.automation.listeners.ConfigListener;
import ca.loblaw.cerebro.automation.listeners.RemoveTestMethodInterceptor;
import ca.loblaw.cerebro.automation.utils.command.CommandLineExecutor;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.Layer;
import ca.loblaw.cerebro.automation.utils.reports.extent.ExtentManager;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import ca.loblaw.cerebro.automation.utils.contexts.OperatingSystemContext;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.assertj.core.api.SoftAssertionError;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.xml.XmlTest;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

/**
 * This BaseTest abstract class is the base parent class for all created TestNG tests.
 * Handles:
 *      - Extent reporting
 *      - Providing location for file logging
 *      - Implementing test removal based on remove conditions
 *      - Implementing test skipping based on dependencies
 *      - Implementing conditional configuration executions
 *      - Environment setup
 */
@Listeners(value = { ConfigListener.class, RemoveTestMethodInterceptor.class })
public abstract class BaseTest implements IHookable, IConfigurable {

    private static final Logger LOG = LogManager.getLogger(BaseTest.class);
    private static final short INSTANCE_ID_LENGTH = 12;

    // Set of remove conditions to remove test methods.
    // Conditions must be given before any test methods are executed. This field is not used anytime afterwards.
    private final Set<String> removeConditions = new HashSet<>();
    private final Set<String> passFlags = new HashSet<>(); // Set of passed flags for test dependencies check
    private final Set<String> configurationsRan = new HashSet<>(); // Set of configuration names that were ran before
    private final String instanceId; // Unique ID that represents an instance of a test class
    private final String fullDataName; // Identifier name used when multiple instances of the same test class are created using @Factories
    private String extentKey; // Unique key to retrieve Extent Test / Nodes associated with this test instance

    public BaseTest() {
        this.fullDataName = null;
        this.instanceId = RandomStringUtils.randomAlphanumeric(INSTANCE_ID_LENGTH);
    }

    public BaseTest(String factoryDataName) {
        this.fullDataName = this.getClass().getSimpleName() + " - " + factoryDataName;
        this.instanceId = RandomStringUtils.randomAlphanumeric(INSTANCE_ID_LENGTH);
    }

    /**
     * Adds flag condition to current test execution to indicate a condition has passed.
     * @param flag Flag name.
     */
    protected void addPassFlag(String flag) {
        passFlags.add(flag);
    }

    protected void addRemoveCondition(String condition) {
        removeConditions.add(condition);
    }

    /**
     * Highest level @BeforeSuite configuration that runs before 'suite' tag.
     * @throws IOException Error reading properties file.
     * @throws InterruptedException Error when command line thread interrupted.
     */
    @BeforeSuite(alwaysRun = true)
    public void before_suite_setup() throws IOException, InterruptedException {
        setupEnvironment();
    }

    /*
     * Setup test environment values from properties files.
     */
    private void setupEnvironment() throws IOException, InterruptedException {
        TestContext.readTestConfigProperties();
        CommandLineExecutor.setCommandLineScripts();
        TestContext.activateCommandLineServiceAccount();
        OperatingSystemContext.setGSUtilCommands();
        OperatingSystemContext.setFilePaths();
    }

    /**
     * Highest level @BeforeTest configuration that runs before XML 'test' bundle tag.
     * @param testContext Suite context information.
     * @param xmlTest XML 'test' bundle tag information.
     * @throws IOException Error reading Extent report config file
     */
    @BeforeTest(alwaysRun = true)
    public void before_test_bundle_setup(ITestContext testContext, XmlTest xmlTest) throws IOException {
        createExtentReport(testContext, xmlTest);
    }

    /*
     * Create Extent report document.
     */
    private void createExtentReport(ITestContext testContext, XmlTest xmlTest) throws IOException {
        ExtentManager.createExtentReport(testContext.getSuite().getName(), xmlTest.getName());
    }

    /**
     * Highest level @BeforeClass configuration that runs before each test class instance.
     * @param testContext Suite context information.
     * @param xmlTest XML 'test' bundle tag information.
     */
    @BeforeClass(alwaysRun = true)
    public void before_class_instance_setup(ITestContext testContext, XmlTest xmlTest) {
        createExtentKey();
        setThreadContext(testContext, xmlTest);
        createExtentTest();
    }

    /*
     * Create Extent key for current test instance.
     */
    private void createExtentKey() {
        extentKey = fullDataName != null ? fullDataName : this.getClass().getSimpleName();
    }

    /*
     * Create Extent test for current test instance
     */
    private void createExtentTest() {
        if (!ExtentManager.hasExtentTest(extentKey)) {
            Set<String> classTestGroups = new HashSet<>();

            // Find all groups in @Test annotation through inheritance chain
            Class<?> currentClass = this.getClass();
            while (currentClass != BaseTest.class && currentClass != Object.class) {
                if (currentClass.isAnnotationPresent(Test.class)) {
                    Test classTestAnnotation = currentClass.getAnnotation(Test.class);
                    classTestGroups.addAll(Arrays.asList(classTestAnnotation.groups()));
                }

                currentClass = currentClass.getSuperclass();
            }

            ExtentManager.createExtentTest(extentKey, classTestGroups.toArray(new String[0]));
        }
    }

    /**
     * Highest level @BeforeMethod configuration that runs before each test method.
     * @param testContext Suite context information.
     * @param xmlTest XML 'test' bundle tag information.
     * @param testResult Current test method information.
     * @param method Actual test method.
     */
    @BeforeMethod(alwaysRun = true)
    public void before_test_method_setup(ITestContext testContext, XmlTest xmlTest, ITestResult testResult, Method method) {
        setThreadContext(testContext, xmlTest);
        createExtentNode(testResult);
        createTestLog(method);
    }

    /*
     * Create Extent node for current test method.
     */
    private void createExtentNode(ITestResult testResult) {
        Test methodTestAnnotation = testResult.getMethod().getConstructorOrMethod().getMethod().getAnnotation(Test.class);
        String testMethodDescription = methodTestAnnotation.description();

        // Provide test description as node name, otherwise use method name
        if (testMethodDescription != null) {

            // Data provider method
            if (!methodTestAnnotation.dataProvider().isEmpty() && testMethodDescription.contains("{}")) {
                Object[] parameters = testResult.getParameters();
                String dataName = (String) parameters[1];
                testMethodDescription = testMethodDescription.replace("{}", dataName);
            }

            ExtentManager.createExtentNode(extentKey, testMethodDescription, testResult.getMethod().getGroups());
        } else {
            String testMethodName = testResult.getMethod().getMethodName();

            // Data provider method
            if (!methodTestAnnotation.dataProvider().isEmpty()) {
                Object[] parameters = testResult.getParameters();
                String dataName = (String) parameters[1];
                testMethodName = testMethodName + " " + dataName;
            }

            ExtentManager.createExtentNode(extentKey, testMethodName, testResult.getMethod().getGroups());
        }
    }

    /*
     * Log description (or method name) of the test method being ran.
     */
    private void createTestLog(Method method) {
        Test testAnnotation = method.getDeclaredAnnotation(Test.class);
        String description = testAnnotation.description();

        if (getFullDataName() == null) {
            LOG.log(Level.getLevel("TEST"), description + " - " + this.getClass().getSimpleName());
        } else {
            LOG.log(Level.getLevel("TEST"), description + " - " + getFullDataName());
        }
    }

    /*
     * Set key-value pairs for current Thread. This is done to make each test instance threadsafe.
     */
    private void setThreadContext(ITestContext testContext, XmlTest xmlTest) {
        if (fullDataName != null) {
            ThreadContext.put(Layer.DATA_NAME, fullDataName);
        }
        ThreadContext.put(Layer.CLASS_NAME, this.getClass().getSimpleName());
        ThreadContext.put(Layer.BUNDLE_NAME, xmlTest.getName());
        ThreadContext.put(Layer.SUITE_NAME, testContext.getSuite().getName());
        ThreadContext.put(Layer.INSTANCE_ID, instanceId);
        ThreadContext.put(Layer.EXTENT_KEY, extentKey);
    }

    /**
     * Override test method execution to handle custom-implemented dependencies.
     * @param hookCallBack Test method caller.
     * @param testResult Current test method information.
     */
    @Override
    public void run(IHookCallBack hookCallBack, ITestResult testResult) {
        SkipException skipException = dependenciesCheck(testResult);

        // Check if test should be skipped due to dependencies
        if(skipException == null) {
            hookCallBack.runTestMethod(testResult);
        } else {
            testResult.setStatus(ITestResult.SKIP);
            testResult.setThrowable(skipException);
        }
    }

    /**
     * Override configuration execution to handle custom execution conditions.
     * @param configureCallBack Configuration caller.
     * @param configResult Current configuration information.
     */
    @Override
    public void run(IConfigureCallBack configureCallBack, ITestResult configResult) {
        ITestNGMethod testNGMethod = configResult.getMethod();
        Method configMethod = testNGMethod.getConstructorOrMethod().getMethod();

        // Handle config conditions for @BeforeMethod and @AfterMethod
        if (testNGMethod.isBeforeMethodConfiguration() || testNGMethod.isAfterMethodConfiguration()) {

            ConfigCondition configCondition = configMethod.getAnnotation(ConfigCondition.class);

            if (configCondition != null){
                // Handle running once
                if (configCondition.runOnce() && configurationsRan.contains(configMethod.getName())) {
                    return;
                }

                // Handle running before certain groups for @BeforeMethod
                // or running after certain groups for @AfterMethod
                String[] runBeforeOrAfterGroups = configCondition.runBeforeOrAfterGroups();

                if (runBeforeOrAfterGroups.length > 0) {
                    if (configResult.getParameters().length > 0) {
                        ITestResult testResult = (ITestResult) configResult.getParameters()[0];
                        List<String> testMethodGroups = Arrays.stream(testResult.getMethod().getGroups()).collect(Collectors.toList());
                        if (!testMethodGroups.containsAll(Arrays.asList(runBeforeOrAfterGroups))) {
                            return;
                        }
                    } else {
                        throw new AutomationException("Running before or after groups requires an ITestResult parameter " +
                                "as the first parameter in the configuration method to read.");
                    }
                }

                // Handle running before certain methods for @BeforeMethod
                // or running after certain methods for @AfterMethod
                String[] runBeforeOrAfterMethods = configCondition.runBeforeOrAfterMethods();
                if (runBeforeOrAfterMethods.length > 0) {
                    if (configResult.getParameters().length > 0) {
                        ITestResult testResult = (ITestResult) configResult.getParameters()[0];
                        String testMethodName = testResult.getMethod().getMethodName();

                        if (!Arrays.asList(runBeforeOrAfterMethods).contains(testMethodName)) {
                            return;
                        }
                    } else {
                        throw new AutomationException("Running before or after methods requires an ITestResult parameter " +
                                "as the first parameter in the configuration method to read.");
                    }
                }
            }
        }

        // Handle dependencies
        if (dependenciesCheck(configResult) != null) {
            return;
        }

        // Handle removals
        if (configMethod.isAnnotationPresent(Remove.class)) {
            Remove removeAnnotation = configMethod.getAnnotation(Remove.class);
            if (removeConditions.contains(removeAnnotation.condition())) {
                return;
            }
        }

        // Determine run configuration
        configurationsRan.add(configMethod.getName());
        configureCallBack.runConfigurationMethod(configResult);
    }

    /*
     * Returns a SkipException if the current test method dependencies are not met.
     * This allows for finer control over which test methods are being ran and when.
     */
    private SkipException dependenciesCheck(ITestResult testResult) {
        Method method = testResult.getMethod().getConstructorOrMethod().getMethod();
        Depends depends = method.getDeclaredAnnotation(Depends.class);

        if (depends != null) {
            // Check flag dependencies
            String[] flagDependencies = depends.flags();

            for (String dependentFlag : flagDependencies) {
                if (!passFlags.contains(dependentFlag)) {
                    return new SkipException("Dependent flag '" + dependentFlag + "' was not true");
                }
            }
        }

        return null;
    }

    /**
     * Lowest level @AfterMethod configuration that runs after each test method.
     * @param testResult Current test method information.
     */
    @AfterMethod(alwaysRun = true)
    public void after_test_method_cleanup(ITestResult testResult) {
        closeExtentNode(testResult);
    }

    /*
     * Report and log test method execution result and close Extent node.
     */
    private void closeExtentNode(ITestResult testResult) {
        switch (testResult.getStatus()) {
            case ITestResult.SUCCESS:
                Reporter.pass(LOG, "All Tests Passed!");
                break;

            case ITestResult.SKIP:
                String skipMessage = testResult.getThrowable().getMessage() != null ?
                        testResult.getThrowable().getMessage() : "SkipException raised";
                Reporter.skip(LOG, skipMessage);
                break;

            default:
                Throwable resultThrowable = testResult.getThrowable();
                if (resultThrowable == null) {
                    break;
                }

                if (resultThrowable instanceof SoftAssertionError) {
                    SoftAssertionError softAssertionError = (SoftAssertionError) resultThrowable;
                    for (String error: softAssertionError.getErrors()) {
                        Reporter.error(LOG, error);
                    }
                } else if (resultThrowable instanceof AssertionError) {
                    AssertionError assertionError = (AssertionError) resultThrowable;
                    Reporter.error(LOG, assertionError.getMessage());
                } else {
                    Reporter.error(LOG, testResult.getThrowable());
                }
        }

        ExtentManager.clearExtentNode(extentKey);
    }

    /**
     * Lowest level @AfterClass configuration that runs after each test instance.
     * @param testContext Suite context information.
     * @param xmlTest XML 'test' bundle tag information.
     */
    @AfterClass(alwaysRun = true)
    public void after_class_instance_cleanup(ITestContext testContext, XmlTest xmlTest) {
        setThreadContext(testContext, xmlTest);
        ThreadContext.clearAll();
        ExtentManager.clearExtentTest(extentKey);
    }

    /**
     * Lowest level @AfterTest configuration that runs after each XML 'test' bundle tag.
     */
    @AfterTest(alwaysRun = true)
    public void after_test_bundle_cleanup() {
        ExtentManager.save();
        ThreadContext.clearMap();
    }

    public String getFullDataName() {
        return fullDataName;
    }

    public String getExtentKey() {
        return extentKey;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public Set<String> getRemoveConditions() {
        return removeConditions;
    }
}
