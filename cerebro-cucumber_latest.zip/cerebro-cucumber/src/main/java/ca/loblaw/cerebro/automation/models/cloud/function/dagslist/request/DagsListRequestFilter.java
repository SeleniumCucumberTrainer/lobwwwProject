package ca.loblaw.cerebro.automation.models.cloud.function.dagslist.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DagsListRequestFilter {

    @JsonProperty("is_paused")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean isPaused;

    @JsonProperty("is_active")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean isActive;

    @JsonProperty("dag_id_pattern")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String pattern;

    public DagsListRequestFilter(Boolean isPaused, Boolean isActive, String pattern) {
        this.isPaused = isPaused;
        this.isActive = isActive;
        this.pattern = pattern;
    }

    public Boolean getPaused() {
        return isPaused;
    }

    public void setPaused(Boolean paused) {
        isPaused = paused;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }
}
