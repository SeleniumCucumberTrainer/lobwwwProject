package ca.loblaw.cerebro.automation.testcases.endtoend;

import ca.loblaw.cerebro.automation.annotations.ConfigCondition;
import ca.loblaw.cerebro.automation.annotations.Depends;
import ca.loblaw.cerebro.automation.annotations.Remove;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRunState;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.TaskInstanceState;
import ca.loblaw.cerebro.automation.component.cloud.composer.DagRun;
import ca.loblaw.cerebro.automation.component.cloud.composer.tasks.*;
import ca.loblaw.cerebro.automation.component.cloud.function.AirflowFunction;
import ca.loblaw.cerebro.automation.exceptions.DagException;
import ca.loblaw.cerebro.automation.helpers.querybuilder.template.single.SingleSourceQuery;
import ca.loblaw.cerebro.automation.interactors.FileRoutingStorageManager;
import ca.loblaw.cerebro.automation.models.cloud.bigquery.TotalStats;
import ca.loblaw.cerebro.automation.models.cloud.dataflow.DataflowResults;
import ca.loblaw.cerebro.automation.models.data.RawFolders;
import ca.loblaw.cerebro.automation.models.pipelines.PublicationType;
import ca.loblaw.cerebro.automation.models.validations.*;
import ca.loblaw.cerebro.automation.steps.endtoend.ControlFlowValidator;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.ExternalTableQuery;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.FileFormat;
import ca.loblaw.cerebro.automation.helpers.querybuilder.externalTable.Column;
import ca.loblaw.cerebro.automation.interactors.AirflowDagUpdater;
import ca.loblaw.cerebro.automation.steps.cloudcomposer.AirflowDagValidator;
import ca.loblaw.cerebro.automation.steps.endtoend.*;
import ca.loblaw.cerebro.automation.steps.filerouting.*;
import ca.loblaw.cerebro.automation.testcases.BaseTest;
import ca.loblaw.cerebro.automation.utils.cloud.bigquery.BigQueryUtils;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFile;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageFileContainer;
import ca.loblaw.cerebro.automation.utils.cloud.storage.CloudStorageUtils;
import ca.loblaw.cerebro.automation.utils.contexts.Project;
import ca.loblaw.cerebro.automation.utils.contexts.TestContext;
import ca.loblaw.cerebro.automation.utils.internal.CerebroPatterns;
import ca.loblaw.cerebro.automation.utils.internal.DateUtils;
import ca.loblaw.cerebro.automation.utils.internal.JsonUtils;
import ca.loblaw.cerebro.automation.utils.internal.PropertiesFileUtils;
import ca.loblaw.cerebro.automation.utils.reports.extent.Reporter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.TableResult;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
@Test(groups = { "end-to-end" })
public abstract class EndToEndTest extends BaseTest {

    private static final Logger LOG = LogManager.getLogger(EndToEndTest.class);
    private static final String AIRFLOW_PROPERTIES = "src/main/resources/setup/cloudcomposer/techcompute/airflowFunction.properties";
    private static AirflowFunction AIRFLOW_FUNCTION;
    private static final long WAIT_INTERVAL = 10000;
    private static final long WAIT_MAX = 1800000;

    // Parameters
    private final Map<String, String> propertiesMap;
    private String testFolderPath;
    private String landingFolderPath;
    private String rawFolderPath;
    private RawFolders rawFolders;
    private String ingestionTable;
    private String snapshotTable;
    private String curationTable;
    private String[] publicationTables;
    private boolean snapshotPresent;

    /* -------- Run Variables -------- */

    // Others
    private String landingStartTime;
    private String jobRunTraceId;
    private String externalTable;

    // Landing
    private List<CloudStorageFile> landingTestCloudFiles;
    private List<String> testCloudFileNames;
    private List<CloudStorageFile> rawTestCloudFiles;
    private List<CloudStorageFile> batchDataRawFiles;

    // Ingestion
    private DagRun ingestionDag;
    private String ingestionRecCreTms;
    private String ingestionDataflowJobId;
    private String ingestionDataflowJobName;
    private long ingestionTablePreviousTotalRecordCount;
    private long ingestionTableTotalRecordCount;
    private long ingestionTableRecordCount;
    private long ingestionDataflowInputCount;
    private long ingestionDataflowRecordCount;
    private long ingestionDataflowErrorCount;

    // Snapshot
    private DagRun snapshotDag;
    private String snapshotTime;
    private long snapshotTablePreviousTotalRecordCount;
    private long snapshotTableRecordCount;

    // Curation
    private DagRun curationDag;
    private String curationRecCreTms;
    private String curationDataflowJobId;
    private String curationDataflowJobName;
    private long curationTablePreviousTotalRecordCount;
    private long curationTableTotalRecordCount;
    private long curationTableRecordCount;
    private long curationQueryRecordCount;
    private long curationDataflowInputCount;
    private long curationDataflowRecordCount;
    private long curationDataflowErrorCount;

    // Publication
    private DagRun publicationDag;
    private String publicationRecCreTms;
    private long[] publicationTablePreviousTotalRecordCounts;
    private long[] publicationTableTotalRecordCounts;
    private long[] publicationTableRecordCounts;
    private PublicationType publicationType;
    private Map<String, TotalStats> publicationTableStats;

    // Test steps and validators
    private FileRoutingStorageManager fileRoutingStorageManager;
    private AirflowDagUpdater airflowDagUpdater;

    public EndToEndTest(String propertiesFilePath) throws IOException {
        this.propertiesMap = PropertiesFileUtils.readPropertiesFileToMap(propertiesFilePath);
        setupProperties();
        setupRemoveConditions();
    }

    @BeforeSuite(alwaysRun = true)
    public void end_to_end_test_before_suite() throws IOException {
        AIRFLOW_FUNCTION = AirflowFunction.fromPropertiesFile(AIRFLOW_PROPERTIES);
    }

    @BeforeClass(alwaysRun = true)
    public void end_to_end_test_before_class() {
        fileRoutingStorageManager = new FileRoutingStorageManager(testFolderPath, landingFolderPath, rawFolderPath, rawFolders);
        airflowDagUpdater = new AirflowDagUpdater(AIRFLOW_FUNCTION);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Input Check
    //------------------------------------------------------------------------------------------------------------------

    @Test(description = "Check Input")
    public void check_input() throws IOException, InterruptedException {
        // Check properties
        validateProperties(propertiesMap);

        // Check Ingestion
        validateDagInput(ingestionDag);
        validateTableInput(ingestionTable);
        ingestionTablePreviousTotalRecordCount = retrieveBigQueryTableTotalRecordCount(ingestionTable);

        // Check Snapshot
        if (snapshotPresent) {
            validateDagInput(snapshotDag);
            validateTableInput(snapshotTable);
            snapshotTablePreviousTotalRecordCount = retrieveBigQueryTableTotalRecordCount(snapshotTable);
        }

        // Check Curation
        validateDagInput(curationDag);
        validateTableInput(curationTable);
        curationTablePreviousTotalRecordCount = retrieveBigQueryTableTotalRecordCount(curationTable);

        // Check Publication
        validateDagInput(publicationDag);
        for (int tableIndex = 0; tableIndex < publicationTables.length; tableIndex++) {
            String publicationTable = publicationTables[tableIndex];
            validateTableInput(publicationTable);
            publicationTablePreviousTotalRecordCounts[tableIndex] = retrieveBigQueryTableTotalRecordCount(publicationTable);
        }

        // Connect DAGs
        if (snapshotDag != null) {
            AirflowDagUpdater.connectUpstreamAndDownstreamDag(ingestionDag, snapshotDag);
            AirflowDagUpdater.connectUpstreamAndDownstreamDag(snapshotDag, curationDag);
            AirflowDagUpdater.connectUpstreamAndDownstreamDag(curationDag, publicationDag);
        } else {
            AirflowDagUpdater.connectUpstreamAndDownstreamDag(ingestionDag, curationDag);
            AirflowDagUpdater.connectUpstreamAndDownstreamDag(curationDag, publicationDag);
        }

        landingStartTime = LocalDateTime.now(ZoneId.of("UTC")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        LOG.info("Landing start time is around {}", landingStartTime);

        addPassFlag("input_valid");
    }

    private void setupRemoveConditions() {
        // Landing
        if (landingFolderPath == null) {
            addRemoveCondition("uses_alternative");
        } else {
            addRemoveCondition("uses_landing");
        }

        // External table
        if (externalTable == null) {
            addRemoveCondition("unreadable_files");
        }

        // Snapshot
        if (!snapshotPresent) {
            addRemoveCondition("no_snapshot");
        } else {
            addRemoveCondition("snapshot_present");
        }
    }

    private void setupProperties() {

        // Landing-Raw
        this.testFolderPath = propertiesMap.get("testFolderPath");
        this.landingFolderPath = propertiesMap.get("landingFolderPath");
        this.rawFolderPath = propertiesMap.get("rawFolderPath");
        this.rawFolders = new RawFolders(rawFolderPath);

        // Ingestion
        this.ingestionTable = propertiesMap.get("ingestionTable");
        this.ingestionDag = new DagRun(propertiesMap.get("ingestionDagId"), Project.TECHCOMPUTE_ZONE);
        this.externalTable = propertiesMap.get("externalTable");

        // Snapshot
        this.snapshotPresent = propertiesMap.containsKey("snapshotDagId") && propertiesMap.containsKey("snapshotTable");
        this.snapshotTable = propertiesMap.get("snapshotTable");
        this.snapshotDag = snapshotPresent ? new DagRun(propertiesMap.get("snapshotDagId"), Project.TECHCOMPUTE_ZONE) : null;

        // Curation
        this.curationTable = propertiesMap.get("curationTable");
        this.curationDag = new DagRun(propertiesMap.get("curationDagId"), Project.TECHCOMPUTE_ZONE);

        // Publication
        this.publicationTables = propertiesMap.get("publicationTables").replace(" ", "").split(",");
        this.publicationTableRecordCounts = new long[publicationTables.length];
        this.publicationTableTotalRecordCounts = new long[publicationTables.length];
        this.publicationTablePreviousTotalRecordCounts = new long[publicationTables.length];
        this.publicationType = PublicationType.from(propertiesMap.get("publicationType"));
        this.publicationDag = new DagRun(propertiesMap.get("publicationDagId"), Project.TECHCOMPUTE_ZONE);
    }

    private void validateProperties(Map<String, String> propertiesMap) {
        // File information
        Assertions.assertThat(propertiesMap)
                .containsKey("fileFormat");
        if (propertiesMap.containsKey("externalTable")) {
            Assertions.assertThat(propertiesMap)
                    .containsKey("fileExternalTableFormat");
            if(propertiesMap.get("fileFormat").contains("csv")) {
                Assertions.assertThat(propertiesMap)
                        .containsKey("fileDelimiter");
                Assertions.assertThat(propertiesMap)
                        .containsKey("fileHasHeader");
            }
        }

        // Landing
        Assertions.assertThat(propertiesMap)
                .containsKey("testFolderPath");
        Assertions.assertThat(propertiesMap)
                .containsKey("rawFolderPath");
    }

    private void validateDagInput(DagRun dag) throws IOException {
        String dagId = dag.getDagId();

        airflowDagUpdater.setDagRun(dag);
        airflowDagUpdater.checkDagInfo();
        airflowDagUpdater.listTasks();
        Assertions.assertThat(dag.hasNoError())
                .as("Check %s exists", dagId)
                .isTrue();
        Assertions.assertThat(dag.isPaused())
                .as("Check %s is paused", dagId)
                .isFalse();
        Reporter.pass(LOG, "DAG {} is valid", dagId);
    }

    private void validateTableInput(String tableName) {
        Assertions.assertThat(BigQueryUtils.checkTableExists(tableName))
                .as("Check table %s exists", tableName)
                .isTrue();
        Reporter.pass(LOG, "Table {} is valid", tableName);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Landing
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(alwaysRun = true, groups = "landing")
    @Depends(flags = "input_valid")
    @ConfigCondition(runBeforeOrAfterGroups = "landing", runOnce = true)
    public void landing_zone_setup(ITestResult testResult) {
        // Copying test files
        fileRoutingStorageManager.cleanLandingFolder();
        fileRoutingStorageManager.retrieveTestFilesPaths();
        fileRoutingStorageManager.copyTestFilesToLandingFolder();

        addPassFlag("test_files_copied");
    }

    @Test(priority = 1, description = "Validate Landing File Routing", groups = "landing")
    @Depends(flags = { "input_valid", "test_files_copied" })
    @Remove(condition = "uses_alternative")
    public void validate_landing_file_routing() throws InterruptedException {
        // Landing files
        fileRoutingStorageManager.waitForLandingFilesToBeRouted();
        landingTestCloudFiles = fileRoutingStorageManager.retrieveLandingFilesSorted();
        testCloudFileNames = CloudStorageFileContainer.wrap(landingTestCloudFiles).toFileNamesList();

        // Retrieve raw test files routed from landing
        rawTestCloudFiles = fileRoutingStorageManager.findRawCloudFilesFromFileNames(
                testCloudFileNames,
                "routed landing files",
                "landing"
        );
        FileRoutingValidator.validateLandingAndRawCloudFiles(landingTestCloudFiles, rawTestCloudFiles, "landing");

        addPassFlag("files_landed");
    }

    @Test(priority = 2, description = "Validate Landing File Routing Metadata Log", groups = "landing")
    @Depends(flags = "files_landed")
    @Remove(condition = "uses_alternative")
    public void validate_landing_file_routing_metadata_log() throws InterruptedException {
        DataObservabilityValidator.validateFileRoutingMetadataLogs(
                landingStartTime,
                retrieveNonDfmFiles(landingTestCloudFiles),
                retrieveNonDfmFiles(rawTestCloudFiles)
        );
    }

    private List<CloudStorageFile> retrieveNonDfmFiles(List<CloudStorageFile> cloudFiles) {
        return cloudFiles.stream()
                .filter(cloudStorageFile -> !cloudStorageFile.getName().endsWith(".dfm"))
                .collect(Collectors.toList());
    }

    //------------------------------------------------------------------------------------------------------------------
    // Direct Landing
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(alwaysRun = true, groups = "direct_landing")
    @Depends(flags = "input_valid")
    @ConfigCondition(runBeforeOrAfterGroups = "direct_landing", runOnce = true)
    public void direct_landing_zone_setup(ITestResult testResult) {
        // Copying test files
        fileRoutingStorageManager.retrieveTestFilesPaths();
        fileRoutingStorageManager.copyTestFilesToRawFolder();

        addPassFlag("test_files_copied");
    }

    @Test(priority = 1, description = "Validate Setup for Direct Landing Pipeline", groups = "direct_landing")
    @Depends(flags = { "input_valid", "test_files_copied" })
    @Remove(condition = "uses_landing")
    public void validate_direct_landing() {
        testCloudFileNames = fileRoutingStorageManager.getTestFilesToCopyPaths().stream()
                .map(FilenameUtils::getName)
                .collect(Collectors.toList());

        // Retrieve raw test files routed from landing
        rawTestCloudFiles = fileRoutingStorageManager.findRawCloudFilesFromFileNames(
                testCloudFileNames,
                "copied test files",
                "landing"
        );

        Assertions.assertThat(rawTestCloudFiles.size())
                .as("Number of raw files found")
                .isEqualTo(testCloudFileNames.size());

        addPassFlag("files_landed");
    }

    //------------------------------------------------------------------------------------------------------------------
    // Ingestion
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(alwaysRun = true, groups = "ingestion")
    @Depends(flags = "files_landed")
    @ConfigCondition(runBeforeOrAfterGroups = "ingestion", runOnce = true)
    public void trigger_ingestion_dag(ITestResult testResult) throws IOException, InterruptedException {
        airflowDagUpdater.setDagRun(ingestionDag);

        // Trigger
        airflowDagUpdater.triggerDag();
        Reporter.info(LOG, "DAG run ID is {}", ingestionDag.getDagRunId());

        // Set ingestion flag is DAG is running
        waitForDagToRun(ingestionDag);

        if (ingestionDag.getState() != DagRunState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("ingestion_triggered");
        } else {
            throw new DagException("Ingestion DAG is still queued");
        }
    }

    @Test(priority = 10, description = "Validate Ingestion Job Run Trace ID", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_job_run_trace_id() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.GENERATE_JOB_RUN_TRACE_ID);
        airflowDagUpdater.retrieveXcomVariables(IngestionTasks.GENERATE_JOB_RUN_TRACE_ID);
        airflowDagUpdater.retrieveXcomValue(IngestionTasks.GENERATE_JOB_RUN_TRACE_ID, "return_value");

        // Retrieve job run trace ID
        TaskInstance generateJobRunTraceId = ingestionDag.getTaskInstance(IngestionTasks.GENERATE_JOB_RUN_TRACE_ID);
        jobRunTraceId = String.valueOf(generateJobRunTraceId.getXcomEntry("return_value"));
        jobRunTraceId = jobRunTraceId.substring(2, jobRunTraceId.length() - 2);
        Reporter.info(LOG, "Job run trace ID is {}", jobRunTraceId);

        // Validations
        Assertions.assertThat(jobRunTraceId)
                .as("Job run trace ID")
                .matches(CerebroPatterns.UUID);
        Reporter.pass(LOG, "Job run trace ID matches UUID pattern");
    }

    @Test(priority = 11, description = "Validate Ingestion Move to Working", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_move_to_working() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.MOVE_TO_WORKING);

        // Retrieve all non-DFM raw files for validation in "working" folder
        String fileFormat = propertiesMap.get("fileFormat");
        batchDataRawFiles = fileRoutingStorageManager.retrieveRawFiles("working");
        batchDataRawFiles = batchDataRawFiles.stream()
                .filter(file -> file.getName().endsWith(fileFormat))
                .collect(Collectors.toList());
        Reporter.info(LOG, "{} of the raw files in 'working' folder are data files", batchDataRawFiles.size());

        // Raw files
        FileRoutingValidator.validateTestFilesMovedToStageFolder(testCloudFileNames, rawFolders, "working");
    }

    @Test(priority = 12, description = "Validate Ingestion Dataflow", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_dataflow() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomVariables(IngestionTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomValue(IngestionTasks.TRIGGER_DATAFLOW_JOB, "jobName");
        airflowDagUpdater.retrieveXcomValue(IngestionTasks.TRIGGER_DATAFLOW_JOB, "jobId");

        // Retrieve recCreTms and target table
        Reporter.info(LOG, "Checking BigQuery information from task '{}'", IngestionTasks.TRIGGER_DATAFLOW_JOB);

        TaskInstance triggerDataflowJob = ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB);
        ingestionRecCreTms = DateUtils.convertShortTimestampToRegular(triggerDataflowJob.getStringArgument("recCreTms"));
        String targetTable = triggerDataflowJob.getStringArgument("trgt_ds_tbl_nm");

        Reporter.info(LOG,"Ingestion recCreTms is {}", ingestionRecCreTms);
        Reporter.info(LOG,"Task '{}' target table is {}", IngestionTasks.TRIGGER_DATAFLOW_JOB, targetTable);

        Assertions.assertThat(targetTable)
                .as("Check task '%s' target table", IngestionTasks.TRIGGER_DATAFLOW_JOB)
                .isEqualTo(extractDatasetTable(ingestionTable));
        Reporter.pass(LOG, "Task '{}' has same target table as the given target table", IngestionTasks.TRIGGER_DATAFLOW_JOB);

        // Total record count
        ingestionTableTotalRecordCount = retrieveBigQueryTableTotalRecordCount(ingestionTable);
        Reporter.info(LOG, "Ingestion table total record count is {}", ingestionTableTotalRecordCount);

        // Batch record count
        ingestionTableRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM `%s` WHERE rec_cre_tms = '%s'",
                        ingestionTable,
                        ingestionRecCreTms
                )
        );
        Reporter.info(LOG, "Ingestion table {} batch record count for {} is {}", ingestionTable, ingestionRecCreTms, ingestionTableRecordCount);
        if (ingestionTableRecordCount == 0) Reporter.warn(LOG, "Ingestion table record count is 0");

        // Retrieve dataflow values
        Reporter.info(LOG, "Checking dataflow information from task '{}'", IngestionTasks.TRIGGER_DATAFLOW_JOB);
        ingestionDataflowJobId = ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobId");
        ingestionDataflowJobName = ingestionDag.getTaskInstance(IngestionTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobName");

        Reporter.info(LOG, "Dataflow job name is {} and ID is {}", ingestionDataflowJobName, ingestionDataflowJobId);

        // Validations
        DataflowJobValidator.validateDataflowJob(ingestionDataflowJobId);

        DataflowResults dataflowResults = DataflowJobValidator.retrieveDataflowMetrics(
                ingestionDataflowJobId,
                Arrays.asList("Read raw files/Extract File Pattern/Via MatchAll",
                        "Retrieve Input/FileIOMatchSource/Extract File Pattern/Via MatchAll"),
                Arrays.asList("Valid Records to BQ/Write to BQ/PrepareWrite",
                        "Beam Row to BQ/BigQueryIO.Write/PrepareWrite"),
                Arrays.asList("Row Level Tranformation Error Logging/Write unaggregated errors to BigQuery/Bounded Write to BQ/PrepareWrite")
        );
        ingestionDataflowInputCount = dataflowResults.getInputCount();
        ingestionDataflowRecordCount = dataflowResults.getRecordCount();
        ingestionDataflowErrorCount = dataflowResults.getErrorCount();

        DataflowJobValidator.validateDataflowInputCount(ingestionDataflowInputCount, batchDataRawFiles.size(), "number of batch files");
        DataflowJobValidator.validateDataflowRecordCount(ingestionDataflowRecordCount, ingestionTableRecordCount);
    }

    @Test(priority = 13, description = "Validate Ingestion Move to Processed", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_move_to_processed() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.MOVE_TO_PROCESSED);

        // Find "working" data raw files moved to "processed"
        batchDataRawFiles = fileRoutingStorageManager.findRawCloudFilesFromFileNames(
                CloudStorageFileContainer.wrap(batchDataRawFiles).toFileNamesList(),
                "batch raw files moved from working",
                "processed"
        );

        FileRoutingValidator.validateTestFilesMovedToStageFolder(testCloudFileNames, rawFolders, "processed");
    }

    @BeforeMethod(alwaysRun = true, groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    @ConfigCondition(runBeforeOrAfterMethods = "validate_ingestion_bigquery", runOnce = true)
    public void create_external_table(ITestResult testResult) throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.MOVE_TO_PROCESSED);

        List<Column> tableColumns = propertiesMap.containsKey("useJsonSchema") ?
                CloudStorageUtils.getSchemaFromJsonFile(rawFolderPath.replace("...", "processed")) :
                BigQueryUtils.getColumnsSchemaFromTable(ingestionTable, true);

        ExternalTableQuery externalTableQuery = new ExternalTableQuery()
                .setTableName(externalTable)
                .setColumns(tableColumns)
                .setFileURIs(batchDataRawFiles)
                .setFileFormat(FileFormat.fromString(propertiesMap.get("fileExternalTableFormat")));

        // File specific External table options
        if (externalTableQuery.getFileFormat() == FileFormat.CSV) {
            externalTableQuery.setMaxBadRecords(Integer.MAX_VALUE);
        }
        if (propertiesMap.containsKey("fileHasHeader")) {
            externalTableQuery.setHasHeader(Boolean.parseBoolean(propertiesMap.get("fileHasHeader")));
        }
        if (propertiesMap.containsKey("fileDelimiter")) {
            externalTableQuery.setDelimiter(propertiesMap.get("fileDelimiter").charAt(0));
        }

        try {
            BigQueryUtils.executeQuery(externalTableQuery.build());
            addPassFlag("external_table_created");
            LOG.info("Created external table '{}' ", externalTable);
        } catch (InterruptedException e) {
            LOG.error("Failed to create external table '{}'", externalTable);
            throw new RuntimeException(e);
        }
    }

    @Test(priority = 14, description = "Validate Ingestion BigQuery Record Count", groups = "ingestion")
    @Depends(flags = { "ingestion_triggered", "external_table_created" })
    @Remove(condition = "unreadable_files")
    public void validate_ingestion_bigquery() throws InterruptedException {
        // External table record count
        long externalTableRecordCount = retrieveBigQueryTableTotalRecordCount(propertiesMap.get("externalTable"));
        Reporter.info(LOG, "External table record count is {}", externalTableRecordCount);

        EndToEndTablesValidator.validateExternalAndIngestionTableFilesRecordCount(
                externalTable,
                ingestionTable,
                ingestionRecCreTms,
                batchDataRawFiles
        );

        EndToEndTablesValidator.validateExternalAndIngestionTableTotalRecordCount(
                externalTableRecordCount,
                ingestionTableRecordCount
        );
    }

    @Test(priority = 15, description = "Validate Ingestion Datastore", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_datastore() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.INSERT_FLOW_CONTROL);

        if (snapshotPresent) {
            ControlFlowValidator.validateDataflowControlFlowInsert(
                    ingestionRecCreTms,
                    extractDatasetTable(ingestionTable),
                    "ingestion",
                    extractDatasetTable(snapshotTable),
                    "snapshot"
            );
        } else {
            ControlFlowValidator.validateDataflowControlFlowInsert(
                    ingestionRecCreTms,
                    extractDatasetTable(ingestionTable),
                    "ingestion",
                    extractDatasetTable(curationTable),
                    "curation"
            );
        }
    }

    @Test(priority = 16, description = "Validate Ingestion Metadata Logs", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_metadata_logs() throws InterruptedException, IOException {
        waitForTaskToCompleteSuccessfully(ingestionDag, IngestionTasks.METADATA_LOG);

        DataObservabilityValidator.validateIngestionComposerMetadataLogs(
                new IngestionComposerValidationDto()
                        .setDagRun(ingestionDag)
                        .setRawFolderPath(rawFolderPath)
                        .setJobRunTraceId(jobRunTraceId)
                        .setDatasetTable(extractDatasetTable(ingestionTable))
                        .setRecCreTms(ingestionRecCreTms)
                        .setDataflowJobId(ingestionDataflowJobId)
                        .setDataflowJobName(ingestionDataflowJobName)
                        .setTableRecordCount(ingestionTableRecordCount)
                        .setDataflowRecordCount(ingestionDataflowRecordCount)
                        .setDataflowErrorCount(ingestionDataflowErrorCount)
                        .setBatchRawFileSize(batchDataRawFiles.size())
        );

        DataObservabilityValidator.validateIngestionDataflowMetadataLogs(
                ingestionDataflowJobName
        );
    }

    @Test(priority = 17, description = "Validate Ingestion DAG", groups = "ingestion")
    @Depends(flags = "ingestion_triggered")
    public void validate_ingestion_dag() throws IOException, InterruptedException {
        waitForDagToFinish(ingestionDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(ingestionDag);
        AirflowDagValidator.validateDagTaskInstances(ingestionDag);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Snapshot
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(alwaysRun = true, groups = "snapshot")
    @ConfigCondition(runBeforeOrAfterGroups = "snapshot", runOnce = true)
    @Depends(flags = "ingestion_triggered")
    public void retrieve_snapshot_dag(ITestResult testResult) throws IOException, InterruptedException {
        waitForTaskToComplete(ingestionDag, "trigger_" + snapshotDag.getDagId());
        airflowDagUpdater.setDagRun(snapshotDag);

        // Retrieve closest to execution date
        airflowDagUpdater.findRunAssociatedWithUpstreamDag();
        if (snapshotDag.getDagRunId() == null) {
            throw new DagException("Snapshot DAG was not triggered");
        }
        LOG.info("DAG run ID is {}", snapshotDag.getDagRunId());

        // Set snapshot flag if triggered and running
        waitForDagToRun(snapshotDag);

        if (snapshotDag.getState() != DagRunState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("snapshot_running");
        } else {
            throw new DagException("Snapshot DAG is still queued");
        }
    }

    @Test(priority = 20, description = "Validate Snapshot BigQuery", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    @Remove(condition = "no_snapshot")
    public void validate_snapshot_bigquery() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.GET_TARGET_TABLE);
        airflowDagUpdater.retrieveXcomVariables(SnapshotTasks.GET_TARGET_TABLE);
        airflowDagUpdater.retrieveXcomValue(SnapshotTasks.GET_TARGET_TABLE, "return_value");

        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.LOAD_CURRENT);

        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.GET_SNAPSHOT_TIME);
        airflowDagUpdater.retrieveXcomVariables(SnapshotTasks.GET_SNAPSHOT_TIME);
        airflowDagUpdater.retrieveXcomValue(SnapshotTasks.GET_SNAPSHOT_TIME, "system_tms");

        // Retrieve recCreTms and target table
        snapshotTime = snapshotDag.getTaskInstance(SnapshotTasks.GET_SNAPSHOT_TIME).getXcomEntry("system_tms");
        String targetTable = snapshotDag.getTaskInstance(SnapshotTasks.GET_TARGET_TABLE).getXcomEntry("return_value");

        Reporter.info(LOG, "Snapshot time from task '{}' is {}", SnapshotTasks.LOAD_CURRENT, snapshotTime);
        Reporter.info(LOG, "Task '{}' target table is {}", SnapshotTasks.LOAD_CURRENT, targetTable);

        Assertions.assertThat(targetTable)
                .as("Check task '%s' target table", SnapshotTasks.LOAD_CURRENT)
                .isEqualTo(extractDatasetTable(snapshotTable));

        // Record count validation
        snapshotTableRecordCount = EndToEndTablesValidator.validateAndReturnSnapshotRecordCount(snapshotTable);

        // Snapshot time validation
        String tableSnapshotTime = EndToEndTablesValidator.validateAndReturnSnapshotTime(
                snapshotTable,
                snapshotDag.getTaskInstance(SnapshotTasks.LOAD_CURRENT).getStartDate(),
                snapshotDag.getTaskInstance(SnapshotTasks.LOAD_CURRENT).getEndDate()
        );

        Assertions.assertThat(tableSnapshotTime)
                .as("Check table snapshot time against DAG task snapshot time")
                .isEqualTo(snapshotTime);
    }

    @Test(priority = 21, description = "Validate Snapshot Datastore", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    @Remove(condition = "no_snapshot")
    public void validate_snapshot_datastore() throws IOException, InterruptedException {
        // Control flow update
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.UPDATE_FLOW_CONTROL);
        ControlFlowValidator.validateDatastoreControlFlowUpdate(
                ingestionRecCreTms,
                extractDatasetTable(ingestionTable),
                "ingestion",
                snapshotTime,
                extractDatasetTable(snapshotTable),
                "snapshot"
        );

        // Control flow insert
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.INSERT_TO_CONTROL);
        ControlFlowValidator.validateDataflowControlFlowInsert(
                snapshotTime,
                extractDatasetTable(snapshotTable),
                "snapshot",
                extractDatasetTable(curationTable),
                "curation"
        );
    }

    @Test(priority = 22, description = "Validate Snapshot Metadata Logs", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    @Remove(condition = "no_snapshot")
    public void validate_snapshot_metadata_logs() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(snapshotDag, SnapshotTasks.METADATA_LOG);

        DataObservabilityValidator.validateSnapshotComposerMetadataLog(
                new SnapshotComposerValidationDto()
                        .setDagRun(snapshotDag)
                        .setJobRunTraceId(jobRunTraceId)
                        .setRecCreTms(snapshotTime)
                        .setSourceName(extractDatasetTable(ingestionTable))
                        .setTargetName(extractDatasetTable(snapshotTable))
                        .setTableRecordCount(snapshotTableRecordCount)
        );
    }

    @Test(priority = 23, description = "Validate Snapshot DAG", groups = "snapshot")
    @Depends(flags = "snapshot_running")
    @Remove(condition = "no_snapshot")
    public void validate_snapshot_dag() throws IOException, InterruptedException {
        waitForDagToFinish(snapshotDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(snapshotDag);
        AirflowDagValidator.validateDagTaskInstances(snapshotDag);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Curation
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(alwaysRun = true, groups = "curation")
    @ConfigCondition(runBeforeOrAfterGroups = "curation", runOnce = true)
    @Depends(flags = "ingestion_triggered")
    @Remove(condition = "snapshot_present")
    public void retrieve_curation_dag(ITestResult testResult) throws IOException, InterruptedException {
        retrieveCurationDagRun(ingestionDag);
    }

    @BeforeMethod(alwaysRun = true, groups = "curation")
    @ConfigCondition(runBeforeOrAfterGroups = "curation", runOnce = true)
    @Depends(flags = "snapshot_running")
    @Remove(condition = "no_snapshot")
    public void retrieve_curation_dag_snapshot(ITestResult testResult) throws IOException, InterruptedException {
        retrieveCurationDagRun(snapshotDag);
    }

    private void retrieveCurationDagRun(DagRun upstreamDag) throws IOException, InterruptedException {
        waitForTaskToComplete(upstreamDag, "trigger_" + curationDag.getDagId());

        // Retrieve closest to execution date
        airflowDagUpdater.setDagRun(curationDag);
        airflowDagUpdater.findRunAssociatedWithUpstreamDag();
        if (curationDag.getDagRunId() == null) {
            throw new DagException("Curation DAG was not triggered");
        }
        LOG.info("DAG run ID is {}", curationDag.getDagRunId());

        // Set curation flag if triggered and running
        waitForDagToRun(curationDag);

        if (curationDag.getState() != DagRunState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("curation_running");
        } else {
            throw new DagException("Curation DAG is still queued");
        }
    }

    @Test(priority = 30, description = "Validate Curation Dataflow", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_dataflow() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.READ_PROPERTY);
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.ADD_TMS_PROPERTY);
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomVariables(CurationTasks.TRIGGER_DATAFLOW_JOB);
        airflowDagUpdater.retrieveXcomValue(CurationTasks.TRIGGER_DATAFLOW_JOB, "jobName");
        airflowDagUpdater.retrieveXcomValue(CurationTasks.TRIGGER_DATAFLOW_JOB, "jobId");

        // Retrieve recCreTms and target table
        TaskInstance trigger_dataflow_job = curationDag.getTaskInstance(CurationTasks.TRIGGER_DATAFLOW_JOB);
        curationRecCreTms = DateUtils.convertShortTimestampToRegular(trigger_dataflow_job.getStringArgument("recCreTms"));
        String targetTable = trigger_dataflow_job.getStringArgument("trgt_ds_tbl_nm");

        Reporter.info(LOG, "Curation recCreTms is {}", curationRecCreTms);
        Reporter.info(LOG, "Curation '{}' target table is {}", CurationTasks.TRIGGER_DATAFLOW_JOB, targetTable);

        Assertions.assertThat(targetTable)
                .as("Check '%s' task target table", CurationTasks.TRIGGER_DATAFLOW_JOB)
                .isEqualTo(extractDatasetTable(curationTable));
        Reporter.pass(LOG, "Task '{}' has same target table as the given target table", CurationTasks.TRIGGER_DATAFLOW_JOB);

        // Retrieve Curation query
        TaskInstance curationQueryTask = curationDag.getTaskInstance("add_tms_property");
        String curationQuery = extractCurationQuery(curationQueryTask);
        Reporter.info(LOG, "Retrieved curation query is:\n\n{}\n", curationQuery);
        curationQueryRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM (%s)",
                        curationQuery
                )
        );
        Reporter.info(LOG, "Curation query record count is {}", curationQueryRecordCount);

        // Curation table record count
        curationTableTotalRecordCount = retrieveBigQueryTableTotalRecordCount(curationTable);
        Reporter.info(LOG, "Curation table total record count is {}", curationTableTotalRecordCount);
        curationTableRecordCount = retrieveBigQueryTableRecordCount(
                String.format(
                        "SELECT COUNT(*) AS record_count FROM `%s` WHERE rec_cre_tms = '%s'",
                        curationTable,
                        curationRecCreTms
                )
        );
        Reporter.info(LOG, "Curation table {} batch record count for {} is {}", curationTable, curationRecCreTms, curationTableRecordCount);
        if (curationTableRecordCount == 0) Reporter.warn(LOG, "Curation table record count is 0");

        // Retrieve dataflow values
        Reporter.info(LOG, "Checking dataflow information from task '{}'", CurationTasks.TRIGGER_DATAFLOW_JOB);
        curationDataflowJobId = curationDag.getTaskInstance(CurationTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobId");
        curationDataflowJobName = curationDag.getTaskInstance(CurationTasks.TRIGGER_DATAFLOW_JOB).getXcomEntry("jobName");

        Reporter.info(LOG, "Dataflow job name is {} and ID is {}", curationDataflowJobName, curationDataflowJobId);

        // Validations
        DataflowJobValidator.validateDataflowJob(curationDataflowJobId);
        DataflowResults dataflowResults = DataflowJobValidator.retrieveDataflowMetrics(
                curationDataflowJobId,
                Arrays.asList("Read BQ Table/Reading Raw Custom SQL query from BQ/Read(BigQueryQuerySource)",
                        "Read BQ Table/Reading Raw Custom SQL query a sql file/Read(BigQueryQuerySource)",
                        "Retrieve Input/BigQueryIO.TypedRead/Read(BigQueryQuerySource)"),
                Arrays.asList("PB:Valid Records to BQ/Write to BQ/PrepareWrite",
                        "Beam Row to BQ/BigQueryIO.Write/PrepareWrite"),
                Arrays.asList("Log Record Errors/Write unaggregated errors to BigQuery/Bounded Write to BQ/PrepareWrite")
        );
        curationDataflowInputCount = dataflowResults.getInputCount();
        curationDataflowRecordCount = dataflowResults.getRecordCount();
        curationDataflowErrorCount = dataflowResults.getErrorCount();

        DataflowJobValidator.validateDataflowInputCount(
                curationDataflowInputCount,
                curationQueryRecordCount,
                "number of rows retrieved from Curation input query"
        );
        DataflowJobValidator.validateDataflowRecordCount(curationDataflowRecordCount, curationTableRecordCount);
    }

    @Test(priority = 31, description = "Validate Curation BigQuery", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_bigquery() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.ADD_TMS_PROPERTY);
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.TRIGGER_DATAFLOW_JOB);

        // Retrieve curation query
        TaskInstance curationQueryTask = curationDag.getTaskInstance("add_tms_property");
        String curationQuery = extractCurationQuery(curationQueryTask);
        Reporter.info(LOG, "Retrieved curation query is:\n\n{}\n", curationQuery);

        // Files record count
        EndToEndTablesValidator.validateCurationQueryAndTableFilesRecordCount(
                curationQuery,
                propertiesMap.get("curationQueryFileColumnName"),
                curationTable,
                curationRecCreTms,
                batchDataRawFiles,
                curationDataflowErrorCount
        );

        // Total record count
        EndToEndTablesValidator.validateCurationQueryAndTableTotalRecordCount(
                curationQueryRecordCount,
                curationTableRecordCount,
                curationDataflowErrorCount
        );
    }

    private String extractCurationQuery(TaskInstance curationQueryTask) throws IOException {
        String curationQuery = null;

        String contents = (String) curationQueryTask.getKeywordArguments().get("contents");
        Map<String, String> contentsMap = PropertiesFileUtils.readPropertiesStringToMap(contents);

        // 1. Curation query is in kwargs
        // 2. Curation query is in SQL file
        if (contentsMap.containsKey("query")) {
            curationQuery = PropertiesFileUtils.readPropertiesStringToMap(contents).get("query");
        } else if (contentsMap.containsKey("curr_sql_file")) {
            String composerBucket = (String) curationQueryTask.getKeywordArguments().get("bucket");
            curationQuery = CloudStorageUtils.readFileAsString(String.format("gs://%s/%s", composerBucket, contentsMap.get("curr_sql_file")));
        }

        // Parse Curation query
        if (curationQuery != null && !curationQuery.isEmpty()) {
            return curationQuery.replace("${rec_cre_tms}", String.format("'%s'", ingestionRecCreTms))
                    .replace("@rec-cre-tms", String.format("'%s'", ingestionRecCreTms))
                    .replace(";", "")
                    .replace("<env>", TestContext.ENV.toString())
                    .replace("${env_short_name}", TestContext.ENV.toString());
        } else {
            throw new DagException("Could not retrieve curation query from DAG task");
        }
    }

    @Test(priority = 32, description = "Validate Curation Datastore", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_datastore() throws IOException, InterruptedException {
        // Control flow update
        waitForTaskToCompleteSuccessfully(curationDag, "update_flow_control");

        if (snapshotPresent) {
            ControlFlowValidator.validateDatastoreControlFlowUpdate(
                    snapshotTime,
                    extractDatasetTable(snapshotTable),
                    "snapshot",
                    curationRecCreTms,
                    extractDatasetTable(curationTable),
                    "curation"
            );
        } else {
            ControlFlowValidator.validateDatastoreControlFlowUpdate(
                    ingestionRecCreTms,
                    extractDatasetTable(ingestionTable),
                    "ingestion",
                    curationRecCreTms,
                    extractDatasetTable(curationTable),
                    "curation"
            );
        }

        // Control flow insert
        waitForTaskToCompleteSuccessfully(curationDag, "insert_to_control");
        ControlFlowValidator.validateDataflowControlFlowInsertOneToMany(
                curationRecCreTms,
                extractDatasetTable(curationTable),
                "curation",
                extractDatasetTableArray(publicationTables),
                "publication"
        );
    }

    @Test(priority = 33, description = "Validate Curation Metadata Logs", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_metadata_logs() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(curationDag, CurationTasks.METADATA_LOG);

        if (snapshotPresent) {
            DataObservabilityValidator.validateCurationComposerMetadataLog(
                    new CurationComposerValidationDto()
                            .setDagRun(curationDag)
                            .setJobRunTraceId(jobRunTraceId)
                            .setRecCreTms(curationRecCreTms)
                            .setSourceName(extractDatasetTable(snapshotTable))
                            .setTargetName(extractDatasetTable(curationTable))
                            .setTableRecordCount(curationTableRecordCount)
                            .setDataflowJobId(curationDataflowJobId)
                            .setDataflowJobName(curationDataflowJobName)
            );
        } else {
            DataObservabilityValidator.validateCurationComposerMetadataLog(
                    new CurationComposerValidationDto()
                            .setDagRun(curationDag)
                            .setJobRunTraceId(jobRunTraceId)
                            .setRecCreTms(curationRecCreTms)
                            .setSourceName(extractDatasetTable(ingestionTable))
                            .setTargetName(extractDatasetTable(curationTable))
                            .setTableRecordCount(curationTableRecordCount)
                            .setDataflowJobId(curationDataflowJobId)
                            .setDataflowJobName(curationDataflowJobName)
            );
        }
    }

    @Test(priority = 34, description = "Validate Curation DAG", groups = "curation")
    @Depends(flags = "curation_running")
    public void validate_curation_dag() throws IOException, InterruptedException {
        waitForDagToFinish(curationDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(curationDag);
        AirflowDagValidator.validateDagTaskInstances(curationDag);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Publication
    //------------------------------------------------------------------------------------------------------------------

    @BeforeMethod(alwaysRun = true, groups = "publication")
    @ConfigCondition(runBeforeOrAfterGroups = "publication", runOnce = true)
    @Depends(flags = "curation_running")
    public void retrieve_publication_dag(ITestResult testResult) throws IOException, InterruptedException {
        if (curationDag.hasTask("trigger_publication")) {
            waitForTaskToComplete(curationDag, "trigger_publication");
        } else {
            waitForTaskToComplete(curationDag, "trigger_" + publicationDag.getDagId());
        }

        // Retrieve closest to execution date
        airflowDagUpdater.setDagRun(publicationDag);
        airflowDagUpdater.findRunAssociatedWithUpstreamDag();
        if (publicationDag.getDagRunId() == null) {
            throw new DagException("Publication DAG was not triggered");
        }
        LOG.info("DAG run ID is {}", publicationDag.getDagRunId());

        // Set publication flag if triggered and running
        waitForDagToRun(publicationDag);

        if (publicationDag.getState() != DagRunState.QUEUED) {
            airflowDagUpdater.getTaskInstances();
            addPassFlag("publication_running");
        } else {
            throw new DagException("Publication DAG is still queued");
        }
    }

    @Test(priority = 40, description = "Validate Publication BigQuery", groups="publication")
    @Depends(flags = "publication_running")
    public void validate_publication_bigquery() throws IOException, InterruptedException {
        waitForTaskToComplete(publicationDag, PublicationTasks.GET_CURRENT_TMS);
        airflowDagUpdater.retrieveXcomVariables(PublicationTasks.GET_CURRENT_TMS);
        airflowDagUpdater.retrieveXcomValue(PublicationTasks.GET_CURRENT_TMS, "system_tms");

        // Retrieve timestamp
        publicationRecCreTms = DateUtils.convertShortTimestampToRegular(
                publicationDag.getTaskInstance(PublicationTasks.GET_CURRENT_TMS).getXcomEntry("system_tms"));
        Reporter.info(LOG, "Publication recCreTms is {}", publicationRecCreTms);

        waitForTaskToComplete(publicationDag, PublicationTasks.PUBLISH);
        airflowDagUpdater.retrieveXcomVariables(PublicationTasks.PUBLISH);
        airflowDagUpdater.retrieveXcomValue(PublicationTasks.PUBLISH, "job_id");
        airflowDagUpdater.retrieveXcomValue(PublicationTasks.PUBLISH, "dml_stats");

        // Retrieve publication query
        String publicationQuery = retrievePublicationQuery(publicationDag.getTaskInstance(PublicationTasks.PUBLISH));
        Reporter.info(LOG, "Publication query is:\n\n{}\n", publicationQuery);

        // Publication query job
        String queryJobId = publicationDag.getTaskInstance(PublicationTasks.PUBLISH).getXcomEntry("job_id");
        Assertions.assertThat(queryJobId)
                .as("Publication query job ID")
                .isNotNull();
        Reporter.info(LOG, "Publication query job ID is {}", queryJobId);

        // Publication query statistics
        String dmlStats = publicationDag.getTaskInstance(PublicationTasks.PUBLISH).getXcomEntry("dml_stats").replace("'", "\"");
        Assertions.assertThat(dmlStats)
                .as("Publication query stats")
                .isNotNull();
        Reporter.info(LOG, "DML stats are: \n\n{}\n", dmlStats);

        // Publication query table stats
        publicationTableStats = retrieveTableStats(dmlStats);
        Assertions.assertThat(publicationTableStats.keySet())
                .as("Tables available for stats")
                .containsExactly(publicationTables);

        // Total record counts
        for (int tableIndex = 0; tableIndex < publicationTables.length; tableIndex++) {
            publicationTableTotalRecordCounts[tableIndex] = retrieveBigQueryTableTotalRecordCount(publicationTables[tableIndex]);
            Reporter.info(LOG, "Publication table {} total record count is {}", publicationTables[tableIndex], publicationTableTotalRecordCounts[tableIndex]);
        }

        // Batch record counts and validations
        for (int tableIndex = 0; tableIndex < publicationTables.length; tableIndex++) {
            // Batch record count information
            switch (publicationType) {
                case DELTA_HIST:
                    publicationTableRecordCounts[tableIndex] =
                            publicationTableTotalRecordCounts[tableIndex] - publicationTablePreviousTotalRecordCounts[tableIndex];
                    break;
                case DELTA_TRUNCATE:
                    publicationTableRecordCounts[tableIndex] = publicationTableTotalRecordCounts[tableIndex];
                    break;
                default:
                    publicationTableRecordCounts[tableIndex] = retrieveBigQueryTableRecordCount(
                            String.format(
                                    "SELECT COUNT(*) AS record_count FROM `%s` WHERE rec_cre_tms >= '%s'",
                                    publicationTables[tableIndex],
                                    publicationRecCreTms
                            )
                    );
                    break;
            }
            Reporter.info(LOG, "Publication table {} batch record count for {} is {}",
                    publicationTables[tableIndex],
                    publicationRecCreTms,
                    publicationTableRecordCounts[tableIndex]
            );

            // Validate publication total table record count
            EndToEndTablesValidator.validatePublicationTableRecordCount(
                    publicationType,
                    publicationTables[tableIndex],
                    publicationTablePreviousTotalRecordCounts[tableIndex],
                    publicationTableTotalRecordCounts[tableIndex],
                    publicationTableStats.get(publicationTables[tableIndex])
            );
        }
    }

    private Map<String, TotalStats> retrieveTableStats(String dmlStats) throws JsonProcessingException {
        JsonNode dmlNode = JsonUtils.readStringToJsonObject(dmlStats);
        Map<String, TotalStats> tableStats = new HashMap<>();

        for (Iterator<String> it = dmlNode.fieldNames(); it.hasNext(); ) {
            String table = it.next();

            // Initialize stats
            if (!tableStats.containsKey(table)) {
                tableStats.put(table, new TotalStats());
            }

            // Populate stats
            JsonNode statsNode = dmlNode.get(table);

            TotalStats totalStats = tableStats.get(table);
            totalStats.addInsertedCount(statsNode.get("inserted_row_count").asLong());
            totalStats.addDeletedCount(statsNode.get("deleted_row_count").asLong());
        }

        return tableStats;
    }

    private String retrievePublicationQuery(TaskInstance publicationQueryTask) {
        String publicationQuery = publicationQueryTask.getStringArgument("sql");
        publicationQuery = publicationQuery.replace("{param-src-rec-cre-tms}", curationRecCreTms);
        publicationQuery = publicationQuery.replace("@rec-cre-tms", String.format("'%s'", curationRecCreTms));

        return publicationQuery;
    }

    @Test(priority = 41, description = "Validate Publication Datastore", groups = "publication")
    @Depends(flags = "publication_running")
    public void validate_publication_datastore() throws IOException, InterruptedException {
        // Control flow update
        waitForTaskToCompleteSuccessfully(publicationDag, PublicationTasks.UPDATE_FLOW_CONTROL);
        ControlFlowValidator.validateDatastoreControlFlowUpdateOneToMany(
                curationRecCreTms,
                extractDatasetTable(curationTable),
                "curation",
                publicationRecCreTms,
                extractDatasetTableArray(publicationTables),
                "publication"
        );
    }

    @Test(priority = 42, description = "Validate Publication Metadata Logs", groups = "publication")
    @Depends(flags = "publication_running")
    public void validate_publication_metadata_logs() throws IOException, InterruptedException {
        waitForTaskToCompleteSuccessfully(publicationDag, PublicationTasks.METADATA_LOG);

        DataObservabilityValidator.validatePublicationComposerMetadataLog(
                new PublicationComposerValidationDto()
                        .setDagRun(publicationDag)
                        .setJobRunTraceId(jobRunTraceId)
                        .setRecCreTms(publicationRecCreTms)
                        .setSourceName(extractDatasetTable(curationTable))
                        .setTargetNames(extractDatasetTableArray(publicationTables))
                        .setTableStats(publicationTableStats)
        );
    }

    @Test(priority = 43, description = "Validate Publication DAG", groups = "publication")
    @Depends(flags = "publication_running")
    public void validate_publication_dag() throws IOException, InterruptedException {
        waitForDagToFinish(publicationDag);

        // -- Finished --
        airflowDagUpdater.getTaskInstances();
        AirflowDagValidator.validateDagRunInfo(publicationDag);
        AirflowDagValidator.validateDagTaskInstances(publicationDag);
    }

    //------------------------------------------------------------------------------------------------------------------
    // Helpers
    //------------------------------------------------------------------------------------------------------------------

    private String extractDatasetTable(String table) {
        return table.split("\\.", 2)[1];
    }

    private String[] extractDatasetTableArray(String[] tables) {
        return Arrays.stream(tables).map(this::extractDatasetTable).toArray(String[]::new);
    }

    private void waitForDagToRun(DagRun dagRun) throws IOException, InterruptedException {
        LOG.info("Waiting for DAG {} to run...", dagRun.getDagId());

        long timeElapsed = 0;
        while (dagRun.getState() == DagRunState.QUEUED && timeElapsed <= WAIT_MAX) {
            Thread.sleep(WAIT_INTERVAL);
            timeElapsed += WAIT_INTERVAL;
            airflowDagUpdater.checkRunInfo();
        }
    }

    private long retrieveBigQueryTableTotalRecordCount(String tableName) throws InterruptedException {
        return retrieveBigQueryTableRecordCount(String.format("SELECT COUNT(*) AS record_count FROM `%s`", tableName));
    }
    private long retrieveBigQueryTableRecordCount(String recordCountQuery) throws InterruptedException {
        TableResult result = BigQueryUtils.executeQuery(recordCountQuery);

        Assertions.assertThat(result.getTotalRows())
                .as("Record count rows")
                .isEqualTo(1);

        long recordCount = 0;
        for (FieldValueList row : result.iterateAll()) {
            recordCount = row.get(0).getNumericValue().longValue();
            break;
        }

        return recordCount;
    }

    private void waitForDagToFinish(DagRun dagRun) throws InterruptedException, IOException {
        LOG.info("Waiting for DAG to finish running...");

        long timeElapsed = 0;
        while (dagRun.getState() == DagRunState.RUNNING && timeElapsed <= WAIT_MAX) {
            Thread.sleep(WAIT_INTERVAL);
            timeElapsed += WAIT_INTERVAL;
            airflowDagUpdater.checkRunInfo();
        }

        LOG.info("DAG is finished");
    }

    private void waitForTaskToCompleteSuccessfully(DagRun dagRun, String taskId) throws IOException, InterruptedException {
        waitForTaskToComplete(dagRun, taskId);
        Assertions.assertThat(dagRun.getTaskInstance(taskId).getState())
                .isEqualTo(TaskInstanceState.SUCCESS);
        Thread.sleep(2000);
    }

    private void waitForTaskToComplete(DagRun dagRun, String taskId) throws InterruptedException, IOException {
        // Check if task is already done running
        if (dagRun.getTaskInstance(taskId).isFinished()) {
            return;
        }

        // Waiting for task
        LOG.info("Waiting for task {} to complete ...", taskId);

        long timeElapsed = 0;
        do {
            Thread.sleep(WAIT_INTERVAL);
            timeElapsed += WAIT_INTERVAL;
            airflowDagUpdater.checkTaskInstanceInfo(taskId);
        } while (!dagRun.getTaskInstance(taskId).isFinished() && timeElapsed <= WAIT_MAX);

        LOG.info("Task {} is completed with state {}", taskId, dagRun.getTaskInstance(taskId).getState());
    }

    @AfterClass(alwaysRun = true)
    public void cleanup_test_files() {
        try {
            if (fileRoutingStorageManager != null && testCloudFileNames != null) {
                fileRoutingStorageManager.cleanUpRawFolderFiles(testCloudFileNames);
                LOG.info("Cleaned up all raw test files: " + testCloudFileNames);
            }
        } catch (Exception e) {
            LOG.error("Failed to clean up all raw test files");
            LOG.error(e);
        }
    }

    @AfterClass(alwaysRun = true)
    public void clean_table_records() {
        try {
            if (ingestionRecCreTms != null) {
                String deleteQuery = new SingleSourceQuery()
                        .setTemplate("DELETE FROM `${TABLE}` WHERE rec_cre_tms = '${TIMESTAMP}' AND file_name IN (${FILES NAMES})")
                        .setTableName(ingestionTable)
                        .setTimestamp(ingestionRecCreTms)
                        .setFiles(rawTestCloudFiles)
                        .build();

                BigQueryUtils.executeQuery(deleteQuery);
            }
        } catch (Exception e) {
            LOG.error("Failed to cleanup ingestion records");
            LOG.error(e);
        }

        try {
            if (curationRecCreTms != null) {
                String deleteQuery = new SingleSourceQuery()
                        .setTemplate("DELETE FROM `${TABLE}` WHERE rec_cre_tms = '${TIMESTAMP}' AND REGEXP_EXTRACT(raw_files_nm,'[^/~]+') IN (${FILES NAMES})")
                        .setTableName(curationTable)
                        .setTimestamp(curationRecCreTms)
                        .setFiles(rawTestCloudFiles)
                        .build();

                BigQueryUtils.executeQuery(deleteQuery);
            }
        } catch (Exception e) {
            LOG.error("Failed to cleanup curation records");
            LOG.error(e);
        }
    }

    @AfterClass(alwaysRun = true)
    public void report_record_counts() {
        // Ingestion
        Reporter.info(createIngestionData(), "individual-table");

        // Snapshot
        if (snapshotTable != null) {
            Reporter.info(createSnapshotData(), "individual-table");
        }

        // Curation
        Reporter.info(createCurationData(), "individual-table");

        // Publication
        for (int tableIndex = 0; tableIndex < publicationTables.length; tableIndex++) {
            Reporter.info(createPublicationData(tableIndex), "individual-table");
        }
    }

    private String[][] createIngestionData() {
        return new String[][] {
                {"Ingestion Table", extractDatasetTable(ingestionTable)},
                {"Previous Total Records", String.valueOf(ingestionTablePreviousTotalRecordCount)},
                {"Current Total Records", String.valueOf(ingestionTableTotalRecordCount)},
                {"Batch Record Count", String.valueOf(ingestionTableRecordCount)},
                {"Batch Record Creation Timestamp", ingestionRecCreTms}
        };
    }

    private String[][] createSnapshotData() {
        return new String[][] {
                {"Snapshot Table", extractDatasetTable(snapshotTable)},
                {"Previous Total Records", String.valueOf(snapshotTablePreviousTotalRecordCount)},
                {"Current Total Records", String.valueOf(snapshotTableRecordCount)},
                {"Snapshot Time", snapshotTime}
        };
    }

    private String[][] createCurationData() {
        return new String[][] {
                {"Curation Table", extractDatasetTable(curationTable)},
                {"Previous Total Records", String.valueOf(curationTablePreviousTotalRecordCount)},
                {"Current Total Records", String.valueOf(curationTableTotalRecordCount)},
                {"Batch Record Count", String.valueOf(curationTableRecordCount)},
                {"Batch Record Creation Timestamp", curationRecCreTms}
        };
    }

    private String[][] createPublicationData(int tableIndex) {
        return new String[][] {
                {"Publication Table", extractDatasetTable(publicationTables[tableIndex])},
                {"Previous Total Records", String.valueOf(publicationTablePreviousTotalRecordCounts[tableIndex])},
                {"Current Total Records", String.valueOf(publicationTableTotalRecordCounts[tableIndex])},
                {"Batch Record Count", String.valueOf(publicationTableRecordCounts[tableIndex])},
                {"Batch Record Creation Timestamp", publicationRecCreTms}
        };
    }
}