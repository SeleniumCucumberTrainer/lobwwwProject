package ca.loblaw.cerebro.automation.models.cloud.function.airflow.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class AirflowResponseTaskList extends AirflowResponseItem {
    @JsonProperty("dag_id")
    private String dagId;

    @JsonProperty("tasks")
    private List<String> taskList;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public List<String> getTaskList() {
        return taskList;
    }

    public void setTaskList(List<String> taskList) {
        this.taskList = taskList;
    }
}
